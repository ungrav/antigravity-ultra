# Blueprint Manifest

`manifest.json` es el índice hash-based de los artefactos restaurables desde `GEMINI_BLUEPRINTS.md`.

## Propósito
- Resolver un artefacto por `artifact_id`.
- Saber su marcador (`BEGIN/END`) sin depender de offsets.
- Verificar integridad con `sha256` antes de restaurar.
- Distinguir entre restore al `gemini_root` y restore al `project_root`.

## Tipos actuales
- `workflow:*`
- `template:*`
- `system:*`

## Scripts
- `bash ~/.gemini/scripts/build-blueprints.sh`
- `bash ~/.gemini/scripts/build-blueprint-manifest.sh`
- `bash ~/.gemini/scripts/verify-blueprint-manifest.sh`
- `bash ~/.gemini/scripts/restore-blueprint-artifact.sh <artifact_id>`
