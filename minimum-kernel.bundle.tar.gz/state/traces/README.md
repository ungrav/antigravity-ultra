# Trace Contract

Cada archivo `*.jsonl` en este directorio representa runs o checkpoints del sistema.

## Reglas mínimas
- Un evento por línea.
- Cada línea debe cumplir `trace.schema.json`.
- Registrar al menos:
  - `schema_version`
  - `run_id`
  - `timestamp`
  - `phase`
  - `event_type`
  - `actor`
  - `status`
  - `workflows`
  - `checks`
- `status` permitidos: `started`, `passed`, `failed`, `blocked`, `confirm_required`.
- `event_type` permitidos: `phase`, `guardrail`, `routing`, `hook`, `incident`.
- Campos opcionales: `notes`, `primary_workflow`, `hook_stage`, `guardrail_decision`, `metadata`.

## Emisión
- Preferir `scripts/emit-trace-event.sh` para evitar drift de formato.
- Los hooks de lifecycle deben dejar sus eventos usando el emisor canónico.
- Los scripts de hardening/evals deben escribir trazas compatibles con `schema_version >= 2`.

## Uso actual
- Trazas de hardening y validación del kernel.
- Evals base (`doctor`, `core-evals`, blueprint restore, guardrails, routing, lifecycle hooks).
- Captura homogénea de eventos de fase, routing, guardrails, hooks e incidentes.
