---
name: autofix
description: >
  Adaptador fino para lanzar la capacidad core `autofix` del kernel. Usa el
  workflow canónico para preparar el contrato, la memoria y el loop seguro.
---

# Autofix (Thin Adapter)

Esta skill ya no define la arquitectura de `autofix`. Su responsabilidad es mínima:
- reconocer la intención del usuario
- preparar el contexto local
- delegar al workflow canónico
- invocar el loop oficial

La fuente de verdad es:
- `~/.gemini/workflows/autofix-workflow.md`

El ejecutor oficial es:
- `~/.gemini/skills/autofix/scripts/autofix-loop.sh`

## Contrato del Adapter

Cuando el usuario diga cosas como:
- "autofix esto"
- "itera hasta que pasen estos tests"
- "optimiza este componente con una métrica clara"

haz exactamente esto:
1. Leer `autofix-workflow.md`.
2. Crear o validar `.autofix/spec.json`, `.autofix/eval.sh` y el resto del contrato.
3. Reusar `.agent/knowledge/` si existe.
4. Lanzar el loop oficial.

## Reglas

- `program.md` ya no es la fuente de verdad; solo es una vista generada.
- Nunca vuelvas a documentar `git restore .`, `git checkout -- .`, `git stash` o auto-commit como parte del motor.
- Si la tarea no tiene evaluación objetiva, no fuerces `autofix`; quédate en el workflow padre.
- Si hay que restaurar esta capacidad desde `GEMINI_BLUEPRINTS.md`, restaura el workflow, esta skill, el loop y las plantillas `.autofix/` juntos.
