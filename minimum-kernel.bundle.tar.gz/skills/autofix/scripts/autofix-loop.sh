#!/usr/bin/env bash
set -euo pipefail

ROOT="${AUTOFIX_ROOT:-$HOME/.gemini}"
PROJECT_ROOT="$(pwd)"
WORKSPACE=""
SPEC_PATH=""
RUN_ID="${AUTOFIX_RUN_ID:-run-$(date -u +%Y%m%dT%H%M%SZ)}"
INNER_WORKTREE="${AUTOFIX_INNER_WORKTREE:-0}"
BACKEND_OVERRIDE=""
MAX_ITERATIONS_OVERRIDE=""
TIMEOUT_OVERRIDE=""

usage() {
  cat <<'EOF'
Usage:
  autofix-loop.sh [--project-root PATH] [--workspace PATH] [--spec PATH] [--agent BACKEND] [--max-iterations N] [--timeout-seconds N] [--run-id ID]

Backends:
  codex | claude | gemini
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --project-root)
      PROJECT_ROOT="$2"
      shift 2
      ;;
    --workspace)
      WORKSPACE="$2"
      shift 2
      ;;
    --spec)
      SPEC_PATH="$2"
      shift 2
      ;;
    --agent|--backend)
      BACKEND_OVERRIDE="$2"
      shift 2
      ;;
    --max-iterations)
      MAX_ITERATIONS_OVERRIDE="$2"
      shift 2
      ;;
    --timeout-seconds)
      TIMEOUT_OVERRIDE="$2"
      shift 2
      ;;
    --run-id)
      RUN_ID="$2"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown parameter: $1" >&2
      usage
      exit 1
      ;;
  esac
done

PROJECT_ROOT="$(cd "$PROJECT_ROOT" && pwd)"
WORKSPACE="${WORKSPACE:-$PROJECT_ROOT/.autofix}"
SPEC_PATH="${SPEC_PATH:-$WORKSPACE/spec.json}"
PROGRAM_PATH="$WORKSPACE/program.md"
EVAL_PATH="$WORKSPACE/eval.sh"
RESULT_PATH="$WORKSPACE/result.json"
STATE_PATH="$WORKSPACE/state.json"
HISTORY_PATH="$WORKSPACE/history.jsonl"
SNAPSHOT_ROOT="$WORKSPACE/snapshots"
MEMORY_HITS_PATH="$WORKSPACE/memory_hits.json"
MEMORY_REJECTIONS_PATH="$WORKSPACE/memory_rejections.json"
FALLBACK_BACKEND_DIR="$ROOT/scripts/autofix-backends"
TEMPLATE_DIR="$ROOT/templates/autofix"
TRASH_ROOT="$PROJECT_ROOT/_DEPRECATED_TRASH/autofix/$RUN_ID"
CHECKPOINT_ROOT="/tmp/gemini-autofix-checkpoints/${RUN_ID}"
CURRENT_ITERATION=0
STARTED_AT="$(date +%s)"
FINISHED_AT=0
BEST_SCORE=""
BEST_ITERATION=""
LAST_IMPROVEMENT_ITERATION=0
EFFECTIVE_ROLLBACK_MODE=""
BACKEND=""
GOAL=""
TENANT_DOMAIN=""
OBJECTIVE_TYPE=""
EVAL_MODE=""
REQUIRES_SECURE_ORIGIN="false"
SUCCESS_RULE_TYPE=""
SUCCESS_METRIC_NAME=""
SUCCESS_THRESHOLD="0"
MAX_ITERATIONS=0
PLATEAU_WINDOW=0
TIMEOUT_SECONDS=0
MEMORY_MODE=""
MEMORY_QUERY_MODE="${AUTOFIX_MEMORY_QUERY_MODE:-normal}"
BACKEND_WRAPPER=""
BACKEND_BIN=""
STRATEGY_HINT_JSON="null"
REUSED_KI_IDS=()
EDITABLE_FILES=()
FULL_CHECKPOINT_PATH=""

emit_info() {
  printf 'INFO: %s\n' "$1"
}

emit_error() {
  printf 'ERROR: %s\n' "$1" >&2
}

json_array_from_args() {
  if [[ $# -eq 0 ]]; then
    printf '[]'
    return
  fi
  printf '%s\n' "$@" | jq -R . | jq -s .
}

history_event() {
  local event="$1"
  local status="$2"
  local message="${3:-}"
  local changed_json="${4:-[]}"
  local details_json="${5:-null}"
  jq -cn \
    --arg event "$event" \
    --arg status "$status" \
    --arg message "$message" \
    --argjson ts "$(date +%s)" \
    --argjson iteration "$CURRENT_ITERATION" \
    --argjson changed_files "$changed_json" \
    --argjson details "$details_json" \
    '{
      ts: $ts,
      iteration: $iteration,
      event: $event,
      status: $status,
      message: $message,
      changed_files: $changed_files
    }
    + (if $details == null then {} else {details: $details} end)' >> "$HISTORY_PATH"
}

write_state() {
  local status="$1"
  local best_score_json="null"
  local best_iteration_json="null"
  if [[ -n "$BEST_SCORE" ]]; then
    best_score_json="$BEST_SCORE"
  fi
  if [[ -n "$BEST_ITERATION" ]]; then
    best_iteration_json="$BEST_ITERATION"
  fi
  jq -n \
    --argjson version 1 \
    --arg run_id "$RUN_ID" \
    --arg status "$status" \
    --arg rollback_mode "$EFFECTIVE_ROLLBACK_MODE" \
    --argjson current_iteration "$CURRENT_ITERATION" \
    --argjson best_score "$best_score_json" \
    --argjson best_iteration "$best_iteration_json" \
    --argjson started_at "$STARTED_AT" \
    --argjson finished_at "$FINISHED_AT" \
    '{
      version: $version,
      run_id: $run_id,
      status: $status,
      current_iteration: $current_iteration,
      best_score: $best_score,
      best_iteration: $best_iteration,
      rollback_mode: $rollback_mode,
      started_at: $started_at,
      finished_at: $finished_at
    }' > "$STATE_PATH"
}

write_result() {
  local status="$1"
  local summary="$2"
  local score="${3:-0}"
  shift 3 || true
  local changed_json
  changed_json="$(json_array_from_args "$@")"
  jq -n \
    --arg status "$status" \
    --arg metric_name "$SUCCESS_METRIC_NAME" \
    --arg summary "$summary" \
    --argjson score "$score" \
    --argjson changed_files "$changed_json" \
    '{
      status: $status,
      metric_name: $metric_name,
      score: $score,
      summary: $summary,
      changed_files: $changed_files
    }' > "$RESULT_PATH"
}

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || {
    emit_error "Missing required command: $1"
    exit 1
  }
}

for cmd in jq awk sed find sort head tail tr basename dirname mktemp shasum perl rsync; do
  require_cmd "$cmd"
done

slugify() {
  printf '%s' "$1" | tr '[:upper:]' '[:lower:]' | tr -cs 'a-z0-9' '-' | sed 's/^-//; s/-$//; s/--*/-/g'
}

safe_move_to_trash() {
  local rel_path="$1"
  local abs_path="$PROJECT_ROOT/$rel_path"
  [[ -e "$abs_path" ]] || return 0
  mkdir -p "$(dirname "$TRASH_ROOT/$rel_path")"
  mv "$abs_path" "$TRASH_ROOT/$rel_path"
}

seed_if_missing() {
  local target="$1"
  local source="$2"
  if [[ ! -f "$target" && -f "$source" ]]; then
    mkdir -p "$(dirname "$target")"
    cp "$source" "$target"
  fi
}

ensure_workspace_contract() {
  mkdir -p "$WORKSPACE"
  seed_if_missing "$SPEC_PATH" "$TEMPLATE_DIR/spec.json"
  seed_if_missing "$PROGRAM_PATH" "$TEMPLATE_DIR/program.md"
  seed_if_missing "$EVAL_PATH" "$TEMPLATE_DIR/eval.sh"
  seed_if_missing "$RESULT_PATH" "$TEMPLATE_DIR/result.json"
  seed_if_missing "$STATE_PATH" "$TEMPLATE_DIR/state.json"
  touch "$HISTORY_PATH"
  chmod +x "$EVAL_PATH" 2>/dev/null || true
}

ensure_memory_baseline() {
  local vault="$PROJECT_ROOT/.agent/knowledge"
  mkdir -p "$vault"/{conclusions,research,skill_insights}
}

validate_spec() {
  jq -e '
    .version == 1 and
    (.goal | type == "string" and length > 0) and
    (.tenant_domain | type == "string" and length > 0) and
    (.objective_type as $t | ["bugfix","refactor","optimize","test","quality"] | index($t) != null) and
    (.editable_files | type == "array" and length > 0 and all(.[]; type == "string")) and
    (.backend as $b | ["codex","claude","gemini"] | index($b) != null) and
    (.eval_mode as $m | ["test","build","browser","metric"] | index($m) != null) and
    (.requires_secure_origin | type == "boolean") and
    (.success_rule.type as $s | ["pass_fail","score_threshold"] | index($s) != null) and
    (.success_rule.metric_name | type == "string" and length > 0) and
    (.success_rule.threshold | type == "number") and
    (.max_iterations | type == "number" and . >= 1 and . <= 20) and
    (.plateau_window | type == "number" and . >= 1 and . <= 10) and
    (.timeout_seconds | type == "number" and . >= 30) and
    (.rollback_mode as $r | ["git_worktree","hybrid_safe"] | index($r) != null) and
    (.memory_mode | type == "string" and length > 0) and
    (
      (.strategy_hint // null) == null or (
        (.strategy_hint | type == "object") and
        (.strategy_hint.strategy_id | type == "string" and length > 0) and
        (.strategy_hint.decision_source | type == "string" and length > 0) and
        (.strategy_hint.confidence | type == "number" and . >= 0 and . <= 1) and
        ((.strategy_hint.backend_hint // null) == null or (.strategy_hint.backend_hint | type == "object")) and
        ((.strategy_hint.reasoning_effort // null) == null or (.strategy_hint.reasoning_effort | type == "string" and length > 0)) and
        (.strategy_hint.workflow_chain | type == "array" and all(.[]; type == "string")) and
        (.strategy_hint.skill_hints | type == "array" and all(.[]; type == "string")) and
        (
          (.strategy_hint.autofix_hint // null) == null or (
            (.strategy_hint.autofix_hint | type == "object") and
            ((.strategy_hint.autofix_hint.status // null) == null or (.strategy_hint.autofix_hint.status | type == "string" and length > 0)) and
            ((.strategy_hint.autofix_hint.blocked_reason // null) == null or (.strategy_hint.autofix_hint.blocked_reason | type == "string"))
          )
        )
      )
    )
  ' "$SPEC_PATH" >/dev/null

  while IFS= read -r rel; do
    [[ "$rel" = /* ]] && {
      emit_error "editable_files must be relative paths: $rel"
      exit 1
    }
    [[ "$rel" == *".."* ]] && {
      emit_error "editable_files must not contain '..': $rel"
      exit 1
    }
  done < <(jq -r '.editable_files[]' "$SPEC_PATH")

  return 0
}

load_spec() {
  GOAL="$(jq -r '.goal' "$SPEC_PATH")"
  TENANT_DOMAIN="$(jq -r '.tenant_domain' "$SPEC_PATH")"
  OBJECTIVE_TYPE="$(jq -r '.objective_type' "$SPEC_PATH")"
  BACKEND="$(jq -r '.backend' "$SPEC_PATH")"
  EVAL_MODE="$(jq -r '.eval_mode' "$SPEC_PATH")"
  REQUIRES_SECURE_ORIGIN="$(jq -r '.requires_secure_origin' "$SPEC_PATH")"
  SUCCESS_RULE_TYPE="$(jq -r '.success_rule.type' "$SPEC_PATH")"
  SUCCESS_METRIC_NAME="$(jq -r '.success_rule.metric_name' "$SPEC_PATH")"
  SUCCESS_THRESHOLD="$(jq -r '.success_rule.threshold' "$SPEC_PATH")"
  MAX_ITERATIONS="$(jq -r '.max_iterations' "$SPEC_PATH")"
  PLATEAU_WINDOW="$(jq -r '.plateau_window' "$SPEC_PATH")"
  TIMEOUT_SECONDS="$(jq -r '.timeout_seconds' "$SPEC_PATH")"
  MEMORY_MODE="$(jq -r '.memory_mode' "$SPEC_PATH")"
  STRATEGY_HINT_JSON="$(jq -c '.strategy_hint // null' "$SPEC_PATH")"
  EDITABLE_FILES=()
  while IFS= read -r editable_file; do
    EDITABLE_FILES+=("$editable_file")
  done < <(jq -r '.editable_files[]' "$SPEC_PATH")

  if [[ -n "$BACKEND_OVERRIDE" ]]; then
    BACKEND="$BACKEND_OVERRIDE"
  fi
  if [[ -n "$MAX_ITERATIONS_OVERRIDE" ]]; then
    MAX_ITERATIONS="$MAX_ITERATIONS_OVERRIDE"
  fi
  if [[ -n "$TIMEOUT_OVERRIDE" ]]; then
    TIMEOUT_SECONDS="$TIMEOUT_OVERRIDE"
  fi

  return 0
}

is_git_repo() {
  command -v git >/dev/null 2>&1 || return 1
  git -C "$PROJECT_ROOT" rev-parse --is-inside-work-tree >/dev/null 2>&1
}

git_tree_is_clean() {
  command -v git >/dev/null 2>&1 || return 1
  git -C "$PROJECT_ROOT" status --porcelain --untracked-files=no | awk 'NF { exit 1 }'
}

choose_effective_mode() {
  if [[ "$INNER_WORKTREE" == "1" ]]; then
    EFFECTIVE_ROLLBACK_MODE="git_worktree"
    return
  fi

  if is_git_repo && git_tree_is_clean; then
    EFFECTIVE_ROLLBACK_MODE="git_worktree"
  else
    EFFECTIVE_ROLLBACK_MODE="hybrid_safe"
  fi
}

run_with_timeout() {
  local timeout_seconds="$1"
  shift
  perl -e 'alarm shift; exec @ARGV;' "$timeout_seconds" "$@"
}

extract_summary() {
  local file="$1"
  awk '
    BEGIN { in_frontmatter = 0; seen_first = 0; lines = 0 }
    /^---$/ {
      if (!seen_first) {
        seen_first = 1
        in_frontmatter = 1
        next
      }
      if (in_frontmatter) {
        in_frontmatter = 0
        next
      }
    }
    in_frontmatter { next }
    NF {
      print
      lines++
      if (lines >= 5) exit
    }
  ' "$file"
}

record_memory_outcome() {
  local event_type="$1"
  local ki_id="$2"
  local reason="${3:-}"
  local weight="${4:-0}"
  history_event "$event_type" "ok" "Memory outcome for $ki_id." "[]" "$(jq -cn \
    --arg ki_id "$ki_id" \
    --arg reason "$reason" \
    --argjson weight "$weight" \
    '{ki_id: $ki_id, reason: $reason, weight: $weight}')"
}

load_memory_context() {
  local vault="$PROJECT_ROOT/.agent/knowledge"
  local candidates_jsonl
  local selection_state
  local selected_json
  local rejected_json
  candidates_jsonl="$(mktemp "${TMPDIR:-/tmp}/autofix-memory-candidates.XXXXXX")"
  selection_state="$(mktemp "${TMPDIR:-/tmp}/autofix-memory-selection.XXXXXX")"
  selected_json="$(mktemp "${TMPDIR:-/tmp}/autofix-memory-selected.XXXXXX")"
  rejected_json="$(mktemp "${TMPDIR:-/tmp}/autofix-memory-rejected.XXXXXX")"

  printf '[]' > "$MEMORY_HITS_PATH"
  printf '[]' > "$MEMORY_REJECTIONS_PATH"
  history_event "memory_selection_started" "running" "Selecting reusable local KIs for autofix."

  if [[ "$MEMORY_QUERY_MODE" != "normal" && "$MEMORY_QUERY_MODE" != "historical" ]]; then
    history_event "memory_selection_rejected" "skip" "Unsupported memory query mode; continuing without memory." "[]" '{"reason":"invalid_query_mode"}'
    history_event "memory_loaded" "noop" "Memory selection skipped because query mode was invalid."
    rm -f "$candidates_jsonl" "$selection_state" "$selected_json" "$rejected_json"
    return 0
  fi

  if [[ ! -d "$vault" ]]; then
    history_event "memory_selection_rejected" "skip" "No local knowledge vault found." "[]" '{"reason":"missing_vault"}'
    history_event "memory_loaded" "noop" "No local knowledge vault found."
    rm -f "$candidates_jsonl" "$selection_state" "$selected_json" "$rejected_json"
    return 0
  fi

  local -a goal_tokens=()
  while IFS= read -r token; do
    [[ ${#token} -ge 4 ]] && goal_tokens+=("$token")
  done < <(printf '%s' "$GOAL" | tr '[:upper:]' '[:lower:]' | tr -cs '[:alnum:]' '\n' | head -n 8)

  while IFS= read -r file; do
    [[ -f "$file" ]] || continue

    local category_dir
    local category
    local ki_id
    local ki_status
    local tenant_domain
    local related_kis_json
    local summary
    local summary_hash
    local domain_match=0
    local domain_score=0
    local file_match_count=0
    local token_match_count=0
    local rerank_score
    local scoring_json
    local final_score
    local selection_reason
    local reason_parts=()

    category_dir="$(basename "$(dirname "$file")")"
    case "$category_dir" in
      conclusions)
        category="conclusion"
        ;;
      research)
        category="research"
        ;;
      skill_insights)
        category="skill_insight"
        ;;
      *)
        continue
        ;;
    esac

    ki_id="$(sed -nE 's/^ki_id:[[:space:]]*"?([^"]+)"?/\1/p' "$file" | head -1)"
    ki_status="$(sed -nE 's/^status:[[:space:]]*"?([^"]+)"?/\1/p' "$file" | head -1)"
    tenant_domain="$(sed -nE 's/^tenant_domain:[[:space:]]*"?([^"]+)"?/\1/p' "$file" | head -1)"
    related_kis_json="$(sed -nE 's/^related_kis:[[:space:]]*(\[.*\])/\1/p' "$file" | head -1)"

    [[ -z "$ki_id" ]] && continue
    [[ -z "$ki_status" ]] && ki_status="active"
    [[ -z "$tenant_domain" ]] && tenant_domain="unknown"
    [[ -z "$related_kis_json" ]] && related_kis_json='[]'

    if [[ "$MEMORY_QUERY_MODE" == "normal" && "$ki_status" != "active" ]]; then
      history_event "memory_selection_rejected" "skip" "Rejected $ki_id because it is not active in normal mode." "[]" "{\"ki_id\":\"$ki_id\",\"reason\":\"status_filtered\",\"status\":\"$ki_status\"}"
      continue
    fi

    if [[ "$MEMORY_QUERY_MODE" == "historical" && "$ki_status" == "archived" ]]; then
      history_event "memory_selection_rejected" "skip" "Rejected $ki_id because archived items are excluded in historical mode." "[]" "{\"ki_id\":\"$ki_id\",\"reason\":\"status_filtered\",\"status\":\"$ki_status\"}"
      continue
    fi

    if [[ "$tenant_domain" == "$TENANT_DOMAIN" ]]; then
      domain_match=1
      domain_score=1
      reason_parts+=("tenant_domain")
    fi

    local editable
    for editable in "${EDITABLE_FILES[@]}"; do
      local base
      base="$(basename "$editable")"
      if rg -qi "$base" "$file"; then
        file_match_count=$((file_match_count + 1))
      fi
    done

    local token
    for token in "${goal_tokens[@]}"; do
      if rg -qi "$token" "$file"; then
        token_match_count=$((token_match_count + 1))
      fi
    done

    if (( file_match_count > 0 )); then
      reason_parts+=("editable_file")
    fi
    if (( token_match_count > 0 )); then
      reason_parts+=("goal_tokens")
    fi

    rerank_score="$(jq -cn \
      --arg category "$category" \
      --argjson domain_match "$domain_match" \
      --argjson file_match_count "$file_match_count" \
      --argjson token_match_count "$token_match_count" \
      '
      def clamp01:
        if . < 0 then 0
        elif . > 1 then 1
        else .
        end;
      (
        (if $domain_match == 1 then 0.30 else 0 end)
        + (if $category == "conclusion" then 0.15 elif $category == "skill_insight" then 0.12 elif $category == "research" then 0.10 else 0 end)
        + (($file_match_count * 0.18) | if . > 0.30 then 0.30 else . end)
        + (($token_match_count * 0.04) | if . > 0.15 then 0.15 else . end)
        + (if $file_match_count > 0 and $token_match_count > 0 then 0.10 else 0 end)
      ) | clamp01
      ')"

    scoring_json="$(jq -cn \
      --argjson rerank_score "$rerank_score" \
      --argjson domain_score "$domain_score" \
      '
      def clamp01:
        if . < 0 then 0
        elif . > 1 then 1
        else .
        end;
      ((0.85 * $rerank_score) + (0.15 * $domain_score)) as $final_score
      | {
          final_score: $final_score
        }
      ')"

    final_score="$(printf '%s' "$scoring_json" | jq -r '.final_score')"

    summary="$(extract_summary "$file" | tr '\n' ' ' | sed 's/  */ /g; s/^ //; s/ $//')"
    summary="$(printf '%s' "$summary" | cut -c1-240)"
    summary_hash="$(printf '%s' "$summary" | shasum -a 256 | awk '{print $1}')"

    selection_reason="baseline"
    if [[ -n "${reason_parts[*]-}" ]]; then
      selection_reason="$(IFS=+; printf '%s' "${reason_parts[*]}")"
    fi

    jq -cn \
      --arg path "$file" \
      --arg ki_id "$ki_id" \
      --arg category "$category" \
      --arg status "$ki_status" \
      --arg tenant_domain "$tenant_domain" \
      --arg summary "$summary" \
      --arg summary_hash "$summary_hash" \
      --arg selection_reason "$selection_reason" \
      --argjson related_kis "$related_kis_json" \
      --argjson domain_score "$domain_score" \
      --argjson rerank_score "$rerank_score" \
      --argjson final_score "$final_score" \
      '{
        path: $path,
        ki_id: $ki_id,
        category: $category,
        status: $status,
        tenant_domain: $tenant_domain,
        summary: $summary,
        summary_hash: $summary_hash,
        related_kis: $related_kis,
        selection_reason: $selection_reason,
        domain_score: $domain_score,
        rerank_score: $rerank_score,
        final_score: $final_score
      }' >> "$candidates_jsonl"
  done < <(find "$vault" \( -path "$vault/conclusions/*.md" -o -path "$vault/research/*.md" -o -path "$vault/skill_insights/*.md" \) -type f 2>/dev/null | sort)

  if [[ ! -s "$candidates_jsonl" ]]; then
    history_event "memory_selection_rejected" "skip" "No reusable local KIs matched the run." "[]" '{"reason":"no_candidates"}'
    history_event "memory_loaded" "noop" "No reusable local KIs matched the run."
    rm -f "$candidates_jsonl" "$selection_state" "$selected_json" "$rejected_json"
    return 0
  fi

  jq -s '
    def limit_for($category):
      if $category == "conclusion" then 2
      elif $category == "research" then 2
      elif $category == "skill_insight" then 1
      else 0
      end;
    def overlaps($needles; $haystack):
      any($needles[]?; $haystack | index(.) != null);
    sort_by(-.final_score)
    | reduce .[] as $cand (
        {
          selected: [],
          rejected: [],
          selected_ids: [],
          selected_related: [],
          summary_hashes: [],
          category_counts: {conclusion: 0, research: 0, skill_insight: 0}
        };
        ($cand.category) as $category
        | if (.selected | length) >= 5 then
            .rejected += [$cand + {selection_rejection: "total_budget"}]
          elif (limit_for($category) == 0) then
            .rejected += [$cand + {selection_rejection: "unsupported_category"}]
          elif ((.category_counts[$category] // 0) >= limit_for($category)) then
            .rejected += [$cand + {selection_rejection: "category_budget"}]
          elif (.summary_hashes | index($cand.summary_hash)) != null then
            .rejected += [$cand + {selection_rejection: "duplicate_summary"}]
          elif ((.selected_related | index($cand.ki_id)) != null) then
            .rejected += [$cand + {selection_rejection: "duplicate_related"}]
          elif overlaps(($cand.related_kis // []); .selected_ids) then
            .rejected += [$cand + {selection_rejection: "duplicate_related"}]
          else
            .selected += [$cand]
            | .selected_ids += [$cand.ki_id]
            | .selected_related += ($cand.related_kis // [])
            | .summary_hashes += [$cand.summary_hash]
            | .category_counts[$category] = ((.category_counts[$category] // 0) + 1)
          end
      )
  ' "$candidates_jsonl" > "$selection_state"

  jq '.selected' "$selection_state" > "$selected_json"
  jq '.rejected' "$selection_state" > "$rejected_json"
  cp "$selected_json" "$MEMORY_HITS_PATH"
  cp "$rejected_json" "$MEMORY_REJECTIONS_PATH"

  while IFS= read -r rejected_line; do
    [[ -z "$rejected_line" ]] && continue
    local rejected_message
    local rejected_details
    rejected_message="$(printf '%s' "$rejected_line" | jq -r '"Rejected \(.ki_id): \(.selection_rejection)."')"
    rejected_details="$(printf '%s' "$rejected_line" | jq -c '{ki_id, category, final_score, selection_reason, selection_rejection}')"
    history_event "memory_selection_rejected" "skip" "$rejected_message" "[]" "$rejected_details"
  done < <(jq -c '.[]' "$rejected_json")

  if [[ "$(jq 'length' "$selected_json")" -eq 0 ]]; then
    history_event "memory_selection_rejected" "skip" "No KIs survived memory selection budgets or deduplication." "[]" '{"reason":"selection_empty"}'
    history_event "memory_loaded" "noop" "No KIs survived memory selection."
    rm -f "$candidates_jsonl" "$selection_state" "$selected_json" "$rejected_json"
    return 0
  fi

  while IFS= read -r selected_line; do
    [[ -z "$selected_line" ]] && continue
    local selected_ki
    local selected_details
    selected_ki="$(printf '%s' "$selected_line" | jq -r '.ki_id')"
    REUSED_KI_IDS+=("$selected_ki")
    record_memory_outcome "memory_selected" "$selected_ki" "" 0
    selected_details="$(printf '%s' "$selected_line" | jq -c '{ki_id, category, final_score, selection_reason}')"
    history_event "memory_selection_completed" "ok" "Selected reusable KI $selected_ki." "[]" "$selected_details"
  done < <(jq -c '.[]' "$selected_json")

  history_event "memory_loaded" "ok" "Recovered local KIs for autofix."
  rm -f "$candidates_jsonl" "$selection_state" "$selected_json" "$rejected_json"
  return 0
}

render_program() {
  local editable_md
  editable_md="$(for file in "${EDITABLE_FILES[@]}"; do printf -- '- `%s`\n' "$file"; done)"

  local good_md
  local dead_md
  local hyperlayer_md
  good_md="$(jq -r '
    .[]
    | select(.category == "conclusion" or .category == "skill_insight")
    | "- `" + .ki_id + "` (" + .category + "): " + .summary
  ' "$MEMORY_HITS_PATH" 2>/dev/null || true)"
  dead_md="$(jq -r '
    .[]
    | select(.category == "research")
    | "- `" + .ki_id + "` (" + .category + "): " + .summary
  ' "$MEMORY_HITS_PATH" 2>/dev/null || true)"

  [[ -z "$good_md" ]] && good_md="- None loaded."
  [[ -z "$dead_md" ]] && dead_md="- None loaded."
  hyperlayer_md="- None provided."

  if jq -e '. != null' <<< "$STRATEGY_HINT_JSON" >/dev/null 2>&1; then
    local strategy_id
    local decision_source
    local confidence
    local preferred_provider
    local preferred_model
    local preferred_reasoning
    local workflow_md
    local skill_md
    local autofix_status
    local blocked_reason
    local strategy_good_md
    local strategy_dead_md
    strategy_id="$(jq -r '.strategy_id' <<< "$STRATEGY_HINT_JSON")"
    decision_source="$(jq -r '.decision_source' <<< "$STRATEGY_HINT_JSON")"
    confidence="$(jq -r '.confidence' <<< "$STRATEGY_HINT_JSON")"
    preferred_provider="$(jq -r '.backend_hint.provider_id // .backend_hint.provider // "none"' <<< "$STRATEGY_HINT_JSON")"
    preferred_model="$(jq -r '.backend_hint.model // "none"' <<< "$STRATEGY_HINT_JSON")"
    preferred_reasoning="$(jq -r '.reasoning_effort // .backend_hint.reasoning_effort // "none"' <<< "$STRATEGY_HINT_JSON")"
    workflow_md="$(jq -r '.workflow_chain | if length == 0 then "  - None suggested." else map("  - `" + . + "`") | join("\n") end' <<< "$STRATEGY_HINT_JSON")"
    skill_md="$(jq -r '.skill_hints | if length == 0 then "  - None suggested." else map("  - `" + . + "`") | join("\n") end' <<< "$STRATEGY_HINT_JSON")"
    autofix_status="$(jq -r '.autofix_hint.status // "off"' <<< "$STRATEGY_HINT_JSON")"
    blocked_reason="$(jq -r '.autofix_hint.blocked_reason // empty' <<< "$STRATEGY_HINT_JSON")"
    hyperlayer_md="$(cat <<EOF
- Strategy ID: \`${strategy_id}\`
- Decision Source: \`${decision_source}\`
- Confidence: \`${confidence}\`
- Preferred Provider: \`${preferred_provider}\`
- Preferred Model: \`${preferred_model}\`
- Preferred Reasoning: \`${preferred_reasoning}\`
- Workflow Hints:
${workflow_md}
- Skill Hints:
${skill_md}
- Autofix Hint Status: \`${autofix_status}\`
$(if [[ -n "$blocked_reason" ]]; then printf -- '- Blocked Reason: `%s`\n' "$blocked_reason"; fi)
EOF
)"
    strategy_good_md="- \`hyperlayer:${strategy_id}\` (strategy_hint): Decision \`${decision_source}\` with confidence \`${confidence}\`, preferred backend \`${preferred_provider}\` / \`${preferred_model}\`, and reasoning \`${preferred_reasoning}\`."
    if [[ "$good_md" == "- None loaded." ]]; then
      good_md="$strategy_good_md"
    else
      good_md="${strategy_good_md}
${good_md}"
    fi

    if [[ "$autofix_status" == "blocked" || -n "$blocked_reason" ]]; then
      strategy_dead_md="- \`hyperlayer:${strategy_id}\` (strategy_hint): Autofix hint blocked$(if [[ -n "$blocked_reason" ]]; then printf ' because `%s`' "$blocked_reason"; fi)."
      if [[ "$dead_md" == "- None loaded." ]]; then
        dead_md="$strategy_dead_md"
      else
        dead_md="${strategy_dead_md}
${dead_md}"
      fi
    fi
  fi

  cat > "$PROGRAM_PATH" <<EOF
# Autofix Run

This file is generated from \`.autofix/spec.json\` plus recovered memory.
Do not treat it as the source of truth.

## Objective
- Goal: ${GOAL}
- Tenant Domain: \`${TENANT_DOMAIN}\`
- Objective Type: \`${OBJECTIVE_TYPE}\`
- Backend: \`${BACKEND}\`

## Constraints
- Modify only the allowlisted files.
- Do not touch workflow files, BLUEPRINTS, or global kernel files.
- Leave memory updates to the loop itself after evaluation.

## Editable Files
${editable_md}

## Hyperlayer Guidance
${hyperlayer_md}

## Known Good Strategies
${good_md}

## Known Dead Ends
${dead_md}

## Evaluation Contract
- Judge: \`.autofix/eval.sh\`
- Result file: \`.autofix/result.json\`
- Success rule: \`${SUCCESS_RULE_TYPE}\`
- Metric: \`${SUCCESS_METRIC_NAME}\`
- Threshold: \`${SUCCESS_THRESHOLD}\`
EOF
}

fingerprint_workspace() {
  local output="$1"
  (
    cd "$PROJECT_ROOT"
    find . -type f \
      -not -path './.git/*' \
      -not -path './.autofix/*' \
      -not -path './node_modules/*' \
      -not -path './dist/*' \
      -not -path './build/*' \
      -not -path './coverage/*' \
      -not -path './_DEPRECATED_TRASH/*' \
      -print0 \
      | sort -z \
      | xargs -0 shasum -a 256 2>/dev/null \
      | sed 's#  \./# #'
  ) > "$output"
}

detect_changed_paths() {
  local before="$1"
  local after="$2"
  awk '
    NR == FNR { before[$2] = $1; next }
    { after[$2] = $1 }
    END {
      for (path in before) {
        if (!(path in after) || after[path] != before[path]) print path
      }
      for (path in after) {
        if (!(path in before)) print path
      }
    }
  ' "$before" "$after" | sort -u
}

validate_changed_paths() {
  local changed_file_list="$1"
  local invalid=0
  local changed_path
  while IFS= read -r changed_path; do
    [[ -z "$changed_path" ]] && continue
    local allowed=0
    local editable
    for editable in "${EDITABLE_FILES[@]}"; do
      if [[ "$changed_path" == "$editable" ]]; then
        allowed=1
        break
      fi
    done
    if [[ "$allowed" -ne 1 ]]; then
      invalid=1
      safe_move_to_trash "$changed_path"
    fi
  done < "$changed_file_list"

  if [[ "$invalid" -eq 1 ]]; then
    history_event "out_of_scope_edit" "error" "Backend modified files outside editable_files."
    return 1
  fi

  return 0
}

is_risky_run() {
  (( ${#EDITABLE_FILES[@]} > 3 )) && return 0
  [[ "$EVAL_MODE" == "browser" || "$EVAL_MODE" == "build" ]] && return 0
  local editable
  for editable in "${EDITABLE_FILES[@]}"; do
    case "$editable" in
      package.json|package-lock.json|pnpm-lock.yaml|yarn.lock|Cargo.toml|pyproject.toml|vite.config.*|next.config.*|docker-compose*.yml|Dockerfile*)
        return 0
        ;;
    esac
  done
  return 1
}

create_full_checkpoint() {
  mkdir -p "$CHECKPOINT_ROOT"
  FULL_CHECKPOINT_PATH="$CHECKPOINT_ROOT/full"
  mkdir -p "$FULL_CHECKPOINT_PATH"
  rsync -a \
    --exclude '.git' \
    --exclude '.autofix' \
    --exclude 'node_modules' \
    --exclude 'dist' \
    --exclude 'build' \
    "$PROJECT_ROOT/" "$FULL_CHECKPOINT_PATH/"
}

restore_full_checkpoint() {
  [[ -n "$FULL_CHECKPOINT_PATH" && -d "$FULL_CHECKPOINT_PATH" ]] || return 0
  rsync -a "$FULL_CHECKPOINT_PATH/" "$PROJECT_ROOT/"
}

create_iteration_snapshot() {
  local iteration="$1"
  local snapshot_dir="$SNAPSHOT_ROOT/iter-$iteration"
  local manifest="$snapshot_dir/manifest.tsv"
  mkdir -p "$snapshot_dir"
  : > "$manifest"
  local rel
  for rel in "${EDITABLE_FILES[@]}"; do
    if [[ -f "$PROJECT_ROOT/$rel" ]]; then
      mkdir -p "$snapshot_dir/$(dirname "$rel")"
      cp "$PROJECT_ROOT/$rel" "$snapshot_dir/$rel"
      printf '%s\tpresent\n' "$rel" >> "$manifest"
    else
      printf '%s\tabsent\n' "$rel" >> "$manifest"
    fi
  done

  return 0
}

restore_iteration_snapshot() {
  local iteration="$1"
  local snapshot_dir="$SNAPSHOT_ROOT/iter-$iteration"
  local manifest="$snapshot_dir/manifest.tsv"
  [[ -f "$manifest" ]] || return 0
  while IFS=$'\t' read -r rel state; do
    [[ -z "$rel" ]] && continue
    if [[ "$state" == "present" && -f "$snapshot_dir/$rel" ]]; then
      mkdir -p "$(dirname "$PROJECT_ROOT/$rel")"
      cp "$snapshot_dir/$rel" "$PROJECT_ROOT/$rel"
    elif [[ "$state" == "absent" && -e "$PROJECT_ROOT/$rel" ]]; then
      safe_move_to_trash "$rel"
    fi
  done < "$manifest"

  return 0
}

resolve_backend() {
  if [[ -x "$FALLBACK_BACKEND_DIR/$BACKEND.sh" ]]; then
    BACKEND_WRAPPER="$FALLBACK_BACKEND_DIR/$BACKEND.sh"
    return
  fi

  if command -v "autofix-$BACKEND" >/dev/null 2>&1; then
    BACKEND_WRAPPER="$(command -v "autofix-$BACKEND")"
    return
  fi

  if command -v "$BACKEND" >/dev/null 2>&1; then
    BACKEND_BIN="$(command -v "$BACKEND")"
    return
  fi

  write_result "blocked" "Backend '$BACKEND' is not available." 0
  history_event "setup" "blocked" "Backend '$BACKEND' is not available."
  FINISHED_AT="$(date +%s)"
  write_state "blocked"
  exit 2
}

run_backend() {
  if [[ -n "$BACKEND_WRAPPER" ]]; then
    run_with_timeout "$TIMEOUT_SECONDS" "$BACKEND_WRAPPER" "$PROGRAM_PATH" "$PROJECT_ROOT"
    return
  fi

  local prompt_text
  prompt_text="$(cat "$PROGRAM_PATH")"
  case "$BACKEND" in
    codex)
      run_with_timeout "$TIMEOUT_SECONDS" "$BACKEND_BIN" exec "$prompt_text"
      ;;
    claude)
      run_with_timeout "$TIMEOUT_SECONDS" "$BACKEND_BIN" -p "$prompt_text"
      ;;
    gemini)
      run_with_timeout "$TIMEOUT_SECONDS" "$BACKEND_BIN" -p "$prompt_text"
      ;;
    *)
      return 1
      ;;
  esac
}

validate_secure_origin_contract() {
  if [[ "$EVAL_MODE" != "browser" || "$REQUIRES_SECURE_ORIGIN" != "true" ]]; then
    return 0
  fi

  if [[ -n "${PORTLESS_URL:-}" || -n "${SECURE_LOCAL_URL:-}" ]]; then
    return 0
  fi

  if rg -q 'https://' "$EVAL_PATH"; then
    return 0
  fi

  write_result "blocked" "Browser eval requires a secure origin, but none was configured." 0
  history_event "setup" "blocked" "Secure origin required but not configured."
  FINISHED_AT="$(date +%s)"
  write_state "blocked"
  exit 2
}

validate_result_contract() {
  jq -e '
    (.status as $s | ["pass","fail","error","timeout","plateau","blocked"] | index($s) != null) and
    (.metric_name | type == "string") and
    (.score | type == "number") and
    (.summary | type == "string") and
    (.changed_files | type == "array" and all(.[]; type == "string"))
  ' "$RESULT_PATH" >/dev/null
}

score_is_improved() {
  local candidate="$1"
  if [[ -z "$BEST_SCORE" ]]; then
    return 0
  fi
  awk -v a="$candidate" -v b="$BEST_SCORE" 'BEGIN { exit !(a > b) }'
}

result_meets_success_rule() {
  local status
  local score
  status="$(jq -r '.status' "$RESULT_PATH")"
  score="$(jq -r '.score' "$RESULT_PATH")"
  if [[ "$SUCCESS_RULE_TYPE" == "pass_fail" ]]; then
    [[ "$status" == "pass" ]]
    return
  fi
  awk -v score="$score" -v threshold="$SUCCESS_THRESHOLD" 'BEGIN { exit !(score >= threshold) }'
}

build_related_yaml() {
  if [[ "$#" -eq 0 ]]; then
    printf '[]'
    return
  fi
  printf '['
  local first=1
  local ki
  for ki in "$@"; do
    [[ "$first" -eq 1 ]] || printf ', '
    printf '"%s"' "$ki"
    first=0
  done
  printf ']'
}

create_knowledge_item() {
  local category_dir="$1"
  local category_name="$2"
  local reason="$3"
  local weight="$4"
  local body_title="$5"
  local summary="$6"
  local polarity="$7"
  local now
  local date_slug
  local ki_id
  local filename
  local related_yaml
  local path
  local reused_preview=()
  local reused_ki

  now="$(date +%s)"
  date_slug="$(date +%F)"
  ki_id="ki-$(printf '%s' "${RUN_ID}-${category_name}-${body_title}-${summary}" | shasum -a 256 | awk '{print substr($1,1,16)}')"
  filename="${date_slug}_$(slugify "$body_title").md"
  if [[ -n "${REUSED_KI_IDS[*]-}" ]]; then
    for reused_ki in "${REUSED_KI_IDS[@]}"; do
      reused_preview+=("$reused_ki")
      [[ "${#reused_preview[@]}" -ge 3 ]] && break
    done
  fi
  related_yaml="$(build_related_yaml "${reused_preview[@]}")"
  path="$PROJECT_ROOT/.agent/knowledge/$category_dir/$filename"

  cat > "$path" <<EOF
---
ki_id: "${ki_id}"
category: "${category_name}"
status: "active"
is_consolidated: false
timestamp: ${now}
tenant_domain: "${TENANT_DOMAIN}"
entities: ["autofix", "${BACKEND}", "${OBJECTIVE_TYPE}"]
related_kis: ${related_yaml}
---
# ${body_title}

- Goal: ${GOAL}
- Backend: \`${BACKEND}\`
- Rollback mode: \`${EFFECTIVE_ROLLBACK_MODE}\`
- Iterations executed: ${CURRENT_ITERATION}
- Editable files:
$(for file in "${EDITABLE_FILES[@]}"; do printf '  - `%s`\n' "$file"; done)

## Outcome
${summary}
EOF

  record_memory_outcome "memory_${polarity}" "$ki_id" "$reason" "$weight"
  printf '%s' "$ki_id"
}

capture_run_knowledge() {
  local outcome="$1"
  local result_summary
  result_summary="$(jq -r '.summary' "$RESULT_PATH")"

  if [[ "$outcome" == "pass" ]]; then
    local conclusion_ki
    conclusion_ki="$(create_knowledge_item "conclusions" "conclusion" "autofix_strategy_win" "1.0" "Autofix Result $(slugify "$GOAL")" "$result_summary" "positive")"

    if (( CURRENT_ITERATION > 1 )) || [[ -n "${REUSED_KI_IDS[*]-}" ]]; then
      create_knowledge_item "skill_insights" "skill_insight" "autofix_strategy_win" "1.0" "Autofix Skill Insight $(slugify "$GOAL")" "Reusable adaptation captured after an autofix run. ${result_summary}" "positive" >/dev/null
    fi

    local ki
    if [[ -n "${REUSED_KI_IDS[*]-}" ]]; then
      for ki in "${REUSED_KI_IDS[@]}"; do
        record_memory_outcome "memory_reuse_win" "$ki" "autofix_reuse_win" "1.0"
      done
    fi
  else
    create_knowledge_item "research" "research" "autofix_strategy_loss" "0.5" "Autofix Dead End $(slugify "$GOAL")" "$result_summary" "negative" >/dev/null
    local ki
    if [[ -n "${REUSED_KI_IDS[*]-}" ]]; then
      for ki in "${REUSED_KI_IDS[@]}"; do
        record_memory_outcome "memory_reuse_loss" "$ki" "autofix_reuse_loss" "1.0"
      done
    fi
  fi
}

sync_autofix_outputs_from_worktree() {
  local worktree_dir="$1"
  mkdir -p "$WORKSPACE"
  rsync -a "$worktree_dir/.autofix/" "$WORKSPACE/"
  if [[ -d "$worktree_dir/.agent/knowledge" ]]; then
    mkdir -p "$PROJECT_ROOT/.agent/knowledge"
    rsync -a --exclude '.vectorstore' "$worktree_dir/.agent/knowledge/" "$PROJECT_ROOT/.agent/knowledge/"
  fi

  return 0
}

apply_editable_files_from_worktree() {
  local worktree_dir="$1"
  local rel
  for rel in "${EDITABLE_FILES[@]}"; do
    if [[ -f "$worktree_dir/$rel" ]]; then
      mkdir -p "$(dirname "$PROJECT_ROOT/$rel")"
      cp "$worktree_dir/$rel" "$PROJECT_ROOT/$rel"
    elif [[ -e "$PROJECT_ROOT/$rel" ]]; then
      safe_move_to_trash "$rel"
    fi
  done

  return 0
}

run_in_isolated_worktree() {
  local worktree_root
  local branch_name
  worktree_root="$(mktemp -d "${TMPDIR:-/tmp}/autofix-worktree.XXXXXX")"
  branch_name="autofix/${RUN_ID}"

  git -C "$PROJECT_ROOT" worktree add -b "$branch_name" "$worktree_root" HEAD >/dev/null
  mkdir -p "$worktree_root/.autofix"
  rsync -a "$WORKSPACE/" "$worktree_root/.autofix/"

  local exit_code=0
  if (
    cd "$worktree_root"
    AUTOFIX_INNER_WORKTREE=1 \
    AUTOFIX_RUN_ID="$RUN_ID" \
    AUTOFIX_ROOT="$ROOT" \
    bash "$ROOT/skills/autofix/scripts/autofix-loop.sh" \
      --project-root "$worktree_root" \
      --workspace "$worktree_root/.autofix" \
      --spec "$worktree_root/.autofix/spec.json"
  ); then
    exit_code=0
  else
    exit_code=$?
  fi

  sync_autofix_outputs_from_worktree "$worktree_root"
  if [[ -f "$worktree_root/.autofix/result.json" ]] && jq -e '.status == "pass"' "$worktree_root/.autofix/result.json" >/dev/null 2>&1; then
    apply_editable_files_from_worktree "$worktree_root"
  fi

  git -C "$PROJECT_ROOT" worktree remove --force "$worktree_root" >/dev/null || true
  git -C "$PROJECT_ROOT" branch -D "$branch_name" >/dev/null 2>&1 || true
  return "$exit_code"
}

run_eval() {
  local exit_code=0
  if run_with_timeout "$TIMEOUT_SECONDS" "$EVAL_PATH"; then
    exit_code=0
  else
    exit_code=$?
  fi
  return "$exit_code"
}

ensure_workspace_contract
ensure_memory_baseline
validate_spec
load_spec
choose_effective_mode
write_state "ready"

if [[ "$EFFECTIVE_ROLLBACK_MODE" == "git_worktree" && "$INNER_WORKTREE" != "1" ]]; then
  history_event "setup" "ok" "Switching to isolated git_worktree mode."
  if run_in_isolated_worktree; then
    exit 0
  fi
  exit $?
fi

cd "$PROJECT_ROOT"

validate_secure_origin_contract
resolve_backend
load_memory_context
render_program
if jq -e '. != null' <<< "$STRATEGY_HINT_JSON" >/dev/null 2>&1; then
  history_event "strategy_hint_loaded" "ok" "Loaded optional Hyperlayer strategy hint." "[]" "$(jq -c '{strategy_id, decision_source, confidence, backend_hint, reasoning_effort, autofix_hint}' <<< "$STRATEGY_HINT_JSON")"
fi
history_event "setup" "ok" "Autofix contract validated."
write_state "running"

if [[ "$EFFECTIVE_ROLLBACK_MODE" == "hybrid_safe" ]]; then
  create_full_checkpoint
fi

while (( CURRENT_ITERATION < MAX_ITERATIONS )); do
  CURRENT_ITERATION=$((CURRENT_ITERATION + 1))
  write_state "running"
  history_event "iteration_started" "running" "Starting autofix iteration."

  before_fp="$(mktemp "${TMPDIR:-/tmp}/autofix-before.XXXXXX")"
  after_fp="$(mktemp "${TMPDIR:-/tmp}/autofix-after.XXXXXX")"
  changed_fp="$(mktemp "${TMPDIR:-/tmp}/autofix-changed.XXXXXX")"
  fingerprint_workspace "$before_fp"
  if [[ "$EFFECTIVE_ROLLBACK_MODE" == "hybrid_safe" ]]; then
    create_iteration_snapshot "$CURRENT_ITERATION"
  fi

  if ! run_backend; then
    write_result "error" "Backend invocation failed before evaluation." 0
    if [[ "$EFFECTIVE_ROLLBACK_MODE" == "hybrid_safe" ]]; then
      restore_iteration_snapshot "$CURRENT_ITERATION"
    fi
    [[ -n "$FULL_CHECKPOINT_PATH" ]] && restore_full_checkpoint
    history_event "eval_failed" "error" "Backend invocation failed."
    FINISHED_AT="$(date +%s)"
    write_state "error"
    capture_run_knowledge "error"
    rm -f "$before_fp" "$after_fp" "$changed_fp"
    exit 1
  fi

  fingerprint_workspace "$after_fp"
  detect_changed_paths "$before_fp" "$after_fp" > "$changed_fp"
  if ! validate_changed_paths "$changed_fp"; then
    write_result "error" "Backend modified files outside editable_files." 0
    if [[ "$EFFECTIVE_ROLLBACK_MODE" == "hybrid_safe" ]]; then
      restore_iteration_snapshot "$CURRENT_ITERATION"
    fi
    [[ -n "$FULL_CHECKPOINT_PATH" ]] && restore_full_checkpoint
    FINISHED_AT="$(date +%s)"
    write_state "error"
    capture_run_knowledge "error"
    rm -f "$before_fp" "$after_fp" "$changed_fp"
    exit 1
  fi

  if run_eval; then
    eval_exit_code=0
  else
    eval_exit_code=$?
  fi

  if [[ ! -f "$RESULT_PATH" ]] || ! validate_result_contract; then
    write_result "error" "eval.sh did not produce a valid result.json contract." 0
    if [[ "$EFFECTIVE_ROLLBACK_MODE" == "hybrid_safe" ]]; then
      restore_iteration_snapshot "$CURRENT_ITERATION"
    fi
    history_event "eval_failed" "error" "Invalid result.json contract."
    [[ -n "$FULL_CHECKPOINT_PATH" ]] && restore_full_checkpoint
    FINISHED_AT="$(date +%s)"
    write_state "error"
    capture_run_knowledge "error"
    rm -f "$before_fp" "$after_fp" "$changed_fp"
    exit 1
  fi

  changed_array=()
  while IFS= read -r changed_path; do
    changed_array+=("$changed_path")
  done < "$changed_fp"
  changed_json="$(json_array_from_args "${changed_array[@]}")"
  jq --argjson changed_files "$changed_json" '.changed_files = $changed_files' "$RESULT_PATH" > "$RESULT_PATH.tmp"
  mv "$RESULT_PATH.tmp" "$RESULT_PATH"

  result_status="$(jq -r '.status' "$RESULT_PATH")"
  result_score="$(jq -r '.score' "$RESULT_PATH")"

  if [[ "$eval_exit_code" -eq 0 ]] && result_meets_success_rule; then
    history_event "eval_passed" "pass" "$(jq -r '.summary' "$RESULT_PATH")" "$changed_json"
    if score_is_improved "$result_score"; then
      BEST_SCORE="$result_score"
      BEST_ITERATION="$CURRENT_ITERATION"
      LAST_IMPROVEMENT_ITERATION="$CURRENT_ITERATION"
    fi
    FINISHED_AT="$(date +%s)"
    write_state "passed"
    capture_run_knowledge "pass"
    rm -f "$before_fp" "$after_fp" "$changed_fp"
    exit 0
  fi

  if score_is_improved "$result_score"; then
    BEST_SCORE="$result_score"
    BEST_ITERATION="$CURRENT_ITERATION"
    LAST_IMPROVEMENT_ITERATION="$CURRENT_ITERATION"
  fi

  if (( CURRENT_ITERATION - LAST_IMPROVEMENT_ITERATION >= PLATEAU_WINDOW )); then
    write_result "plateau" "Score stopped improving within the plateau window." "$result_score" "${changed_array[@]}"
    if [[ "$EFFECTIVE_ROLLBACK_MODE" == "hybrid_safe" ]]; then
      restore_iteration_snapshot "$CURRENT_ITERATION"
      if [[ -n "$FULL_CHECKPOINT_PATH" ]]; then
        restore_full_checkpoint
      fi
    fi
    history_event "plateau_detected" "plateau" "Autofix reached the configured plateau window." "$changed_json"
    FINISHED_AT="$(date +%s)"
    write_state "plateau"
    capture_run_knowledge "plateau"
    rm -f "$before_fp" "$after_fp" "$changed_fp"
    exit 1
  fi

  if [[ "$EFFECTIVE_ROLLBACK_MODE" == "hybrid_safe" ]]; then
    restore_iteration_snapshot "$CURRENT_ITERATION"
    history_event "rollback_applied" "ok" "Hybrid-safe rollback applied." "$changed_json"
  fi
  history_event "eval_failed" "$result_status" "$(jq -r '.summary' "$RESULT_PATH")" "$changed_json"
  rm -f "$before_fp" "$after_fp" "$changed_fp"
done

write_result "fail" "Autofix reached max_iterations without success." "${BEST_SCORE:-0}"
if [[ "$EFFECTIVE_ROLLBACK_MODE" == "hybrid_safe" && -n "$FULL_CHECKPOINT_PATH" ]]; then
  restore_full_checkpoint
fi
history_event "run_completed" "fail" "Autofix reached max_iterations."
FINISHED_AT="$(date +%s)"
write_state "failed"
capture_run_knowledge "fail"
exit 1
