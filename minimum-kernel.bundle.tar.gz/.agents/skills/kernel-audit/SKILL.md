---
name: kernel-audit
description: "Audit or critique the Antigravity ops-kernel with current evidence, explicit layer boundaries, and validated claims before recommending changes."
license: Apache-2.0
source: antigravity-project
metadata:
  author: antigravity-project
  version: "1.1.0"
---

# Kernel Audit

## Activation Contract

Use this skill for requests to audit, critique, explain, simplify, or improve the Antigravity ops-kernel, including comparisons between the portable product and the local runtime. It takes precedence over the generic `audit` skill, which is for UI/design review.

Resolve the task as `kernel_audit`. Read:

1. Native canon and current state.
2. `MEMORY.md`, section **How To Audit This Kernel**.
3. `state/read_contract.json`.
4. `.agent/knowledge/.project_dna.md` and only the best targeted architectural KIs.
5. Recent `PROJECT_HISTORY.md` entries and `evals/manifest.json`.
6. `state/kernel-audit-rubric.json`.

Read scripts or runtime surfaces only when they substantiate a specific claim. Treat `~/.gemini/antigravity/brain` as behavioral evidence, never architectural authority.

## Hard Rules

- Separate: portable canon, portable bundle payload, machine-local runtime, generated artifacts, and host data.
- Current repo/runtime evidence outranks memory, generated views, reports, and model inference.
- A resolved or mitigated incident is historical unless reproduced now.
- File count is not operational complexity; use the manifest and executed profiles.
- Performance recommendations require measurements.
- Cross-platform proposals must distinguish portable bootstrap from local tooling.
- Before replacing an architecture, explain its purpose and protected invariant.
- “No change recommended” and “insufficient evidence” are valid conclusions.
- Material counts and statuses must be exact and derived from current authoritative sources; do not write “40+” when the manifest resolves an exact total.
- An open or historical incident is not a confirmed current defect unless reproduced during the audit.
- Do not create or endorse an implementation plan unless the audit-to-plan gate passes.

## Language And Tone

- Write user-facing reports in the user's language. Keep exact identifiers, commands, paths, product names, and precision-critical technical terms unchanged.
- Do not mix English headings with Spanish explanatory prose when the user wrote in Spanish.
- Prefer plain terms such as `observado`, `no reproducido`, `histórico`, `hipótesis`, and `evidencia insuficiente`.
- Avoid praise and promotional wording. Passing checks supports “the evaluated checks passed,” not “the architecture is exceptional, brilliant, superb, fully functional, or universally robust.”
- Explain an unavoidable specialized term the first time it appears.

## Decision Gates

Stop before recommendations when:

- authority or layer is unclear;
- a current defect depends only on an old report;
- a count has not been tied to the active manifest;
- a proposal assumes a host capability that may be absent;
- native and external read profiles are being conflated.
- exact counts were replaced by estimates or rounded language;
- a proposed action does not reference a confirmed current finding;
- the report language or tone obscures the evidence.

Gather targeted evidence or mark the conclusion insufficient. Do not fill gaps with plausible architecture.

## Execution Steps

1. State the audit question and boundaries.
2. Build the evidence matrix:

| Claim | Layer | Status | Current evidence | Confidence |
| --- | --- | --- | --- | --- |
| ... | portable / payload / local / generated / host | observed / inferred / historical | file, command, or test | high / medium / low |

3. Validate all material medium/low-confidence claims.
4. Assign each item a stable identifier and classification:
   - `confirmed`: current behavior reproduced or directly observed;
   - `hypothesis`: plausible but still requires validation;
   - `historical`: ledger or prior report context not reproduced now;
   - `rejected`: contradicted or unsupported.
5. Compare findings against the versioned rubric.
6. Explain the invariant behind any challenged mechanism.
7. Recommend changes only where evidence demonstrates a current gap.
8. Validate the report against `state/kernel-audit-artifact.schema.json`.
9. If implementation is justified, apply the audit-to-plan gate before handing confirmed findings to OpenSpec.

## Output Contract

Return:

1. **Scope and authority**
2. **Evidence matrix**
3. **Confirmed findings**, each with an `F-##` identifier
4. **Hypotheses and historical context**
5. **Rejected or unsupported claims**
6. **Conclusion**: change, no change, or insufficient evidence
7. **Recommendations**, only when linked to confirmed finding identifiers
8. **Next validation**, only when evidence is incomplete

Each implementation recommendation must contain:

- `finding_id`
- current evidence
- expected impact
- acceptance criteria
- rollback or constraints

An implementation plan is allowed only when the conclusion is `changes_recommended`, every proposed action satisfies that traceability contract, and no material uncertainty remains. Otherwise stop at the audit.

## References

- `../../../MEMORY.md`
- `../../../state/read_contract.json`
- `../../../state/kernel-audit-rubric.json`
- `../../../state/kernel-audit-artifact.schema.json`
- `../../../evals/manifest.json`
