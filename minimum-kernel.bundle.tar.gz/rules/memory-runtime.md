# Memory Runtime Rule Pack

## Purpose
Short runtime rule for memory. Normal tasks should not study the memory system; they should use the smallest context that helps solve the user request.

## Golden Path
- Start with the canonical entry file and `.agent/current_state.md`.
- Normal code/docs/UI work reads only target files.
- Bug-like local work may inspect the latest `ERROR_LOG.md` rows as a quick regression guard.
- Architecture/refactor work may inspect latest `PROJECT_HISTORY.md` entries and `.agent/knowledge/.project_dna.md`.
- Memory/kernel work may read `MEMORY.md` and targeted KIs.
- Restore/portable work may read `GEMINI_BLUEPRINTS.md`.

## Live State and Ledgers
- `.agent/current_state.md` is the operational handoff agents read first, capped at 40 lines or 1200 tokens.
- `.agent/current_state.json` is the structured state source used by renderers while fresh.
- `.agent/project_state.json` is generated cache; regenerate it, do not hand-edit it as truth.
- If live-state views disagree, treat state as stale, revalidate repo/runtime facts, and rerender the views.
- `PROJECT_HISTORY.md` is the durable changelog.
- `ERROR_LOG.md` is the incident ledger.

## KI Selection
- Use `scripts/select-memory-context.sh` when it saves time.
- If selector tooling is unavailable, grep targeted active Markdown notes by `tenant_domain`, entities, and task keywords.
- Read `.agent/knowledge/.project_dna.md` before individual KIs when historical memory is needed.
- Load at most 5 KIs or about 1200 tokens; usually 0-3 is enough.

## Capture
- Capture durable lessons, not transcripts or task chatter.
- `fast_local` and tiny edits do not create KIs.
- `standard` and `deep_audit` may run `scripts/capture-ki.sh --suggest-from-current-state --json`, but native KI edits are valid for explicit memory/kernel work.
- Add `--write` only when the suggestion says `should_capture=true`.
- Do not store secrets, raw logs, copied code, hidden reasoning, or full plans.

## Failure Mode
- If memory tooling fails during local work, continue with target files and report the memory fallback briefly.
- For memory/kernel changes, validate state and generated views before closing.
