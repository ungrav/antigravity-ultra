# Skills Arsenal & Trust Rule Pack

## 1. DISCOVERY ORDER & TRIGGERS (MANDATORY)
1. **Registry-first**: `~/.gemini/skills-lock.json` is the canonical runtime inventory and preferred resolution order. Default discovery MUST consult the registry first, not walk every disk scope eagerly.
2. **Manifest as Cache**: `~/.gemini/skills-manifest.json` is generated cache only. Never treat it as the source of truth over disk + lock + curation config.
3. **Tiered Discovery**: Runtime discovery expands in this order:
   - `core` with `defaultDiscovery: true`
   - `supplemental` only if `core` does not produce a strong fit
   - `archived` only under explicit user request or audit/forensic workflows
4. **Disk Access Discipline**: Touch disk to read `SKILL.md` only for shortlisted skills selected from the registry or when validating integrity.
5. **MCP in Parallel**: Inspect live MCP capabilities when relevant, but do not confuse MCP discovery with installed disk skills.
6. **Cross-Language Triggers**: Map natural language (ES) to official English triggers and skill names.
7. **Progressive Semantic Discovery**: Use the depth selected by `auto-pilot-workflow.md`: `lite`, `standard`, or `deep_audit`. Community discovery is semantic and context-aware, not a rigid exact-match triplet.
8. **Semantic Matrix**: Build queries from these dimensions: user wording, provider/tool, pattern/problem, framework/runtime, adjacent alternative, ES/EN equivalent.
9. **Stop Conditions**: Stop when a trusted clear match exists, or after two consecutive redundant/noisy rounds.
10. **Community Trust Gate**: Use `scripts/skill-trust-gate.sh` and `skills-lifecycle-workflow.md` before installing from non-allowlisted sources. The gate uses skills.sh `find-skills` as the external discovery path and never installs during discovery.
11. **Skill Acquisition Gate (Hard Block)**: Search installed/available/community skills before manual creation; create a new skill only when no adequate existing source covers the task and the rejection rationale is recorded.
12. **Registry Sync**: After adding, removing, or moving any installed skill directory, run `~/.gemini/scripts/sync-skills-registry.sh` and then the relevant lifecycle/smoke checks.

## 1.1 PROGRESSIVE DISCOVERY DEPTH
- `lite`: query `core` first. After local registry search fails, use up to 2 focused `npx skills find` queries only if they materially reduce uncertainty.
- `standard`: query `core`, then `supplemental`, then use `scripts/skill-trust-gate.sh discover --task "<task>" --paths "<paths>" --lane standard` to generate a project-context brief and 4-6 skills.sh/find-skills queries when local evidence is insufficient.
- `deep_audit`: query `core`, `supplemental`, then use `scripts/skill-trust-gate.sh discover --task "<task>" --paths "<paths>" --lane deep_audit --force-external` to generate 6-10 skills.sh/find-skills queries distributed across at least 5 semantic dimensions, including alternatives and community terminology.
- Vague synonyms are prohibited. Query coverage must reflect project context, architecture goals, and the concrete problem being solved.
- Creating a skill is forbidden until registry search, semantic search, and sufficient external review have been exhausted.

## 1.2 CAPABILITY ROUTER CONTRACT
- Use `scripts/resolve-capability-context.sh --task "<task>" --paths "<paths>" --lane fast_local|standard|deep_audit --json` before broad skill/MCP discovery for standard or deep work.
- The resolver is read-only. It may select skills, MCP candidates, warnings, and a `Project Standards (auto-resolved)` block; it MUST NOT install skills or enable MCP servers.
- Agent/sub-agent prompts should receive compact rules text, not a request to scan every `SKILL.md`.
- Sub-agents should not load unselected skill bodies unless the compact rules are insufficient and the orchestrator explicitly asks for fallback loading.
- MCPs are capabilities, not skills. Disabled MCPs, secret-bearing MCPs, external writes, or MCP config changes require the tool-policy/external-surface gates before use or activation.
- Persist resolver evidence in `state/run_state.json` fields when useful: `skills_selected`, `skills_considered`, `skills_queries`, `mcp_selected`, `mcp_considered`, and `capability_resolution_status`.

## 1.3 COMPACT RULES / CONFIRM RULES
- ALWAYS prefer project-local skills over global skills when both match.
- ALWAYS inject at most 3-5 selected skills into sub-agent context.
- ALWAYS install new reusable project skills into `.agents/skills/` unless the user explicitly requests a global install.
- ALWAYS run `scripts/skill-trust-gate.sh audit` before installing a community skill; use `approve` only after scanner results and source review justify the risk.
- NEVER use `--global`, write global skill dirs, or mutate global MCP config from an inferred preference.
- NEVER load the entire skill arsenal to solve a task that already has a clear local match.
- CONFIRM before dependency installs, live community skill acquisition with warnings, global skill installs, MCP enable/disable, secret-bearing MCP use, or external/public writes.

## 2. LOCATION SEMANTICS & TIERS
- `.agents/skills/`, `.gemini/skills/`, and `.agent/skills/` are project scopes. They do not count toward the global runtime budget.
- `~/.gemini/antigravity/skills/` and `~/.gemini/skills/` are the controlled global scopes.
- `~/.codex/skills/` and `~/.agents/skills/` are external-managed global scopes. They stay indexed, but they do not define the controlled global budget.
- Preserve the 7 physical scopes exactly as-is. For reasoning and cleanup only, collapse them into 4 runtime classes: project, controlled-global, external-managed, and live discovery.
- Tier semantics:
  - `core`: available in default runtime discovery
  - `supplemental`: valid and searchable on expansion, but excluded from default discovery
  - `archived`: excluded from default discovery and community recommendation, preserved only for explicit invocation or audits
- Controlled global budget:
  - `essential <= 25`
  - `useful <= 80`
  - the rest becomes `noise -> archived`
- External-managed skills are hidden from default discovery unless they are explicit `required` / `explicitCore` exceptions.
- New project-specific skills default to `.agents/skills/`.
- New global skills default to `~/.gemini/antigravity/skills/` only if they are reusable across many projects.
- `fp-*` / `fp-ts-*` are `project-only`. Azure, persona/roleplay, and vendor-locked stacks do not belong in the controlled global runtime by default.

## 3. STRUCTURE, DUPLICATES, AND ACTIVATION
- Every skill folder MUST contain `SKILL.md`.
- `SKILL.md` MUST expose YAML frontmatter with a clear `description`. `name` is optional and defaults to the folder name.
- Discovery follows progressive disclosure: the agent first sees registry metadata, then reads the full `SKILL.md` only when relevant.
- Optional `scripts/`, `examples/`, and `resources/` are allowed. Prefer invoking scripts with `--help` first instead of loading their entire source unless inspection is necessary.
- Duplicate policy:
  - same skill ID + same hash across scopes -> keep the preferred instance and mark lower-priority copies as `shadowed`
  - same skill ID + different hashes -> keep the preferred instance, mark the rest as `divergent_duplicate`, and require manual review
- High-confidence cleanup candidates include shadowed compatibility copies, malformed skills, disallowed global families, and policy-archived controlled-global noise.
- Controlled-global noise is moved into `_DEPRECATED_TRASH/skills-cleanup/<date>/`. External-managed scopes are not moved automatically.

## 4. SKILL TRUST POLICY
- AUTO-install ONLY for allowlisted trusted sources.
- Non-allowlisted -> CONFIRM.
- Use pinned references (owner/repo@tag-or-commit).
- Run package-backed skill tooling through `scripts/dependency-safety-adapter.sh`; use exact package versions, never `@latest`, and preserve the 24h/72h freshness gate.
- Snapshot + rollback mandatory before dynamic install/update.
- Record through `scripts/logctl.sh history` or `scripts/logctl.sh incident` only when `project_ledgers=true`.
