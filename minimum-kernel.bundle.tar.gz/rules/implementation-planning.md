# Implementation Planning Rule Pack

## 1. HARD GATE
- Only sensitive or high-impact risk-bearing mutating tasks MUST create or update a formal implementation plan in the current host/session before implementation begins.
- Do not create, update, or depend on `./implementation_plan.md` as a live project artifact.
- For plan-event gated work, the project persists only minimal `plan_state` metadata and an approved-plan receipt reference; the full plan body stays in the producing host/session.
- The plan is blocking only when this rule marks the task plan-gated: no dependency changes, migrations, architecture/security/data mutations, or other sensitive changes until the user approves the plan/receipt.
- For `standard` or `deep_audit` work, the plan MUST be grounded in the current pre-plan intelligence evidence (skills checked, research performed, and governance restrictions already discovered).
- Discovery, reading, inventory, baseline measurements, and verification of the current state are allowed before approval.
- If scope changes materially after approval, revise the plan and obtain renewed approval.

## 2. WHEN THE PLAN IS MANDATORY
Treat the task as risk-bearing if any of these apply:
- The request touches architecture, auth, storage, API contracts, migrations, deployment/release, MCP runtime, memory/RAG internals, blueprints, core scripts, dependencies, external integrations, or security-sensitive configuration.
- The request introduces or replaces dependencies, services, models, or infrastructure.
- The implementation needs phased execution across unrelated modules, rollback thinking beyond local revert, or explicit migration/deploy/release validation.
- The user is asking for a migration, substantial bug fix with uncertain root cause, architecture change, system-wide behavior change, or breaking change.
- The touched surface expands beyond a tightly related 2-3 file local cluster and creates broad multi-module, release, data, or rollback risk.

## 3. EXEMPTIONS
The hard gate may be skipped only for:
- Read-only analysis or explanation.
- Tiny docs or typo fixes with no behavioral impact.
- Copy edits, local renames, and one-line or similarly bounded mechanical changes with no structural, runtime, tooling, or dependency impact.
- Pure formatting changes.
- `fast_local` changes resolved by the router when they remain local, obvious, and tightly bounded.
- `fast_local` bugfixes, tiny features, or minor functional tweaks that stay within a tightly related 1-3 file local cluster and outside root config, auth, storage, API contracts, migrations, build tooling, CI/CD, deployment, MCP runtime, memory, blueprints, core scripts, dependency, external integration, and breaking-change surfaces.
- `standard_low` bounded local features/refactors/bugfixes outside sensitive surfaces: use a short chat/session receipt when useful, never a long-form plan body and never mandatory lifecycle events.
- `fast_local` work does not create `PROJECT_HISTORY.md`, `ERROR_LOG.md`, or KI entries unless it reveals a real incident, durable decision, reusable pattern, or handoff-worthy verification change.

If in doubt about sensitive surface impact, require the formal plan. If the only doubt is local implementation detail inside a bounded 1-3 file cluster, prefer `standard_low` receipt plus targeted verification without lifecycle events.

## 4. REQUIRED SHAPE OF THE IMPLEMENTATION PLAN
For `standard_low`, use a short receipt instead of a full long-form plan body when the change is bounded and local but still benefits from explicit alignment. The receipt must name objective, affected surfaces/files, validation commands, rollback/constraints, and approval/intent source. It does not require `plan-event.schema.json` unless the task also touches a plan-event gated surface.

For `standard_high` and `deep_audit`, the full plan body remains host/session-only and MUST be in Spanish with these sections exactly:
1. `Objetivo y resultado exacto`
2. `Estado actual y restricciones`
3. `Archivos/módulos impactados`
4. `Fases atómicas`
5. `Cambios concretos por fase`
6. `Validación y pruebas`
7. `Riesgos, rollback y dependencias`

## 5. REQUIRED DETAIL LEVEL
For `standard_high` and `deep_audit`, each atomic phase MUST include:
- exact action
- file or target affected
- expected result
- validation command, test, or evidence
- explicit risk or rollback note when applicable

Additionally:
- `Estado actual y restricciones` MUST state which skills were evaluated or reused, what investigation was performed, which sources were consulted, and which security/governance constraints are already in force.
- `Riesgos, rollback y dependencias` MUST include relevant supply-chain risk, external skill risk, important alternatives discarded, and any exception that would still require explicit human confirmation.

Prohibited:
- vague steps like “implementar X” with no files or validation
- hidden assumptions not written in the plan
- giant undifferentiated phases that bundle unrelated work
- plans that skip tests, rollback, or affected files

## 6. EXECUTION CONTRACT
- `auto-pilot-workflow.md` and `feature-development-workflow.md` must enforce this rule.
- The agent may use discovery workflows and skills to prepare the plan, but may not mutate the target implementation before approval.
- The project-level source for this gate is `.agent/current_state.json.plan_state`, mirrored into `.agent/current_state.md` and `.agent/project_state.json`, not a mutable plan file in the repo.
- Every transition of that mirror for plan-event gated work MUST come from an explicit host event. Codex should use `scripts/emit-codex-plan-event.sh`, Antigravity should use `scripts/emit-antigravity-plan-event.sh`, and `scripts/planctl.sh` remains manual recovery/debug tooling.
- Non-sensitive `fast_local` / `standard_low` work does not have to create or update `plan_state`.
- The kernel never infers `draft`, `pending_user`, `approved`, or `superseded` from free-form chat alone. If the agent just presented a bounded plan and the user clearly approves it in chat, continue only after the host or adapter records the corresponding structured event.
- If adapter-driven approval fails because `plan_state` drifted or no presented plan is visible, re-present a compact receipt, run `scripts/planctl.sh recover-presented --content-hash <hash> --summary "<summary>"` as manual fallback, and wait for a fresh explicit approval event before implementation.
- `recover-presented` is a recovery transition only: it may rebuild `required -> drafted -> presented`, but it must never approve, implement, create a decision KI, or treat old chat approval as still active.
- `source_host` and `producer_agent` are different on purpose: the host owns state authority; the producer owns the plan body.
- `plan_approved` must carry an explicit `approval_source` such as `host_ui_button`, `host_ui_command`, or `chat_structured_command`. A conversational “ok” counts only after the host or adapter records that structured event; do not require extra visible ceremony from the user.
- If the user comments on the plan or reduces/increases scope, update the plan first, then continue only after approval.
- If the user asks to review/audit a plan, or routing marks the task as `deep_audit`, perform a findings-first plan audit before implementation. The audit output order is mandatory:
  1. critical findings
  2. hidden assumptions
  3. reuse/discovery or governance omissions
  4. missing validations
  5. insufficient rollback coverage
  6. corrected proposal
  7. how Codex would execute it and why

## 7. HOST/PROJECT PERSISTENCE CONTRACT
- The full plan lives only in the current host/session.
- Persist only `.agent/current_state.json.plan_state` for formal plan-event gated work. Render `.agent/current_state.md` from it, regenerate `.agent/project_state.json`, and keep `state/run_state.json` as runtime trace/cache fields.
- `plan_state` may contain `required`, `source`, `status`, `updated_at`, `content_hash`, `memory_synced`, `next_action`, `producer_agent`, and `receipt_ref`; it must never contain the plan body or internal host paths.
- For schema v3, `plan_approved` must include a lean `durable_capture.receipt` with objective, affected surfaces, impacted files, phases, validation commands, rollback, and constraints. The receipt is durable evidence, not the hidden plan body.
- For sensitive work that deliberately uses a `standard_low` lifecycle receipt, `emit-antigravity-plan-event.sh` and `emit-codex-plan-event.sh` may receive `--receipt-json` / `--receipt-file` without `--durable-capture-json`; they synthesize the compatible durable capture and do not write a plan body into the repo.
- Canonical event names are: `plan_required_resolved`, `plan_drafted`, `plan_presented`, `plan_approved`, `plan_superseded`, `plan_audit_completed`, and `plan_reset`.
- `event_id` is mandatory and idempotent. Repeated event ids are `no-op`; out-of-sequence transitions must fail closed.
- `Antigravity` uses `scripts/emit-antigravity-plan-event.sh`, `Codex` uses `scripts/emit-codex-plan-event.sh`, and manual/runtime recovery may use `scripts/planctl.sh`. All feed the same ingestor contract without duplicating the full plan artifact.
- `scripts/planctl.sh recover-presented` is the only supported manual fallback for desynced presented plans. It emits existing canonical events and leaves `plan_state.status = pending_user`.
- Approved plans create a durable `decision` KI only when the resulting decision is reusable or materially affects delivery.
- Material revisions to an already approved plan create a new `decision` KI and supersede the older one when both are durable.
- Plan audits and findings-first reviews create a `conclusion` KI when the result is durable.
- Draft plans do not create KIs by default.
- If the user explicitly requests an exported copy, write it under a different Spanish filename with timestamp; never as `implementation_plan.md`.
