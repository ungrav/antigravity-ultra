# Agent Router: OpenSpec + MCP Rule Pack

## 1. Routing intent
- Default to the smallest workflow that can answer correctly; do not run every capability just because it exists.
- Automatic means: once the trigger matches and the local inventory reports `available`, the agent invokes the capability without asking. If it is unavailable or degraded, use the catalog fallback and report `PARTIAL` for that capability.
- Use OpenSpec as the spec-driven layer for complex, public, risky, or ambiguous delivery work.
- Use MCPs as just-in-time capabilities: available at hand, activated by task class and risk.

## 2. Implementation readiness gate
- For non-trivial mutation, follow `INSPECT -> CLASSIFY -> DISCOVER SKILLS -> DOCUMENT -> CLARIFY -> SPECIFY -> APPROVE -> APPLY -> VERIFY`.
- Model knowledge is a starting hypothesis, not sufficient evidence for external technology behavior or specialized implementation procedure.
- Before design, inspect applicable installed skills even when the agent believes it already knows the procedure. Record skills checked, used, and discarded with a short reason.
- If no installed skill covers a needed capability, use local registry resolution and `scripts/skill-trust-gate.sh discover` before inventing a replacement. Discovery never authorizes installation; audit, trust approval, and confirmation rules still apply.
- When work depends on a library, SDK, framework, API, CLI, or cloud service whose current or versioned behavior matters, use Context7 even when the technology is familiar. Identify the local version first and compare current documentation with repository code and configuration.
- If Context7 is unavailable or insufficient, consult primary official documentation. If current behavior still cannot be verified, report `PARTIAL`; never silently promote model memory to evidence.
- After inspection, skills, and documentation, use OpenSpec explore or ask one concise question when material requirements, acceptance criteria, compatibility, rollout, or trade-offs remain unresolved.
- A plan with material `Open Questions`, critical assumptions, inconsistent artifacts, or missing approval is not apply-ready.
- Before non-trivial mutation, emit this receipt:

```text
READINESS
Objective: ...
Acceptance criteria: ...
Repository evidence: ...
External technologies and versions: ...
Skills checked/used: ...
Documentation consulted: ...
Reusable solution selected: ...
Open questions: none
OpenSpec change: ...
Approval: confirmed
READY TO APPLY: yes|no
```

- `READY TO APPLY: no` prohibits edits, installs, migrations, and configuration mutation. Continue with inspection, skill discovery, documentation, exploration, or clarification instead.
- Material scope changes after approval require revised OpenSpec artifacts, a refreshed receipt, and renewed approval.
- `fast_local` work remains proportional: an obvious, reversible, tightly bounded local change may skip the formal receipt, but must still inspect the target, preserve user changes, and verify the result.

## 3. Workflow lanes
- `fast_local`: simple questions, targeted reads, tiny docs/copy edits, or obvious 1-file fixes. Do not create OpenSpec changes, Graphify maps, or browser sessions unless directly requested.
- `standard`: bounded bugfixes/features/refactors across a small related surface. Use Serena and/or Context7 automatically when their triggers below match.
- `spec_driven`: features, public behavior changes, architecture/API/data/auth/payment/storage changes, dependency/tooling changes, broad refactors, or unclear multi-file work. Create or update an OpenSpec change before implementation.
- `kernel_audit`: critiques or improvement reviews of the ops-kernel. Resolve the dedicated read context and load the project `kernel-audit` skill before making system-wide claims or proposing implementation.
- Kernel-audit reports use the user's language consistently, exact current facts, and neutral evidence wording. They distinguish confirmed, hypothetical, historical, and rejected claims.
- Kernel audit does not imply implementation planning. Handoff to OpenSpec is permitted only when the conclusion is `changes_recommended` and every proposed action references a confirmed current finding with evidence, impact, acceptance criteria, and rollback/constraints.
- `deep_map`: large or unfamiliar repos, cross-cutting refactors, unclear ownership, or high blast-radius work. Use Graphify/repo-map first, then OpenSpec if implementation will proceed.
- `ui_verify`: web UI behavior, visual regressions, route flows, accessibility smoke checks, or browser-specific bugs. Use Playwright MCP for verification evidence.

## 4. Automatic trigger matrix
Use this matrix before doing broad reads or implementation. `MUST` means use automatically when available; do not ask first.

| Capability | MUST trigger automatically | SHOULD trigger | SKIP by default |
| --- | --- | --- | --- |
| Kernel audit | Audit/critique of the ops-kernel; evaluation of Antigravity architecture or complexity; recommendations to improve the kernel; portable-product versus local-runtime comparison. | Any broad claim about kernel health, authority, portability, or operational complexity. | Ordinary code/security/UI audits outside the ops-kernel and small local tasks. |
| Project memory | “remember/recall”, “what did we decide”, “why did we do X”, prior incidents, or explicit historical/project-decision context. | Architecture work where prior decisions may constrain the change. | Small local tasks, known target files, and questions with no historical dependency. |
| OpenSpec | User asks for feature/spec/proposal/plan; change affects public behavior, API/data/auth/payment/storage, architecture, dependencies/tooling, deploy/release, or unrelated multi-file work. | Ambiguous acceptance criteria or implementation path after targeted inspection. | Simple answers, typos, formatting, small local fixes, targeted read-only analysis. |
| Serena | Symbol-level code task touching 2+ files; refactor; “where is this implemented?”; call hierarchy; rename/extract/move; semantic edit safer than grep. | Medium bugfix where ownership/callers are unclear. | Plain docs, config-only edits, one obvious file, no code navigation needed. |
| Context7 | Implementing/configuring/debugging/reviewing code that depends on a library, SDK, framework, CLI, API, or cloud service with version/current behavior, even when the agent already knows the technology. | Before changing dependency-sensitive examples, config, imports, or generated setup. | Pure local business logic with no external API/library uncertainty. |
| Playwright | Web UI change; browser bug; route/form/modal/navigation behavior; visual/accessibility smoke; after significant frontend changes with known local URL. | Validate acceptance of UI flows before reporting PASS. | Backend-only, docs-only, non-UI code, no runnable/known web target. |
| Graphify | Large/unfamiliar repo orientation; architecture map; blast-radius/dependency impact; cross-cutting refactor; repeated broad questions over code/docs; expected exploration of 4+ unrelated areas. | Before OpenSpec for a broad change in a repo the agent cannot summarize confidently. | Small repo/task, targeted file known, one local feature/bugfix, or graph not built and setup would exceed task value. |

## 5. Trigger precedence
- If multiple triggers match, use only the minimal useful chain:
  1. Project memory for historical decisions, prior incidents, and “why”.
  2. Kernel audit skill and rubric for ops-kernel critiques.
  3. Context7 for external-version uncertainty.
  4. Graphify for broad repo map or blast radius.
  5. Serena for semantic code navigation/editing.
  6. OpenSpec for spec-driven planning when the work is complex/risky/public.
  7. Playwright for web UI verification after or during implementation.
- Project memory and Graphify are complementary: memory explains prior decisions; Graphify verifies current structure and impact.
- Do not run Graphify before Serena when the task already names a specific file/symbol and the repo area is clear.
- Do not run Playwright before implementation unless the task is to reproduce/debug an existing UI issue.
- Do not ask “should I use X?” when a trigger matches; use it or report why it was unavailable.

## 6. OpenSpec gate
Use OpenSpec when any of these are true:
- The request changes requirements, user-visible behavior, APIs, data models, auth, payments, permissions, deploy/release behavior, or architecture.
- The work spans unrelated modules or needs phased delivery.
- The user asks for SDD, OpenSpec, `/opsx`, a proposal, or an implementation plan for a real change.
- The agent cannot state acceptance criteria confidently from the prompt and repo facts.

Minimum OpenSpec shape:
- `openspec/changes/<change-id>/proposal.md` for intent and scope.
- `design.md` only when technical decisions/tradeoffs are non-trivial.
- `tasks.md` with implementation and verification steps.
- Spec deltas under `openspec/changes/<change-id>/specs/` for changed capabilities.
- Artifacts for non-trivial implementation must record repository evidence, skills evaluated, documentation consulted, resolved decisions, reuse choice, validation, and rollback.

Do not use OpenSpec for routine answers, one-file mechanical changes, formatting, or local typo/docs edits unless requested.

## 7. Clarifying-question gate
Before mutating, stop and ask one concise question when:
- There are two or more plausible implementations with meaningful tradeoffs.
- Acceptance criteria, target surface, migration behavior, rollout, or compatibility is unclear.
- The change is irreversible, secret-bearing, externally visible, security-sensitive, or expensive to verify.
- Confidence in the implementation path is below 0.75 after targeted repo inspection and triggered tools.

Do not ask when repo conventions make the answer obvious, the action is local/reversible, or OpenSpec/host plan already captured the decision.

## 8. MCP activation policy
- Refresh `.kernel/capabilities.local.json` with `scripts/manage-capabilities.sh scan` when installed capability state may have changed.
- Serena: use automatically for semantic symbol navigation, call hierarchy, safe code edits, and refactors where grep/read would be noisy. The MCP launch must include `start-mcp-server` and project auto-detection.
- Context7: the minimal tier configures the official remote endpoint. Use it automatically to revalidate current/versioned docs even for familiar technologies; never send secrets or proprietary source snippets. Network failure is `degraded`; use primary official documentation or report `PARTIAL` rather than relying only on model knowledge.
- Playwright: use automatically for browser/UI verification, screenshots, route flows, DOM behavior, and post-change smoke tests when a runnable target is known.
- Graphify: use automatically when installed for large or unfamiliar repositories, architecture maps, blast-radius analysis, or repeated questions over broad code/docs. Keep `graphify-out/` local until the user or repository policy approves versioning.
- OpenSpec is a CLI/spec workflow integration, not an MCP. Initialize its official Antigravity skills/workflows per project when the user chooses the capability.

The portable payload contains capability metadata only. It never contains third-party packages, binaries, local MCP configuration, or launchers. Optional installs remain CONFIRM unless explicitly requested and routed through the dependency-safety guard using an exact approved version.
