#!/usr/bin/env bash
set -euo pipefail

ROOT="$HOME/.gemini"
TRACE_FILE=""
RUN_ID=""
EVENT_TYPE=""
ACTOR=""
PHASE=""
STATUS=""
WORKFLOWS=""
CHECKS=""
NOTES=""
PRIMARY_WORKFLOW=""
HOOK_STAGE=""
GUARDRAIL_DECISION=""
METADATA_JSON="{}"

usage() {
  cat <<'EOF'
Usage:
  emit-trace-event.sh [--root PATH] [--trace-file PATH] --run-id ID --event-type TYPE --actor NAME --phase PHASE --status STATUS --workflows CSV --checks CSV [--notes CSV] [--primary-workflow FILE] [--hook-stage STAGE] [--guardrail-decision AUTO|CONFIRM|BLOCK] [--metadata-json JSON]
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --root) ROOT="$2"; shift 2 ;;
    --trace-file) TRACE_FILE="$2"; shift 2 ;;
    --run-id) RUN_ID="$2"; shift 2 ;;
    --event-type) EVENT_TYPE="$2"; shift 2 ;;
    --actor) ACTOR="$2"; shift 2 ;;
    --phase) PHASE="$2"; shift 2 ;;
    --status) STATUS="$2"; shift 2 ;;
    --workflows) WORKFLOWS="$2"; shift 2 ;;
    --checks) CHECKS="$2"; shift 2 ;;
    --notes) NOTES="$2"; shift 2 ;;
    --primary-workflow) PRIMARY_WORKFLOW="$2"; shift 2 ;;
    --hook-stage) HOOK_STAGE="$2"; shift 2 ;;
    --guardrail-decision) GUARDRAIL_DECISION="$2"; shift 2 ;;
    --metadata-json) METADATA_JSON="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unexpected argument: $1" >&2; usage; exit 1 ;;
  esac
done

[[ -n "$RUN_ID" && -n "$EVENT_TYPE" && -n "$ACTOR" && -n "$PHASE" && -n "$STATUS" && -n "$WORKFLOWS" && -n "$CHECKS" ]] || {
  usage
  exit 1
}

TRACE_FILE="${TRACE_FILE:-$ROOT/state/traces/observability.jsonl}"
mkdir -p "$(dirname "$TRACE_FILE")"

csv_to_json_array() {
  local raw="$1"
  jq -cn --arg raw "$raw" '$raw | split(",") | map(gsub("^\\s+|\\s+$";"")) | map(select(length > 0))'
}

workflows_json="$(csv_to_json_array "$WORKFLOWS")"
checks_json="$(csv_to_json_array "$CHECKS")"
notes_json="$(csv_to_json_array "$NOTES")"

event_json="$(jq -cn \
  --argjson schema_version 2 \
  --arg run_id "$RUN_ID" \
  --arg timestamp "$(date -u +"%Y-%m-%dT%H:%M:%SZ")" \
  --arg phase "$PHASE" \
  --arg event_type "$EVENT_TYPE" \
  --arg actor "$ACTOR" \
  --arg status "$STATUS" \
  --arg primary_workflow "$PRIMARY_WORKFLOW" \
  --arg hook_stage "$HOOK_STAGE" \
  --arg guardrail_decision "$GUARDRAIL_DECISION" \
  --argjson workflows "$workflows_json" \
  --argjson checks "$checks_json" \
  --argjson notes "$notes_json" \
  --argjson metadata "$METADATA_JSON" \
  '{
    schema_version: $schema_version,
    run_id: $run_id,
    timestamp: $timestamp,
    phase: $phase,
    event_type: $event_type,
    actor: $actor,
    status: $status,
    workflows: $workflows,
    checks: $checks,
    notes: $notes
  }
  + (if $primary_workflow != "" then {primary_workflow: $primary_workflow} else {} end)
  + (if $hook_stage != "" then {hook_stage: $hook_stage} else {} end)
  + (if $guardrail_decision != "" then {guardrail_decision: $guardrail_decision} else {} end)
  + (if ($metadata | type) == "object" and ($metadata | length) > 0 then {metadata: $metadata} else {} end)')"

printf '%s\n' "$event_json" >> "$TRACE_FILE"
printf '%s\n' "$event_json"
