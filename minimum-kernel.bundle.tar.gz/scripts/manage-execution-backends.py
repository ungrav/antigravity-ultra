#!/usr/bin/env python3
"""Discover, qualify, and route optional execution backends without persisting secrets."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
from typing import Any
from urllib import error, request


RISK_ORDER = {"low": 0, "medium": 1, "high": 2}
SECRET_KEYS = {"api_key", "apikey", "authorization", "password", "secret", "secret_key", "token", "access_token"}


def utc_iso(epoch: float | None = None) -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() if epoch is None else epoch))


def read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return default


def write_json_private(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(f"{path.name}.{os.getpid()}.tmp")
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8")
    os.chmod(temp, 0o600)
    temp.replace(path)
    os.chmod(path, 0o600)


def json_pointer(value: Any, pointer: str) -> Any:
    current = value
    for raw in pointer.strip("/").split("/") if pointer.strip("/") else []:
        key = raw.replace("~1", "/").replace("~0", "~")
        if isinstance(current, list):
            current = current[int(key)]
        elif isinstance(current, dict):
            current = current[key]
        else:
            raise KeyError(pointer)
    return current


def resolve_secret(auth: dict[str, Any]) -> str | None:
    reference = auth.get("secret_ref") if isinstance(auth, dict) else None
    if not isinstance(reference, dict):
        return None
    source = reference.get("source")
    if source == "env":
        value = os.environ.get(str(reference.get("name", "")), "")
        return value or None
    if source == "json_file":
        path = Path(str(reference.get("path", ""))).expanduser()
        data = read_json(path, {})
        try:
            value = json_pointer(data, str(reference.get("json_pointer", "")))
        except (KeyError, IndexError, ValueError, TypeError):
            return None
        return str(value) if value else None
    return None


def redact(value: Any, secrets: list[str]) -> Any:
    if isinstance(value, dict):
        out: dict[str, Any] = {}
        for key, item in value.items():
            if key.casefold() in SECRET_KEYS:
                out[key] = "[REDACTED]"
            else:
                out[key] = redact(item, secrets)
        return out
    if isinstance(value, list):
        return [redact(item, secrets) for item in value]
    if isinstance(value, str):
        text = value
        for secret in secrets:
            if not secret:
                continue
            if text == secret or text == f"Bearer {secret}":
                return "[REDACTED]"
            if len(secret) >= 8:
                text = text.replace(secret, "[REDACTED]")
        return text
    return value


def merge_backends(defaults: list[dict[str, Any]], overrides: list[dict[str, Any]]) -> list[dict[str, Any]]:
    merged = {str(item["id"]): json.loads(json.dumps(item)) for item in defaults if isinstance(item, dict) and item.get("id")}
    for item in overrides:
        if not isinstance(item, dict) or not item.get("id"):
            continue
        backend_id = str(item["id"])
        base = merged.get(backend_id, {})
        base.update(item)
        if isinstance(merged.get(backend_id, {}).get("auth"), dict) and isinstance(item.get("auth"), dict):
            auth = dict(merged[backend_id]["auth"])
            auth.update(item["auth"])
            base["auth"] = auth
        merged[backend_id] = base
    return [merged[key] for key in sorted(merged)]


def local_paths(root: Path, defaults: dict[str, Any], explicit_overrides: str | None = None) -> dict[str, Path]:
    configured = defaults.get("local_files", {})
    values = {key: root / str(value) for key, value in configured.items()}
    if explicit_overrides:
        values["overrides"] = Path(explicit_overrides).expanduser().resolve()
    return values


def http_headers(auth: dict[str, Any], secrets: list[str]) -> tuple[dict[str, str], bool]:
    kind = str(auth.get("kind", "none"))
    if kind == "none":
        return {"Content-Type": "application/json"}, True
    secret = resolve_secret(auth)
    if not secret:
        return {"Content-Type": "application/json"}, False
    secrets.append(secret)
    header = "Authorization" if kind == "bearer" else str(auth.get("header", "X-API-Key"))
    value = f"Bearer {secret}" if kind == "bearer" else secret
    return {"Content-Type": "application/json", header: value}, True


def http_json(url: str, headers: dict[str, str], payload: dict[str, Any] | None = None, timeout: float = 3.0) -> tuple[int, Any, str | None, float]:
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = request.Request(url, data=data, headers=headers, method="POST" if payload is not None else "GET")
    started = time.monotonic()
    try:
        with request.urlopen(req, timeout=timeout) as response:
            raw = response.read()
            return response.status, json.loads(raw or b"{}"), None, (time.monotonic() - started) * 1000
    except error.HTTPError as exc:
        raw = exc.read()
        try:
            body = json.loads(raw or b"{}")
        except json.JSONDecodeError:
            body = {}
        message = str(body.get("error") or body.get("message") or f"HTTP {exc.code}")
        return exc.code, body, message, (time.monotonic() - started) * 1000
    except (error.URLError, TimeoutError, OSError) as exc:
        return 0, {}, str(exc), (time.monotonic() - started) * 1000


def provider_for(model_id: str, fallback: str) -> str:
    folded = model_id.casefold()
    if "claude" in folded:
        return "anthropic"
    if "gemini" in folded:
        return "google"
    if folded.startswith("gpt") or "gpt-oss" in folded:
        return "openai"
    if "qwen" in folded:
        return "qwen"
    if "minimax" in folded:
        return "minimax"
    if "glm" in folded:
        return "zhipu"
    if "kimi" in folded:
        return "moonshot"
    if "deepseek" in folded:
        return "deepseek"
    return fallback


def artifact_fingerprint(model_id: str, provider: str, privacy: str) -> str:
    normalized = model_id.casefold()
    normalized = re.sub(r"\.(gguf|safetensors)$", "", normalized)
    tokens = [item for item in re.split(r"[^a-z0-9.]+", normalized) if item]
    ignored = re.compile(r"^(mlx|gguf|4bit|8bit|16bit|fp16|bf16|q\d.*|iq\d.*)$")
    core = "-".join(item for item in tokens if not ignored.match(item))
    identity = core if privacy == "local" else f"{provider}:{core}"
    return "sha256:" + hashlib.sha256(identity.encode("utf-8")).hexdigest()[:20]


def model_entry(backend: dict[str, Any], raw: dict[str, Any], model_id: str) -> dict[str, Any]:
    kind = str(raw.get("type") or raw.get("object") or "generation")
    if "embed" in model_id.casefold() or "embedding" in kind.casefold():
        capabilities = ["embedding"]
    else:
        capabilities = ["generation"]
        if backend.get("kind") == "cli_harness":
            capabilities += ["coding", "review", "tool_use"]
    privacy = str(backend.get("privacy", "remote"))
    if privacy == "mixed":
        privacy = "remote" if model_id.casefold().endswith(":cloud") else "local"
    provider = provider_for(model_id, str(backend.get("provider", "unknown")))
    state = raw.get("state")
    if state is None and isinstance(raw.get("loaded_instances"), list):
        state = "loaded" if raw["loaded_instances"] else "not-loaded"
    return {
        "ref": f"{backend['id']}:{model_id}",
        "backend_id": backend["id"],
        "model_id": model_id,
        "display_name": str(raw.get("display_name") or raw.get("name") or model_id),
        "provider": provider,
        "engine": backend.get("engine"),
        "kind": kind,
        "state": state or "unknown",
        "privacy": privacy,
        "resource_group": backend.get("resource_group"),
        "capabilities": capabilities,
        "artifact_fingerprint": artifact_fingerprint(model_id, provider, privacy),
        "metadata": {
            key: raw[key]
            for key in ("arch", "architecture", "compatibility_type", "quantization", "params_string", "size", "size_bytes")
            if key in raw
        },
    }


def parse_models(backend: dict[str, Any], body: Any) -> list[dict[str, Any]]:
    raw_models: list[Any] = []
    if isinstance(body, dict) and isinstance(body.get("data"), list):
        raw_models = body["data"]
    elif isinstance(body, dict) and isinstance(body.get("models"), list):
        raw_models = body["models"]
    results: list[dict[str, Any]] = []
    for raw in raw_models:
        if isinstance(raw, str):
            raw = {"id": raw}
        if not isinstance(raw, dict):
            continue
        model_id = str(raw.get("id") or raw.get("key") or raw.get("name") or raw.get("model") or "").strip()
        if model_id:
            results.append(model_entry(backend, raw, model_id))
    return results


def command_version(command: str) -> tuple[str | None, str | None]:
    executable = shutil.which(command)
    if not executable:
        return None, None
    try:
        result = subprocess.run([executable, "--version"], capture_output=True, text=True, timeout=15)
        output = (result.stdout or result.stderr).strip().splitlines()
        return executable, output[0] if output else None
    except (OSError, subprocess.SubprocessError):
        return executable, None


def wrapper_metadata(executable: str | None) -> dict[str, Any]:
    if not executable:
        return {"kind": "missing", "project_mount_capable": False}
    try:
        path = Path(executable).resolve()
        text = path.read_text(encoding="utf-8", errors="ignore")[:32768]
    except OSError:
        return {"kind": "binary", "project_mount_capable": False}
    docker = "docker run" in text or "docker exec" in text or "docker compose" in text
    mount = bool(re.search(r"(/workspace|:\\?workspace)", text)) and ("-v" in text or "--mount" in text)
    return {"kind": "docker_wrapper" if docker else "script", "project_mount_capable": mount}


def discover_backend(definition: dict[str, Any], secrets: list[str]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    backend = dict(definition)
    backend_id = str(backend["id"])
    if backend.get("enabled") is False:
        return {"id": backend_id, "kind": backend.get("kind"), "provider": backend.get("provider"), "engine": backend.get("engine"), "status": "disabled", "auth": {"kind": str(backend.get("auth", {}).get("kind", "none")), "available": False}}, []
    if backend.get("kind") == "cli_harness":
        executable, version = command_version(str(backend.get("command", backend_id)))
        metadata = wrapper_metadata(executable)
        models: list[dict[str, Any]] = []
        if executable and backend.get("model_command"):
            try:
                result = subprocess.run([executable, *[str(item) for item in backend["model_command"]]], capture_output=True, text=True, timeout=20)
                if result.returncode == 0:
                    for line in result.stdout.splitlines():
                        model_id = line.strip()
                        if model_id:
                            models.append(model_entry(backend, {"id": model_id, "name": model_id}, model_id))
            except (OSError, subprocess.SubprocessError):
                pass
        elif executable:
            models.append(model_entry(backend, {"id": "__harness__", "name": f"{backend_id} harness"}, "__harness__"))
        status = "available" if executable else "missing"
        return {
            "id": backend_id,
            "kind": backend.get("kind"),
            "provider": backend.get("provider"),
            "engine": backend.get("engine"),
            "status": status,
            "command": backend.get("command"),
            "executable": executable,
            "version": version,
            "privacy": backend.get("privacy"),
            "resource_group": backend.get("resource_group"),
            "wrapper": metadata,
            "auth": {"kind": "none", "available": True},
            "model_count": len(models),
        }, models

    auth = backend.get("auth", {"kind": "none"})
    headers, auth_available = http_headers(auth, secrets)
    endpoint = str(backend.get("endpoint", "")).rstrip("/")
    health: dict[str, Any] = {}
    if backend.get("health_path"):
        status_code, body, message, latency = http_json(endpoint + str(backend["health_path"]), headers if auth_available else {"Content-Type": "application/json"})
        health = {
            "status_code": status_code,
            "latency_ms": round(latency, 1),
            "summary": message or (str(body.get("status") or body.get("healthy") or "reachable") if isinstance(body, dict) else "reachable"),
        }
        if isinstance(body, dict):
            for key in ("model_count", "loaded_count", "default_model", "version"):
                if key in body:
                    health[key] = body[key]
            engine_pool = body.get("engine_pool")
            if isinstance(engine_pool, dict):
                for key in ("model_count", "loaded_count"):
                    if key in engine_pool:
                        health[key] = engine_pool[key]
    models: list[dict[str, Any]] = []
    discovery_status = 0
    discovery_error: str | None = None
    discovery_path: str | None = None
    if auth_available:
        for candidate in backend.get("discovery_paths", []):
            status_code, body, message, _ = http_json(endpoint + str(candidate), headers)
            discovery_status = status_code
            discovery_error = message
            if status_code == 200:
                discovery_path = str(candidate)
                models = parse_models(backend, body)
                break
    status = "available" if discovery_status == 200 else "degraded" if endpoint and (health.get("status_code") == 200 or discovery_status in (401, 403)) else "missing"
    return {
        "id": backend_id,
        "kind": backend.get("kind"),
        "provider": backend.get("provider"),
        "engine": backend.get("engine"),
        "status": status,
        "endpoint": endpoint,
        "privacy": backend.get("privacy"),
        "resource_group": backend.get("resource_group"),
        "generation_protocol": backend.get("generation_protocol"),
        "auth": {"kind": str(auth.get("kind", "none")), "available": auth_available},
        "health": health,
        "discovery": {"path": discovery_path, "status_code": discovery_status, "error": discovery_error},
        "model_count": len(models),
    }, models


def ensure_policy(paths: dict[str, Path], defaults: dict[str, Any]) -> dict[str, Any]:
    policy = read_json(paths["delegation_policy"], {})
    if policy:
        return policy
    policy = {"version": 1, "kind": "delegation_policy_local", **defaults.get("delegation_defaults", {}), "updated_at": utc_iso()}
    write_json_private(paths["delegation_policy"], policy)
    return policy


def ensure_qualifications(paths: dict[str, Path]) -> dict[str, Any]:
    value = read_json(paths["qualifications"], {})
    if value:
        return value
    value = {"version": 1, "kind": "model_qualification_local", "updated_at": utc_iso(), "records": []}
    write_json_private(paths["qualifications"], value)
    return value


def discover(root: Path, defaults: dict[str, Any], paths: dict[str, Path]) -> tuple[dict[str, Any], dict[str, Any], list[str]]:
    overrides = read_json(paths["overrides"], {})
    definitions = merge_backends(defaults.get("backends", []), overrides.get("backends", []) if isinstance(overrides, dict) else [])
    secrets: list[str] = []
    backend_results: list[dict[str, Any]] = []
    models: list[dict[str, Any]] = []
    for definition in definitions:
        backend, discovered = discover_backend(definition, secrets)
        backend_results.append(backend)
        models.extend(discovered)
    artifacts_by_id: dict[str, dict[str, Any]] = {}
    for model in models:
        fingerprint_value = model["artifact_fingerprint"]
        artifact = artifacts_by_id.setdefault(fingerprint_value, {"fingerprint": fingerprint_value, "model_refs": [], "backend_ids": [], "aliases": []})
        artifact["model_refs"].append(model["ref"])
        artifact["backend_ids"].append(model["backend_id"])
        artifact["aliases"].append(model["model_id"])
    artifacts = []
    for artifact in artifacts_by_id.values():
        artifact["model_refs"] = sorted(set(artifact["model_refs"]))
        artifact["backend_ids"] = sorted(set(artifact["backend_ids"]))
        artifact["aliases"] = sorted(set(artifact["aliases"]))
        artifacts.append(artifact)
    now = utc_iso()
    backends_doc = {"version": 1, "kind": "execution_backends_local", "generated_at": now, "backends": backend_results}
    models_doc = {"version": 1, "kind": "model_inventory_local", "generated_at": now, "models": sorted(models, key=lambda item: item["ref"]), "artifacts": sorted(artifacts, key=lambda item: item["fingerprint"])}
    write_json_private(paths["backends"], redact(backends_doc, secrets))
    write_json_private(paths["models"], redact(models_doc, secrets))
    ensure_policy(paths, defaults)
    ensure_qualifications(paths)
    return redact(backends_doc, secrets), redact(models_doc, secrets), secrets


def record_qualification(paths: dict[str, Path], args: argparse.Namespace, evidence: dict[str, Any] | None = None) -> dict[str, Any]:
    doc = ensure_qualifications(paths)
    records = doc.setdefault("records", [])
    record = {
        "backend_id": args.backend,
        "model_id": args.model,
        "task_class": args.task_class,
        "status": args.status,
        "checked_at": utc_iso(),
        "checked_at_epoch": int(time.time()),
        "protocol": args.protocol,
        "latency_ms": args.latency_ms,
        "summary": args.summary,
    }
    if evidence:
        record.update(evidence)
    records[:] = [item for item in records if not (item.get("backend_id") == args.backend and item.get("model_id") == args.model and item.get("task_class") == args.task_class)]
    records.append(record)
    doc["updated_at"] = utc_iso()
    write_json_private(paths["qualifications"], doc)
    return record


def route(paths: dict[str, Path], task_class: str, risk: str, privacy: str) -> dict[str, Any]:
    policy = read_json(paths["delegation_policy"], {})
    if not policy.get("enabled") or policy.get("consent") != "granted":
        return {"route": "direct_main_agent", "reason": "delegation_not_enabled", "candidate": None}
    if RISK_ORDER.get(risk, 99) > RISK_ORDER.get(str(policy.get("max_risk", "low")), 0):
        return {"route": "direct_main_agent", "reason": "risk_exceeds_policy", "candidate": None}
    inventory = read_json(paths["models"], {"models": []})
    backends_doc = read_json(paths["backends"], {"backends": []})
    qualifications = read_json(paths["qualifications"], {"records": []})
    backend_status = {item.get("id"): item.get("status") for item in backends_doc.get("backends", [])}
    ttl_seconds = int(policy.get("qualification_ttl_hours", 168)) * 3600
    now = int(time.time())
    qualified: dict[tuple[str, str], dict[str, Any]] = {}
    for item in qualifications.get("records", []):
        if item.get("task_class") != task_class or item.get("status") not in ("qualified", "limited"):
            continue
        if now - int(item.get("checked_at_epoch", 0)) > ttl_seconds:
            continue
        qualified[(str(item.get("backend_id")), str(item.get("model_id")))] = item
    candidates = []
    for model in inventory.get("models", []):
        if backend_status.get(model.get("backend_id")) != "available":
            continue
        if privacy == "local_only" and model.get("privacy") != "local":
            continue
        evidence = qualified.get((str(model.get("backend_id")), str(model.get("model_id"))))
        if not evidence and not policy.get("allow_unqualified"):
            continue
        score = 100 if model.get("privacy") == "local" else 0
        score += 20 if evidence and evidence.get("status") == "qualified" else 5
        latency = evidence.get("latency_ms") if evidence else None
        if isinstance(latency, (int, float)):
            score += max(0, 20 - int(latency / 1000))
        candidates.append((score, model, evidence))
    if not candidates:
        return {"route": "direct_main_agent", "reason": "no_eligible_qualified_backend", "candidate": None}
    candidates.sort(key=lambda item: (-item[0], item[1]["ref"]))
    score, model, evidence = candidates[0]
    return {"route": "delegate", "reason": "qualified_policy_match", "candidate": model, "qualification": evidence, "score": score}


def extract_response(protocol: str, body: Any) -> str:
    if not isinstance(body, dict):
        return ""
    if protocol == "ollama_chat":
        return str(body.get("message", {}).get("content", ""))
    if protocol == "openai_responses":
        if body.get("output_text"):
            return str(body["output_text"])
        texts = []
        for item in body.get("output", []):
            for content in item.get("content", []) if isinstance(item, dict) else []:
                if isinstance(content, dict) and content.get("text"):
                    texts.append(str(content["text"]))
        return "".join(texts)
    if protocol == "anthropic_messages":
        return "".join(str(item.get("text", "")) for item in body.get("content", []) if isinstance(item, dict))
    choices = body.get("choices", [])
    if choices and isinstance(choices[0], dict):
        return str(choices[0].get("message", {}).get("content", ""))
    return ""


def probe_backend(definition: dict[str, Any], backend_state: dict[str, Any], model: dict[str, Any], allow_load: bool, secrets: list[str]) -> dict[str, Any]:
    if backend_state.get("status") != "available":
        return {"status": "unavailable", "protocol": str(definition.get("generation_protocol", "unknown")), "latency_ms": None, "summary": "backend_not_available"}
    if definition.get("kind") == "cli_harness":
        executable = backend_state.get("executable") or shutil.which(str(definition.get("command", "")))
        if not executable:
            return {"status": "unavailable", "protocol": "cli", "latency_ms": None, "summary": "executable_missing"}
        if definition.get("id") == "agy" and model.get("model_id") != "__harness__":
            started = time.monotonic()
            try:
                result = subprocess.run(
                    [str(executable), "--sandbox", "--mode", "plan", "--model", str(model["model_id"]), "--print", "Return exactly OK."],
                    capture_output=True,
                    text=True,
                    timeout=120,
                )
                latency = (time.monotonic() - started) * 1000
                passed = result.returncode == 0 and result.stdout.strip().casefold() == "ok"
                return {"status": "qualified" if passed else "limited", "protocol": "agy_cli_plan", "latency_ms": round(latency, 1), "summary": "exact_ok" if passed else f"exit_{result.returncode}"}
            except (OSError, subprocess.SubprocessError):
                return {"status": "unavailable", "protocol": "agy_cli_plan", "latency_ms": None, "summary": "cli_probe_failed"}
        wrapper = backend_state.get("wrapper", {})
        if wrapper.get("kind") == "docker_wrapper" and wrapper.get("project_mount_capable"):
            return {"status": "limited", "protocol": "wrapper_inspection", "latency_ms": None, "summary": "docker_wrapper_project_mount_capable_generation_not_run"}
        return {"status": "limited", "protocol": "wrapper_inspection", "latency_ms": None, "summary": "harness_available_generation_not_run"}
    if model.get("resource_group") == "heavy_local_model" and not allow_load:
        loaded = model.get("state") == "loaded" or int(backend_state.get("health", {}).get("loaded_count", 0) or 0) > 0
        if not loaded:
            return {"status": "untested", "protocol": str(definition.get("generation_protocol", "unknown")), "latency_ms": None, "summary": "not_loaded_no_autoload"}
    protocol = str(definition.get("generation_protocol", "openai_chat"))
    headers, auth_available = http_headers(definition.get("auth", {"kind": "none"}), secrets)
    if not auth_available:
        return {"status": "unavailable", "protocol": protocol, "latency_ms": None, "summary": "authentication_unavailable"}
    endpoint = str(definition.get("endpoint", "")).rstrip("/")
    prompt = "Return exactly OK."
    if protocol == "ollama_chat":
        path = "/api/chat"
        payload = {"model": model["model_id"], "messages": [{"role": "user", "content": prompt}], "stream": False, "options": {"temperature": 0, "num_predict": 8}}
    elif protocol == "openai_responses":
        path = "/v1/responses"
        payload = {"model": model["model_id"], "input": prompt, "max_output_tokens": 8}
    elif protocol == "anthropic_messages":
        path = "/v1/messages"
        payload = {"model": model["model_id"], "max_tokens": 8, "messages": [{"role": "user", "content": prompt}]}
        headers.setdefault("anthropic-version", "2023-06-01")
    else:
        path = "/v1/chat/completions"
        payload = {"model": model["model_id"], "messages": [{"role": "user", "content": prompt}], "temperature": 0, "max_tokens": 8}
    status_code, body, message, latency = http_json(endpoint + path, headers, payload, timeout=120)
    text = extract_response(protocol, body).strip()
    passed = status_code == 200 and text.casefold() == "ok"
    summary = "exact_ok" if passed else f"http_{status_code}" if status_code else "request_failed"
    if message and status_code != 200:
        summary += ":" + message[:120]
    return {"status": "qualified" if passed else "unavailable" if status_code in (401, 403, 404, 410) or status_code == 0 else "limited", "protocol": protocol, "latency_ms": round(latency, 1), "summary": summary, "status_code": status_code}


def load_runtime(args: argparse.Namespace) -> tuple[Path, dict[str, Any], dict[str, Path], list[dict[str, Any]]]:
    kernel_root = Path(args.kernel_root).expanduser().resolve()
    root = Path(args.root).expanduser().resolve()
    defaults_path = Path(args.defaults).expanduser().resolve() if args.defaults else kernel_root / "config/execution-backends.defaults.json"
    defaults = read_json(defaults_path, None)
    if not isinstance(defaults, dict):
        raise SystemExit(f"Invalid execution backend defaults: {defaults_path}")
    paths = local_paths(root, defaults, args.overrides)
    overrides = read_json(paths["overrides"], {})
    definitions = merge_backends(defaults.get("backends", []), overrides.get("backends", []) if isinstance(overrides, dict) else [])
    return root, defaults, paths, definitions


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("discover", "status", "consent", "record", "route", "probe", "benchmark"))
    parser.add_argument("action", nargs="?")
    parser.add_argument("--kernel-root", default=str(Path(__file__).resolve().parents[1]))
    parser.add_argument("--root", default=".")
    parser.add_argument("--defaults")
    parser.add_argument("--overrides")
    parser.add_argument("--backend")
    parser.add_argument("--model")
    parser.add_argument("--task-class", default="connectivity")
    parser.add_argument("--status", choices=("qualified", "limited", "unqualified", "unavailable", "untested"), default="untested")
    parser.add_argument("--protocol", default="manual")
    parser.add_argument("--latency-ms", type=float)
    parser.add_argument("--summary", default="")
    parser.add_argument("--privacy", choices=("local_only", "allow_remote"), default="local_only")
    parser.add_argument("--max-risk", choices=("low", "medium", "high"), default="low")
    parser.add_argument("--risk", choices=("low", "medium", "high"), default="low")
    parser.add_argument("--allow-load", action="store_true")
    parser.add_argument("--models", default="")
    parser.add_argument("--output")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    _, defaults, paths, definitions = load_runtime(args)
    secrets: list[str] = []
    if args.command == "discover":
        backends, models, secrets = discover(Path(args.root).expanduser().resolve(), defaults, paths)
        result = {"backends": backends, "models": models, "policy": ensure_policy(paths, defaults)}
    elif args.command == "status":
        result = {
            "backends": read_json(paths["backends"], {"status": "missing"}),
            "models": read_json(paths["models"], {"status": "missing"}),
            "qualifications": read_json(paths["qualifications"], {"status": "missing"}),
            "policy": ensure_policy(paths, defaults),
        }
    elif args.command == "consent":
        if args.action not in ("enable", "disable"):
            parser.error("consent requires enable or disable")
        policy = ensure_policy(paths, defaults)
        enabled = args.action == "enable"
        policy.update({"enabled": enabled, "consent": "granted" if enabled else "revoked", "privacy": args.privacy, "max_risk": args.max_risk, "updated_at": utc_iso()})
        write_json_private(paths["delegation_policy"], policy)
        result = policy
    elif args.command == "record":
        if not args.backend or not args.model:
            parser.error("record requires --backend and --model")
        result = record_qualification(paths, args)
    elif args.command == "route":
        result = route(paths, args.task_class, args.risk, args.privacy)
    elif args.command == "benchmark":
        benchmark_script = Path(args.kernel_root).expanduser().resolve() / "scripts/benchmark-local-models.py"
        command = [sys.executable, str(benchmark_script), "--root", str(Path(args.root).expanduser().resolve()), "--backend", args.backend or "lmstudio"]
        if args.models:
            command += ["--models", args.models]
        if args.allow_load:
            command.append("--allow-load")
        if args.output:
            command += ["--output", args.output]
        definitions_by_id = {item["id"]: item for item in definitions}
        definition = definitions_by_id.get(args.backend or "lmstudio")
        if definition is None:
            raise SystemExit("Benchmark backend is not defined")
        benchmark_env = os.environ.copy()
        auth = definition.get("auth", {"kind": "none"})
        if isinstance(auth, dict) and auth.get("kind", "none") != "none":
            secret = resolve_secret(auth)
            if not secret:
                raise SystemExit("Benchmark backend authentication is unavailable")
            benchmark_env["LM_API_TOKEN"] = secret
            secrets.append(secret)
        completed = subprocess.run(command, capture_output=True, text=True, env=benchmark_env)
        if completed.returncode != 0:
            raise SystemExit(completed.stderr.strip() or "benchmark failed")
        result = json.loads(completed.stdout)
    else:
        if not args.backend or not args.model:
            parser.error("probe requires --backend and --model")
        definitions_by_id = {item["id"]: item for item in definitions}
        backend_states = {item.get("id"): item for item in read_json(paths["backends"], {"backends": []}).get("backends", [])}
        models = read_json(paths["models"], {"models": []}).get("models", [])
        model = next((item for item in models if item.get("backend_id") == args.backend and item.get("model_id") == args.model), None)
        if args.backend not in definitions_by_id or model is None:
            raise SystemExit("Backend/model not found; run discover first")
        probe = probe_backend(definitions_by_id[args.backend], backend_states.get(args.backend, {}), model, args.allow_load, secrets)
        args.status = probe["status"]
        args.protocol = probe["protocol"]
        args.latency_ms = probe.get("latency_ms")
        args.summary = probe.get("summary", "")
        result = record_qualification(paths, args, {"status_code": probe.get("status_code")})
    safe = redact(result, secrets)
    print(json.dumps(safe, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
