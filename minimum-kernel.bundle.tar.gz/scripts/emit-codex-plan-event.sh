#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-$HOME/.gemini}"
ROOT_SET=0
EVENT_NAME=""
EVENT_ID=""
PROJECT_ROOT=""
TIMESTAMP=""
REQUIRED_FLAG=""
CONTENT_HASH=""
NEXT_ACTION=""
DURABLE_CAPTURE_JSON=""
DURABLE_CAPTURE_FILE=""
RECEIPT_JSON=""
RECEIPT_FILE=""
ORIGIN_WORKFLOW=""
APPROVAL_SOURCE=""
SUPERSEDE_ACTIVE_PLAN=false

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INGESTOR="$SCRIPT_DIR/ingest-plan-event.sh"

usage() {
  cat <<'EOF'
Usage:
  emit-codex-plan-event.sh [--root PATH] --project-root PATH --event-name NAME --event-id ID --timestamp ISO8601
    [--required true|false]
    [--content-hash SHA256]
    [--next-action VALUE]
    [--durable-capture-json JSON | --durable-capture-file PATH]
    [--receipt-json JSON | --receipt-file PATH]
    [--origin-workflow FILE]
    [--supersede-active-plan true|false]
    [--approval-source host_ui_button|host_ui_command|chat_structured_command|manual_script]

Description:
  Codex adapter that emits canonical host plan events without persisting a repo plan artifact.
EOF
}

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || {
    echo "Missing required command: $1" >&2
    exit 1
  }
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --root)
      ROOT="$2"
      ROOT_SET=1
      shift 2
      ;;
    --project-root)
      PROJECT_ROOT="$2"
      shift 2
      ;;
    --event-name)
      EVENT_NAME="$2"
      shift 2
      ;;
    --event-id)
      EVENT_ID="$2"
      shift 2
      ;;
    --timestamp)
      TIMESTAMP="$2"
      shift 2
      ;;
    --required)
      REQUIRED_FLAG="$2"
      shift 2
      ;;
    --content-hash)
      CONTENT_HASH="$2"
      shift 2
      ;;
    --next-action)
      NEXT_ACTION="$2"
      shift 2
      ;;
    --durable-capture-json)
      DURABLE_CAPTURE_JSON="$2"
      shift 2
      ;;
    --durable-capture-file)
      DURABLE_CAPTURE_FILE="$2"
      shift 2
      ;;
    --receipt-json)
      RECEIPT_JSON="$2"
      shift 2
      ;;
    --receipt-file)
      RECEIPT_FILE="$2"
      shift 2
      ;;
    --origin-workflow)
      ORIGIN_WORKFLOW="$2"
      shift 2
      ;;
    --approval-source)
      APPROVAL_SOURCE="$2"
      shift 2
      ;;
    --supersede-active-plan)
      SUPERSEDE_ACTIVE_PLAN="$2"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      if [[ $ROOT_SET -eq 0 && "$1" != --* ]]; then
        ROOT="$1"
        ROOT_SET=1
        shift
      else
        echo "Unexpected argument: $1" >&2
        usage
        exit 1
      fi
      ;;
  esac
done

require_cmd jq

[[ -n "$PROJECT_ROOT" && -n "$EVENT_NAME" && -n "$EVENT_ID" && -n "$TIMESTAMP" ]] || {
  usage
  exit 1
}

if [[ -n "$DURABLE_CAPTURE_FILE" ]]; then
  DURABLE_CAPTURE_JSON="$(cat "$DURABLE_CAPTURE_FILE")"
fi

if [[ -n "$RECEIPT_FILE" ]]; then
  RECEIPT_JSON="$(cat "$RECEIPT_FILE")"
fi

if [[ -z "$DURABLE_CAPTURE_JSON" && -n "$RECEIPT_JSON" ]]; then
  printf '%s' "$RECEIPT_JSON" | jq -e '. | type == "object"' >/dev/null || {
    echo "receipt must be a JSON object." >&2
    exit 1
  }
  DURABLE_CAPTURE_JSON="$(printf '%s' "$RECEIPT_JSON" | jq -c '{
    tenant_domain: "delivery",
    summary: .objective,
    alternatives: ["Defer/no-op", "Apply bounded approved change"],
    validation: .validation_commands,
    risks: .constraints,
    receipt: .
  }')"
fi

if [[ -n "$DURABLE_CAPTURE_JSON" ]]; then
  printf '%s' "$DURABLE_CAPTURE_JSON" | jq -e '. | type == "object"' >/dev/null || {
    echo "durable_capture must be a JSON object." >&2
    exit 1
  }
fi

EVENT_JSON="$(jq -cn \
  --arg project_root "$PROJECT_ROOT" \
  --arg event_name "$EVENT_NAME" \
  --arg event_id "$EVENT_ID" \
  --arg timestamp "$TIMESTAMP" \
  --arg content_hash "$CONTENT_HASH" \
  --arg next_action "$NEXT_ACTION" \
  --arg origin_workflow "$ORIGIN_WORKFLOW" \
  --arg required_flag "$REQUIRED_FLAG" \
  --arg approval_source "$APPROVAL_SOURCE" \
  --argjson supersede_active_plan "$( [[ "$SUPERSEDE_ACTIVE_PLAN" == "true" ]] && printf 'true' || printf 'false' )" \
  --argjson durable_capture "$(if [[ -n "$DURABLE_CAPTURE_JSON" ]]; then printf '%s' "$DURABLE_CAPTURE_JSON"; else printf 'null'; fi)" \
  '{
    schema_version: 3,
    event_id: $event_id,
    event_name: $event_name,
    source_host: "codex_internal",
    producer_agent: "codex",
    approval_source: (if $approval_source == "" then null else $approval_source end),
    project_root: $project_root,
    timestamp: $timestamp
  }
  + (if $required_flag != "" then {required: ($required_flag == "true")} else {} end)
  + (if $content_hash != "" then {content_hash: $content_hash} else {} end)
  + (if $next_action != "" then {next_action: $next_action} else {} end)
  + (if $origin_workflow != "" then {origin_workflow: $origin_workflow} else {} end)
  + (if $supersede_active_plan then {supersede_active_plan: true} else {} end)
  + (if $durable_capture != null then {durable_capture: $durable_capture} else {} end)')"

"$INGESTOR" --root "$ROOT" --event-json "$EVENT_JSON"
