#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
MODE="check"
FORCE="false"

usage() {
  cat <<'EOF'
Usage: render-read-contract-surfaces.sh [--root PATH] [--check|--write] [--force]

Description:
  Syncs the kernel read-contract projections from state/read_contract.json.
  This refreshes the generated read-contract block inside GEMINI.md and the
  deterministic AGENTS.md onboarding output for the target project root.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --root)
      ROOT="$(cd "$2" && pwd)"
      shift 2
      ;;
    --check)
      MODE="check"
      shift
      ;;
    --write)
      MODE="write"
      shift
      ;;
    --force)
      FORCE="true"
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unexpected argument: $1" >&2
      usage
      exit 1
      ;;
  esac
done

KERNEL_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
PY_RENDERER="$KERNEL_ROOT/scripts/render-read-contract.py"
AGENTS_RENDERER="$KERNEL_ROOT/scripts/render-project-agents-md.sh"

if [[ ! -f "$PY_RENDERER" ]]; then
  echo "ERROR: Missing renderer: $PY_RENDERER" >&2
  exit 1
fi

if [[ ! -f "$AGENTS_RENDERER" ]]; then
  echo "ERROR: Missing AGENTS renderer: $AGENTS_RENDERER" >&2
  exit 1
fi

python3 "$PY_RENDERER" --kernel-root "$KERNEL_ROOT" --target sync-gemini --root "$KERNEL_ROOT" --mode "$MODE"

if [[ "$MODE" == "write" ]]; then
  if [[ "$FORCE" == "true" ]]; then
    bash "$AGENTS_RENDERER" --project-root "$ROOT" --write --force
  else
    bash "$AGENTS_RENDERER" --project-root "$ROOT" --write
  fi
else
  bash "$AGENTS_RENDERER" --project-root "$ROOT" --check
fi
