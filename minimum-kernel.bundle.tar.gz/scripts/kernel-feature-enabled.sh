#!/usr/bin/env bash
set -euo pipefail

ROOT="$HOME/.gemini"
FEATURE=""
JSON_OUTPUT=0

usage() {
  cat <<'EOF'
Usage:
  kernel-feature-enabled.sh FEATURE [--root PATH]
  kernel-feature-enabled.sh --json [--root PATH]

Description:
  Reads optional kernel feature flags from .kernel/install_state.json.
  Without install_state, source/local defaults keep memory, ledgers, core tests,
  and strict plan gate enabled.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --root)
      ROOT="$2"
      shift 2
      ;;
    --json)
      JSON_OUTPUT=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      if [[ -z "$FEATURE" ]]; then
        FEATURE="$1"
        shift
      else
        echo "Unexpected argument: $1" >&2
        usage
        exit 1
      fi
      ;;
  esac
done

ROOT="$(cd "$ROOT" && pwd -P)"
STATE_FILE="$ROOT/.kernel/install_state.json"

defaults_json() {
  cat <<'JSON'
{
  "live_state": true,
  "project_state_cache": true,
  "memory_vault": true,
  "project_ledgers": true,
  "core_tests": true,
  "full_evals": false,
  "audit_tooling": true,
  "mcp_templates": true,
  "advanced_workflows": true,
  "strict_plan_gate": true,
  "telemetry_tooling": false
}
JSON
}

features_json() {
  if [[ -f "$STATE_FILE" ]]; then
    jq -c '
      (.features // {})
      | .live_state = true
      | .project_state_cache = true
    ' "$STATE_FILE"
  else
    defaults_json | jq -c '.'
  fi
}

FEATURES="$(features_json)"

if (( JSON_OUTPUT == 1 )); then
  jq -n \
    --arg root "$ROOT" \
    --arg source "$(if [[ -f "$STATE_FILE" ]]; then printf 'install_state'; else printf 'source_defaults'; fi)" \
    --argjson features "$FEATURES" \
    '{schema_version:1, root:$root, source:$source, features:$features}'
  exit 0
fi

[[ -n "$FEATURE" ]] || {
  usage
  exit 1
}

VALUE="$(jq -r --arg key "$FEATURE" '.[$key] // false' <<< "$FEATURES")"
printf '%s\n' "$VALUE"
if [[ "$VALUE" == "true" ]]; then
  exit 0
fi
exit 1
