#!/usr/bin/env bash
set -euo pipefail

ROOT="$HOME/.gemini"
PROFILE="lean"
INCLUDE_PORTABLE=0
LIST_ONLY=0

usage() {
  cat <<'EOF'
Usage:
  run-evals-from-manifest.sh [--root PATH] [--profile lean|core] [--portable] [--list]

Description:
  Runs eval checks declared in evals/manifest.json. Commands may use the
  placeholder {root}, which is replaced with the resolved project root.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --root)
      ROOT="$2"
      shift 2
      ;;
    --profile)
      PROFILE="$2"
      shift 2
      ;;
    --portable)
      INCLUDE_PORTABLE=1
      shift
      ;;
    --list)
      LIST_ONLY=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unexpected argument: $1" >&2
      usage >&2
      exit 1
      ;;
  esac
done

ROOT="$(cd "$ROOT" && pwd -P)"
MANIFEST="$ROOT/evals/manifest.json"
ERRORS=0
TMP_DIR="$(mktemp -d "${TMPDIR:-/tmp}/gemini-manifest-evals.XXXXXX")"
trap 'rm -rf "$TMP_DIR"' EXIT

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || {
    printf 'ERROR: missing command: %s\n' "$1" >&2
    exit 1
  }
}

emit_error() {
  printf 'ERROR: %s\n' "$1"
  ERRORS=$((ERRORS + 1))
}

emit_info() {
  printf 'INFO: %s\n' "$1"
}

require_cmd jq
[[ -f "$MANIFEST" ]] || {
  emit_error "Missing eval manifest: $MANIFEST"
  printf 'SUMMARY: %s error(s)\n' "$ERRORS"
  exit 1
}

jq -e --arg profile "$PROFILE" '
  .version >= 2 and
  (.profiles | type == "object") and
  (.profiles[$profile] | type == "object")
' "$MANIFEST" >/dev/null || {
  emit_error "Invalid eval manifest or unknown profile: $PROFILE"
  printf 'SUMMARY: %s error(s)\n' "$ERRORS"
  exit 1
}

read_entries() {
  jq -r --arg profile "$PROFILE" --argjson portable "$INCLUDE_PORTABLE" '
    . as $root
    |
    def checks_for($id):
      ($root.profiles[$id].extends // []) as $parents
      | ([ $parents[] | checks_for(.)[] ] + ($root.profiles[$id].checks // []));
    checks_for($profile)[]
    | select((.portable_only // false) == false or $portable == 1)
    | [.id, .label, .command] | @tsv
  ' "$MANIFEST"
}

while IFS=$'\t' read -r check_id label command; do
  [[ -n "$check_id" ]] || continue
  resolved_command="${command//\{root\}/$ROOT}"

  if (( LIST_ONLY == 1 )); then
    printf '%s\t%s\t%s\n' "$check_id" "$label" "$resolved_command"
    continue
  fi

  output="$TMP_DIR/${check_id//[^A-Za-z0-9_.-]/_}.log"
  emit_info "Checking $label"
  if bash -lc "$resolved_command" >"$output" 2>&1; then
    emit_info "$label passed."
  else
    emit_error "$label failed."
    sed -n '1,16p' "$output"
  fi
done < <(read_entries)

if (( LIST_ONLY == 1 )); then
  exit 0
fi

if (( ERRORS > 0 )); then
  printf 'SUMMARY: %s error(s)\n' "$ERRORS"
  exit 1
fi

printf 'SUMMARY: 0 error(s)\n'
