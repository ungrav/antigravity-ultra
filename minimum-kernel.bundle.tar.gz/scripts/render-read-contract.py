#!/usr/bin/env python3
import argparse
import json
import pathlib
import sys


GEMINI_BEGIN = "<!-- GEMINI_READ_CONTRACT_START -->"
GEMINI_END = "<!-- GEMINI_READ_CONTRACT_END -->"
PORTABLE_PROFILE_END = "<!-- PORTABLE_KERNEL_PROFILE_END -->"


def fail(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


def parse_bool(raw: str) -> bool:
    lowered = raw.strip().lower()
    if lowered in {"true", "1", "yes"}:
        return True
    if lowered in {"false", "0", "no"}:
        return False
    fail(f"Invalid boolean value: {raw}")


def default_kernel_root() -> pathlib.Path:
    return pathlib.Path(__file__).resolve().parents[1]


def load_contract(kernel_root: pathlib.Path) -> dict:
    contract_path = kernel_root / "state" / "read_contract.json"
    if not contract_path.exists():
        fail(f"Missing read contract: {contract_path}")
    try:
        contract = json.loads(contract_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        fail(f"Invalid read contract JSON: {exc}")

    required_profiles = {"native", "external"}
    missing_profiles = required_profiles.difference(contract.get("profiles", {}).keys())
    if missing_profiles:
        fail(f"read_contract.json is missing profiles: {', '.join(sorted(missing_profiles))}")

    required_classes = {"baseline", "jit", "fallback", "experimental", "recovery"}
    missing_classes = required_classes.difference(contract.get("read_classes", {}).keys())
    if missing_classes:
        fail(f"read_contract.json is missing read classes: {', '.join(sorted(missing_classes))}")

    required_jit = {"code_local", "incident", "architecture", "kernel_audit", "memory_kernel", "recovery"}
    missing_jit = required_jit.difference(contract.get("jit_expansions", {}).keys())
    if missing_jit:
        fail(f"read_contract.json is missing jit expansions: {', '.join(sorted(missing_jit))}")

    if "sunset_aliases" in contract:
        fail("read_contract.json must not contain sunset_aliases; use state/compat_contract.json instead")

    probes = contract.get("preflight_probes", {})
    if "incident_sniff" not in probes:
        fail("read_contract.json is missing preflight probe: incident_sniff")

    return contract


def render_chain(entries: list[dict]) -> str:
    return " -> ".join(f"`{entry['surface']}`" for entry in entries)


def render_plain_list(items: list[str]) -> str:
    return ", ".join(f"`{item}`" for item in items)


def render_surface_list(items: list[str]) -> str:
    return "; ".join(items)


def render_read_classes(contract: dict) -> list[str]:
    lines = ["### Read Classes"]
    for key in ["baseline", "jit", "fallback", "experimental", "recovery"]:
        description = contract["read_classes"][key]["description"]
        lines.append(f"- `{key}`: {description}")
    lines.append("")
    return lines


def render_non_baseline(contract: dict) -> list[str]:
    lines = ["### Non-Baseline Surfaces", "- `fallback`:"]
    for entry in contract["fallback_surfaces"]:
        lines.append(f"  - `{entry['surface']}`: {entry['when']} {entry['note']}")
    lines.append("- `experimental`:")
    for entry in contract["experimental_surfaces"]:
        lines.append(f"  - `{entry['surface']}`: {entry['note']}")
    lines.append("- `recovery`:")
    for entry in contract["recovery_surfaces"]:
        lines.append(f"  - `{entry['surface']}`: {entry['note']}")
    lines.append("")
    return lines


def render_jit(contract: dict) -> list[str]:
    lines = ["### JIT Escalation"]
    for key in ["code_local", "incident", "architecture", "kernel_audit", "memory_kernel", "recovery"]:
        entry = contract["jit_expansions"][key]
        probes = entry.get("preflight_probes", [])
        probe_text = f"; preflight probes available {render_surface_list(probes)}" if probes else ""
        lines.append(
            f"- `{key}` ({entry['label']}): allow {render_surface_list(entry['allowed_surfaces'])}; "
            f"keep out {render_surface_list(entry['keep_out'])}{probe_text}."
        )
    lines.append("")
    return lines


def render_gemini_block(contract: dict) -> str:
    native = contract["profiles"]["native"]
    external = contract["profiles"]["external"]
    probe = contract["preflight_probes"]["incident_sniff"]
    lines = [
        "## Generated Read Contract",
        f"- Version: `{contract.get('contract_version')}`; structured source: `state/read_contract.json`.",
        f"- Start native work with {render_chain(native['read_order'])}.",
        f"- Start external work with {render_chain(external['read_order'])}.",
        "- Optional resolver helper: `scripts/resolve-read-context.py --profile <native|external> --task \"<task>\" --json`.",
        "- If the resolver is unavailable, continue with the manual table in `AGENTS.md`/`rules/memory-runtime.md` and report `resolver unavailable`.",
        f"- Bug-like local work may read only the latest `{probe['surface']}` rows capped at {probe['max_lines']} lines / {probe['max_tokens']} tokens.",
        "- Load `MEMORY.md` only for memory/kernel or `kernel_audit` work; load `GEMINI_BLUEPRINTS.md` only for restore/portable work.",
        "",
    ]
    return "\n".join(lines).rstrip() + "\n"


def render_agents_block(
    contract: dict,
    *,
    shared_exports: bool,
    has_design_md: bool,
    has_design_system: bool,
    has_error_log: bool,
    has_project_history: bool,
) -> str:
    external = contract["profiles"]["external"]
    lines = [
        "## Golden Path",
        f"- Version: `{contract.get('contract_version')}`; structured source: `state/read_contract.json`.",
        f"- Start here: {render_chain(external['read_order'])}.",
        "- Optional helper: `scripts/resolve-read-context.py --profile external --task \"<task>\" --json`; if it fails, use the table and report `resolver unavailable`.",
        "",
        "## Manual Reading Table",
        "1. Normal/local: target files only.",
        "2. Bug ambiguous: target files + latest `ERROR_LOG.md` rows.",
        "3. Architecture/refactor: latest `PROJECT_HISTORY.md` + Project DNA if useful.",
        "4. Kernel audit: native canon + `MEMORY.md` audit table + read contract + Project DNA/targeted KIs + recent history/eval manifest.",
        "5. Memory/kernel: `MEMORY.md` + targeted KIs.",
        "6. Restore/portable: `GEMINI_BLUEPRINTS.md` + launchers.",
        "",
            "## Temporal Freshness",
            "- Use the host-provided current date, or run `date '+%Y-%m-%d %H:%M:%S %Z %z'` before date-sensitive work.",
            "- Verify current/latest/versioned recommendations with live or primary sources; do not rely only on model memory.",
            "- If current verification is unavailable, say so and mark the answer as offline/PARTIAL.",
            "",
            "## Dependency And Skills Safety",
            "- Remote npm/npx execution for MCPs, skills, or CLIs must go through `scripts/dependency-safety-adapter.sh` or an equivalent detected host guard: exact versions only, no `@latest`.",
            "- Before creating a new skill, use local registry resolution and `scripts/skill-trust-gate.sh discover` so skills.sh `find-skills` gets a project-context search brief.",
            "- Install community skills project-local by default after audit/approval; global installs require explicit user request.",
            "",
            "## Local Canon",
            "- `GEMINI.md` is local canon, but not normal external warmup; if files disagree, follow `GEMINI.md`.",
    ]

    if shared_exports:
        lines.append(
            "- Read shared/exportable sections only unless runtime detail is needed."
        )
    else:
        lines.append(
            "- No shared exports; read `GEMINI.md` surgically only when needed."
        )

    lines.extend(
        [
            "",
            "## Memory",
            "- Normal tasks use no vault. For \"what did we decide\", \"why did we do X\", prior errors, or architecture, read Project DNA then run `scripts/select-memory-context.sh --root . --query \"<task>\" --limit 5`.",
            "- Verify KI claims against repo/runtime before recommending current files, scripts, flags, or decisions.",
        ]
    )

    lines.extend(
        [
            "",
            "## Memory Capture",
            "- Closeout triggers include \"cerrar sesión\", \"closeout\", \"wrap up\", \"handoff\", and \"continuar luego\".",
            "- Closeout command: `scripts/kernel-closeout.sh --root . --close-session --session-summary \"<summary>\" --next-step \"<next>\" --verify runtime`; add `--memory-summary` only for durable memory.",
        ]
    )

    if has_design_md and has_design_system:
        lines.append("- UI/frontend tasks: read `DESIGN.md` first; use `DESIGN_SYSTEM.md` only as the local bridge/fallback.")
    elif has_design_md:
        lines.append("- UI/frontend tasks: read `DESIGN.md` before editing visual components or UX flows.")
    elif has_design_system:
        lines.append("- UI/frontend tasks: read `DESIGN_SYSTEM.md` before editing visual components or UX flows.")
    lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def sync_gemini(contract: dict, root: pathlib.Path, mode: str) -> int:
    gemini_path = root / "GEMINI.md"
    if not gemini_path.exists():
        fail(f"Missing GEMINI.md: {gemini_path}")

    rendered = render_gemini_block(contract).rstrip()
    block = f"{GEMINI_BEGIN}\n{rendered}\n{GEMINI_END}"
    current = gemini_path.read_text(encoding="utf-8")

    if GEMINI_BEGIN in current and GEMINI_END in current:
        before, remainder = current.split(GEMINI_BEGIN, 1)
        _, after = remainder.split(GEMINI_END, 1)
        updated = before.rstrip() + "\n\n" + block + after
    else:
        if PORTABLE_PROFILE_END in current:
            prefix, suffix = current.split(PORTABLE_PROFILE_END, 1)
            updated = prefix + PORTABLE_PROFILE_END + "\n\n" + block + suffix
        elif "## 0. Prime Directive" in current:
            prefix, suffix = current.split("## 0. Prime Directive", 1)
            updated = prefix.rstrip() + "\n\n" + block + "\n\n## 0. Prime Directive" + suffix
        else:
            updated = current.rstrip() + "\n\n" + block + "\n"

    if not updated.endswith("\n"):
        updated += "\n"

    if mode == "check":
        if current != updated:
            fail("GEMINI.md generated read-contract block is stale.")
        print("INFO: GEMINI.md read-contract block is fresh.")
        return 0

    gemini_path.write_text(updated, encoding="utf-8")
    print("INFO: Rendered GEMINI.md read-contract block.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--kernel-root",
        default=str(default_kernel_root()),
        help="Kernel root that owns state/read_contract.json",
    )
    parser.add_argument(
        "--target",
        required=True,
        choices=["gemini-block", "agents-block", "sync-gemini"],
    )
    parser.add_argument("--root", default=None, help="Target root for sync-gemini.")
    parser.add_argument("--mode", choices=["check", "write"], default="check")
    parser.add_argument("--shared-exports", default="false")
    parser.add_argument("--has-design-md", default="false")
    parser.add_argument("--has-design-system", default="false")
    parser.add_argument("--has-error-log", default="false")
    parser.add_argument("--has-project-history", default="false")
    args = parser.parse_args()

    kernel_root = pathlib.Path(args.kernel_root).expanduser().resolve()
    contract = load_contract(kernel_root)

    if args.target == "gemini-block":
        sys.stdout.write(render_gemini_block(contract))
        return 0

    if args.target == "agents-block":
        sys.stdout.write(
            render_agents_block(
                contract,
                shared_exports=parse_bool(args.shared_exports),
                has_design_md=parse_bool(args.has_design_md),
                has_design_system=parse_bool(args.has_design_system),
                has_error_log=parse_bool(args.has_error_log),
                has_project_history=parse_bool(args.has_project_history),
            )
        )
        return 0

    if args.root is None:
        fail("--root is required for sync-gemini")
    return sync_gemini(contract, pathlib.Path(args.root).expanduser().resolve(), args.mode)


if __name__ == "__main__":
    raise SystemExit(main())
