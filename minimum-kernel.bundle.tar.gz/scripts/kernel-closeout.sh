#!/usr/bin/env bash
set -euo pipefail

ROOT="$HOME/.gemini"
OBJECTIVE=""
STATUS="ready"
NEXT_STEP=""
HISTORY_SUMMARY=""
CAPTURE_SUMMARY=""
TENANT_DOMAIN=""
KIND="auto"
ENTITIES_INPUT=""
VERIFY_MODE="runtime"
CAPTURE_MODE="auto"
WRITE_HISTORY=1
BUILD_BLUEPRINTS=1
JSON_OUTPUT=0
declare -a COMPLETED_ITEMS=()
declare -a ACTIVE_FILES=()
declare -a RESUME_COMMANDS=()

usage() {
  cat <<'EOF'
Usage:
  kernel-closeout.sh [options]

Options:
  --root PATH
  --objective TEXT
  --completed TEXT              Repeatable; replaces last_completed_task.
  --status TEXT                 Default: ready.
  --next-step TEXT
  --active-file PATH            Repeatable; replaces active_files when provided.
  --resume-command TEXT         Repeatable; replaces resume_commands when provided.
  --history-summary TEXT        Defaults to completed items or objective.
  --skip-history
  --capture auto|write|skip     Default: auto.
  --capture-summary TEXT        Used with --capture write.
  --tenant-domain DOMAIN        Used with --capture write.
  --kind KIND|auto              Used with --capture write.
  --entities JSON_OR_CSV        Used with --capture write.
  --no-blueprints
  --verify runtime|full|core|none
  --json

Description:
  Single closeout trigger for standard/deep kernel work. It updates live state,
  writes the durable history ledger, regenerates blueprints, verifies, and then
  captures a KI when the final verified state says the change is durable.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --root)
      ROOT="$2"
      shift 2
      ;;
    --objective)
      OBJECTIVE="$2"
      shift 2
      ;;
    --completed)
      COMPLETED_ITEMS+=("$2")
      shift 2
      ;;
    --status)
      STATUS="$2"
      shift 2
      ;;
    --next-step)
      NEXT_STEP="$2"
      shift 2
      ;;
    --active-file)
      ACTIVE_FILES+=("$2")
      shift 2
      ;;
    --resume-command)
      RESUME_COMMANDS+=("$2")
      shift 2
      ;;
    --history-summary)
      HISTORY_SUMMARY="$2"
      shift 2
      ;;
    --skip-history)
      WRITE_HISTORY=0
      shift
      ;;
    --capture)
      CAPTURE_MODE="$2"
      shift 2
      ;;
    --capture-summary)
      CAPTURE_SUMMARY="$2"
      shift 2
      ;;
    --tenant-domain)
      TENANT_DOMAIN="$2"
      shift 2
      ;;
    --kind)
      KIND="$2"
      shift 2
      ;;
    --entities)
      ENTITIES_INPUT="$2"
      shift 2
      ;;
    --no-blueprints)
      BUILD_BLUEPRINTS=0
      shift
      ;;
    --verify)
      VERIFY_MODE="$2"
      shift 2
      ;;
    --json)
      JSON_OUTPUT=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unexpected argument: $1" >&2
      usage
      exit 1
      ;;
  esac
done

case "$VERIFY_MODE" in
  runtime|full|core|none) ;;
  *)
    echo "Unsupported --verify mode: $VERIFY_MODE" >&2
    exit 1
    ;;
esac

case "$CAPTURE_MODE" in
  auto|write|skip) ;;
  *)
    echo "Unsupported --capture mode: $CAPTURE_MODE" >&2
    exit 1
    ;;
esac

ROOT="$(cd "$ROOT" && pwd -P)"
STATECTL="$ROOT/scripts/statectl.sh"
LOGCTL="$ROOT/scripts/logctl.sh"
CAPTURE_KI="$ROOT/scripts/capture-ki.sh"
BUILD_BLUEPRINTS_SCRIPT="$ROOT/scripts/build-blueprints.sh"
VERIFY_BLUEPRINT_MANIFEST="$ROOT/scripts/verify-blueprint-manifest.sh"
GEMINI_DOCTOR="$ROOT/scripts/gemini-doctor.sh"
RUN_CORE_EVALS="$ROOT/scripts/run-core-evals.sh"

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || {
    echo "Missing required command: $1" >&2
    exit 1
  }
}

require_file() {
  [[ -f "$1" ]] || {
    echo "Missing required file: $1" >&2
    exit 1
  }
}

require_cmd jq
require_file "$STATECTL"
require_file "$LOGCTL"
require_file "$CAPTURE_KI"
if (( BUILD_BLUEPRINTS == 1 )); then
  require_file "$BUILD_BLUEPRINTS_SCRIPT"
  require_file "$VERIFY_BLUEPRINT_MANIFEST"
fi
case "$VERIFY_MODE" in
  runtime|full)
    require_file "$GEMINI_DOCTOR"
    ;;
  core)
    require_file "$RUN_CORE_EVALS"
    ;;
esac

json_array_from_args() {
  jq -cn '$ARGS.positional' --args "$@"
}

json_array_from_array() {
  local count="$1"
  shift || true
  if [[ "$count" -eq 0 ]]; then
    jq -cn '[]'
  else
    json_array_from_args "$@"
  fi
}

join_items() {
  local sep="$1"
  shift || true
  local out=""
  local item
  for item in "$@"; do
    if [[ -z "$out" ]]; then
      out="$item"
    else
      out="${out}${sep}${item}"
    fi
  done
  printf '%s' "$out"
}

current_objective() {
  jq -r '.objective // ""' "$ROOT/.agent/current_state.json" 2>/dev/null || true
}

if [[ -z "$HISTORY_SUMMARY" ]]; then
  if [[ "${#COMPLETED_ITEMS[@]}" -gt 0 ]]; then
    HISTORY_SUMMARY="$(join_items "; " "${COMPLETED_ITEMS[@]}")"
  elif [[ -n "$OBJECTIVE" ]]; then
    HISTORY_SUMMARY="$OBJECTIVE"
  else
    HISTORY_SUMMARY="$(current_objective)"
  fi
fi

if [[ -z "$HISTORY_SUMMARY" && "$WRITE_HISTORY" == "1" ]]; then
  echo "history summary is empty; pass --history-summary or --completed" >&2
  exit 1
fi

build_state_patch() {
  local verification_status="$1"
  local freshness_state="$2"
  local completed_json active_json resume_json
  completed_json="$(json_array_from_array "${#COMPLETED_ITEMS[@]}" "${COMPLETED_ITEMS[@]+"${COMPLETED_ITEMS[@]}"}")"
  active_json="$(json_array_from_array "${#ACTIVE_FILES[@]}" "${ACTIVE_FILES[@]+"${ACTIVE_FILES[@]}"}")"
  resume_json="$(json_array_from_array "${#RESUME_COMMANDS[@]}" "${RESUME_COMMANDS[@]+"${RESUME_COMMANDS[@]}"}")"
  jq -cn \
    --arg objective "$OBJECTIVE" \
    --arg status "$STATUS" \
    --arg next_step "$NEXT_STEP" \
    --arg verification_status "$verification_status" \
    --arg freshness_state "$freshness_state" \
    --argjson completed "$completed_json" \
    --argjson active_files "$active_json" \
    --argjson resume_commands "$resume_json" \
    '
    {}
    | if $objective != "" then .objective = $objective else . end
    | if $status != "" then .status = $status else . end
    | if $next_step != "" then .next_step = $next_step else . end
    | if ($completed | length) > 0 then .last_completed_task = $completed else . end
    | if ($active_files | length) > 0 then .active_files = $active_files else . end
    | if ($resume_commands | length) > 0 then .resume_commands = $resume_commands else . end
    | .verification_status = $verification_status
    | .freshness_state = $freshness_state
    '
}

run_step() {
  local label="$1"
  shift
  printf 'INFO: %s\n' "$label" >&2
  set +e
  if (( JSON_OUTPUT == 1 )); then
    "$@" >&2
  else
    "$@"
  fi
  local status=$?
  set -e
  if [[ "$status" -eq 0 ]]; then
    printf 'INFO: %s passed.\n' "$label" >&2
    return 0
  fi
  printf 'ERROR: %s failed.\n' "$label" >&2
  return "$status"
}

append_failure() {
  local item="$1"
  if [[ -z "${FAILED_STEPS:-}" ]]; then
    FAILED_STEPS="$item"
  else
    FAILED_STEPS="${FAILED_STEPS}; ${item}"
  fi
}

initial_patch="$(build_state_patch "PENDING: kernel-closeout verification in progress." "handoff")"
bash "$STATECTL" patch --root "$ROOT" --patch-json "$initial_patch" >/dev/null

HISTORY_STATUS="skipped"
BLUEPRINT_STATUS="skipped"
VERIFY_STATUS="skipped"
CAPTURE_STATUS="skipped"
CAPTURE_PATH=""
FAILED_STEPS=""

if (( WRITE_HISTORY == 1 )); then
  if run_step "Writing project history" bash "$LOGCTL" history --root "$ROOT" --summary "$HISTORY_SUMMARY"; then
    HISTORY_STATUS="written"
  else
    HISTORY_STATUS="failed"
    append_failure "history"
  fi
fi

if (( BUILD_BLUEPRINTS == 1 )); then
  if run_step "Regenerating blueprints" bash "$BUILD_BLUEPRINTS_SCRIPT" "$ROOT" && \
     run_step "Verifying blueprint manifest" bash "$VERIFY_BLUEPRINT_MANIFEST" "$ROOT"; then
    BLUEPRINT_STATUS="pass"
  else
    BLUEPRINT_STATUS="failed"
    append_failure "blueprints"
  fi
fi

case "$VERIFY_MODE" in
  runtime)
    if run_step "Running runtime doctor" bash "$GEMINI_DOCTOR" --runtime "$ROOT"; then
      VERIFY_STATUS="pass"
    else
      VERIFY_STATUS="failed"
      append_failure "runtime doctor"
    fi
    ;;
  full)
    if run_step "Running full doctor" bash "$GEMINI_DOCTOR" --full "$ROOT"; then
      VERIFY_STATUS="pass"
    else
      VERIFY_STATUS="failed"
      append_failure "full doctor"
    fi
    ;;
  core)
    if run_step "Running core evals" bash "$RUN_CORE_EVALS" "$ROOT"; then
      VERIFY_STATUS="pass"
    else
      VERIFY_STATUS="failed"
      append_failure "core evals"
    fi
    ;;
  none)
    VERIFY_STATUS="not_run"
    ;;
esac

if [[ -n "$FAILED_STEPS" ]]; then
  final_verification="FAIL: kernel-closeout failed during ${FAILED_STEPS}."
  final_patch="$(build_state_patch "$final_verification" "stale")"
  bash "$STATECTL" patch --root "$ROOT" --patch-json "$final_patch" >/dev/null || true
  bash "$STATECTL" assert-sync --root "$ROOT" >/dev/null || true
  if (( JSON_OUTPUT == 1 )); then
    jq -n \
      --arg result "FAIL" \
      --arg failed_steps "$FAILED_STEPS" \
      --arg history "$HISTORY_STATUS" \
      --arg blueprints "$BLUEPRINT_STATUS" \
      --arg verify "$VERIFY_STATUS" \
      '{result:$result, failed_steps:$failed_steps, history:$history, blueprints:$blueprints, verification:$verify}'
  fi
  exit 1
fi

if [[ "$VERIFY_MODE" == "none" ]]; then
  final_result="PARTIAL"
  final_verification="PARTIAL: kernel-closeout ran with --verify none; history=${HISTORY_STATUS}; blueprints=${BLUEPRINT_STATUS}."
else
  final_result="PASS"
  final_verification="PASS: kernel-closeout verify=${VERIFY_MODE}; history=${HISTORY_STATUS}; blueprints=${BLUEPRINT_STATUS}."
fi

final_patch="$(build_state_patch "$final_verification" "fresh")"
bash "$STATECTL" patch --root "$ROOT" --patch-json "$final_patch" >/dev/null

if [[ "$final_result" == "PASS" ]]; then
  case "$CAPTURE_MODE" in
    auto)
      if CAPTURE_OUTPUT="$(bash "$CAPTURE_KI" --root "$ROOT" --suggest-from-current-state --json --write 2>&1)"; then
        CAPTURE_STATUS="$(jq -r '.result // "unknown"' <<< "$CAPTURE_OUTPUT" 2>/dev/null || printf 'unknown')"
        CAPTURE_PATH="$(jq -r '.ki_path // ""' <<< "$CAPTURE_OUTPUT" 2>/dev/null || true)"
      else
        CAPTURE_STATUS="failed"
        append_failure "capture"
      fi
      ;;
    write)
      [[ -n "$CAPTURE_SUMMARY" ]] || CAPTURE_SUMMARY="$HISTORY_SUMMARY"
      capture_args=(--root "$ROOT" --summary "$CAPTURE_SUMMARY" --kind "$KIND" --source-workflow "kernel-closeout.sh" --write)
      [[ -n "$TENANT_DOMAIN" ]] && capture_args+=(--tenant-domain "$TENANT_DOMAIN")
      [[ -n "$ENTITIES_INPUT" ]] && capture_args+=(--entities "$ENTITIES_INPUT")
      if CAPTURE_OUTPUT="$(bash "$CAPTURE_KI" "${capture_args[@]}" 2>&1)"; then
        CAPTURE_STATUS="$(jq -r '.result // "unknown"' <<< "$CAPTURE_OUTPUT" 2>/dev/null || printf 'unknown')"
        CAPTURE_PATH="$(jq -r '.ki_path // ""' <<< "$CAPTURE_OUTPUT" 2>/dev/null || true)"
      else
        CAPTURE_STATUS="failed"
        append_failure "capture"
      fi
      ;;
    skip)
      CAPTURE_STATUS="skipped"
      ;;
  esac
fi

if [[ -n "$FAILED_STEPS" ]]; then
  final_verification="FAIL: kernel-closeout verification passed, but ${FAILED_STEPS} failed."
  final_patch="$(build_state_patch "$final_verification" "stale")"
  bash "$STATECTL" patch --root "$ROOT" --patch-json "$final_patch" >/dev/null || true
  bash "$STATECTL" assert-sync --root "$ROOT" >/dev/null || true
  exit 1
fi

if [[ "$final_result" == "PASS" ]]; then
  final_verification="${final_verification} capture=${CAPTURE_STATUS}"
  [[ -n "$CAPTURE_PATH" ]] && final_verification="${final_verification} (${CAPTURE_PATH})"
  final_verification="${final_verification}."
  final_patch="$(build_state_patch "$final_verification" "fresh")"
  bash "$STATECTL" patch --root "$ROOT" --patch-json "$final_patch" >/dev/null
fi

bash "$STATECTL" assert-sync --root "$ROOT" >/dev/null

if (( JSON_OUTPUT == 1 )); then
  jq -n \
    --arg result "$final_result" \
    --arg history "$HISTORY_STATUS" \
    --arg blueprints "$BLUEPRINT_STATUS" \
    --arg verify "$VERIFY_STATUS" \
    --arg capture "$CAPTURE_STATUS" \
    --arg capture_path "$CAPTURE_PATH" \
    '{result:$result, history:$history, blueprints:$blueprints, verification:$verify, capture:$capture} + (if $capture_path != "" then {capture_path:$capture_path} else {} end)'
else
  printf 'SUMMARY: %s history=%s blueprints=%s verification=%s capture=%s\n' \
    "$final_result" "$HISTORY_STATUS" "$BLUEPRINT_STATUS" "$VERIFY_STATUS" "$CAPTURE_STATUS"
fi
