#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

if [[ "${PORTABLE_KERNEL_INTERNAL_CALL:-0}" != "1" && -f "$SCRIPT_ROOT/portable-kernel.sh" ]]; then
  exec bash "$SCRIPT_ROOT/portable-kernel.sh" regen --root "${1:-$SCRIPT_ROOT}"
fi

ROOT="${1:-$HOME/.gemini}"
BLUEPRINTS="$ROOT/GEMINI_BLUEPRINTS.md"
WORKFLOWS_DIR="$ROOT/workflows"
AUTOFIX_SKILL_DIR="$ROOT/skills/autofix"
AUTOFIX_TEMPLATE_DIR="$ROOT/templates/autofix"
WORKFLOWS_INDEX_RENDERER="$ROOT/scripts/render-workflows-index.sh"
BLUEPRINT_MANIFEST_BUILDER="$ROOT/scripts/build-blueprint-manifest.sh"
PORTABLE_OUTPUT_DIR="$ROOT/.portable"
PORTABLE_OUTPUT_TARBALL="$PORTABLE_OUTPUT_DIR/minimum-kernel.bundle.tar.gz"
PORTABLE_OUTPUT_MANIFEST="$PORTABLE_OUTPUT_DIR/bundle_manifest.json"
PORTABLE_ROOT_TARBALL="$ROOT/minimum-kernel.bundle.tar.gz"

TEMP_BLUEPRINT="$(mktemp "${TMPDIR:-/tmp}/gemini-blueprints.XXXXXX")"
SECTION_TMP="$(mktemp "${TMPDIR:-/tmp}/gemini-blueprints-section.XXXXXX")"
SEEN_TMP="$(mktemp "${TMPDIR:-/tmp}/gemini-blueprints-seen.XXXXXX")"
FILES_LIST_TMP="$(mktemp "${TMPDIR:-/tmp}/gemini-blueprints-files.XXXXXX")"
PORTABLE_STAGE="$(mktemp -d "${TMPDIR:-/tmp}/gemini-portable-stage.XXXXXX")"
PORTABLE_LIST="$(mktemp "${TMPDIR:-/tmp}/gemini-portable-list.XXXXXX")"
PORTABLE_MANIFEST="$(mktemp "${TMPDIR:-/tmp}/gemini-portable-manifest.XXXXXX")"
PORTABLE_TARBALL="$(mktemp "${TMPDIR:-/tmp}/gemini-portable-bundle.XXXXXX")"

cleanup() {
  rm -f "$TEMP_BLUEPRINT" "$SECTION_TMP" "$SEEN_TMP" "$FILES_LIST_TMP" "$PORTABLE_LIST" "$PORTABLE_MANIFEST" "$PORTABLE_TARBALL"
  rm -rf "$PORTABLE_STAGE"
}
trap cleanup EXIT

emit_block() {
  local file="$1"
  local index="$2"
  local name
  name="$(basename "$file")"
  local heading="### 2.${index} ${name}"
  [[ "$name" == "auto-pilot-workflow.md" ]] && heading+=" ⚡ (MASTER WORKFLOW)"

  {
    echo "$heading"
    echo '~~~~markdown'
    echo "<!-- BEGIN: ${name} -->"
    cat "$file"
    if [[ -n "$(tail -c 1 "$file" 2>/dev/null)" ]]; then
      echo ""
    fi
    echo "<!-- END: ${name} -->"
    echo '~~~~'
    echo ""
  } >> "$SECTION_TMP"
}

emit_portable_block() {
  local file="$1"
  local label="$2"
  local fence="$3"
  {
    echo "#### $label"
    echo "~~~~$fence"
    echo "<!-- BEGIN: ${label} -->"
    cat "$file"
    if [[ -n "$(tail -c 1 "$file" 2>/dev/null)" ]]; then
      echo ""
    fi
    echo "<!-- END: ${label} -->"
    echo '~~~~'
    echo ""
  } >> "$SECTION_TMP"
}

copy_path() {
  local source="$1"
  local target="$2"
  [[ -e "$source" ]] || return 0
  mkdir -p "$(dirname "$target")"
  if [[ -d "$source" ]]; then
    cp -R "$source" "$target"
  else
    cp "$source" "$target"
  fi
}

stage_portable_bundle() {
  local stage="$PORTABLE_STAGE"
  mkdir -p "$stage/.portable" "$stage/knowledge/global_patterns" "$stage/knowledge/advisories" "$stage/knowledge/global_profile" "$stage/logs" "$stage/state/traces"

  for dir in config rules scripts workflows blueprints; do
    [[ -d "$ROOT/$dir" ]] || continue
    copy_path "$ROOT/$dir" "$stage/$dir"
  done

  find "$stage" -type d -name '_DEPRECATED_TRASH' -prune -exec rm -rf {} +

  if [[ -d "$stage/scripts" ]]; then
    find "$stage/scripts" -type d -name '__pycache__' -prune -exec rm -rf {} +
    find "$stage/scripts" -maxdepth 1 -type f \( -name 'check-*' -o -name 'evaluate-*' \) -delete
    rm -f \
      "$stage/scripts/run-core-evals.sh" \
      "$stage/scripts/run-lean-evals.sh" \
      "$stage/scripts/gemini-doctor.sh" \
      "$stage/scripts/render-workflows-index.sh" \
      "$stage/scripts/antigravity-node-mcp-launch.sh" \
      "$stage/scripts/sanitize-antigravity-mcp-config.sh"
    rm -rf "$stage/scripts/doctor"
  fi

  if [[ -d "$stage/workflows" ]]; then
    rm -rf "$stage/workflows/_DEPRECATED_TRASH"
    rm -f "$stage/workflows/WORKFLOWS_INDEX.md"
    for workflow_file in "$stage"/workflows/*-workflow.md; do
      [[ -f "$workflow_file" ]] || continue
      status="$(sed -nE 's/^status:[[:space:]]*//p' "$workflow_file" 2>/dev/null | head -1)"
      if [[ "$status" == "adapter" || "$status" == "archived" ]]; then
        rm -f "$workflow_file"
      fi
    done
  fi

  if [[ -d "$ROOT/skills/autofix" ]]; then
    mkdir -p "$stage/skills"
    copy_path "$ROOT/skills/autofix" "$stage/skills/autofix"
  fi

  if [[ -d "$ROOT/templates/autofix" ]]; then
    mkdir -p "$stage/templates"
    copy_path "$ROOT/templates/autofix" "$stage/templates/autofix"
  fi

  for file in \
    state/approval-grants.json \
    state/plan-event.schema.json \
    state/post-publish-dispatch-queue.json \
    state/post-publish-dispatch-queue.schema.json \
    state/project_state.schema.json \
    state/run_state.json \
    state/read_contract.json \
    state/traces/trace.schema.json \
    state/traces/README.md \
    knowledge/.memory_maintenance.json \
    knowledge/metadata.json \
    knowledge/global_patterns/README.md \
    knowledge/advisories/README.md \
    knowledge/global_profile/README.md
  do
    copy_path "$ROOT/$file" "$stage/$file"
  done

  : > "$stage/logs/lightweight_audit.log"
  : > "$stage/state/traces/portable-bootstrap.jsonl"

  if [[ ! -f "$stage/knowledge/.memory_maintenance.json" ]]; then
    cat > "$stage/knowledge/.memory_maintenance.json" <<'EOF'
{
  "version": 1,
  "last_run_at": 0,
  "last_run_mode": "never",
  "last_reason": "never_run",
  "last_signal_count": 0,
  "last_scope": "global"
}
EOF
  fi

  if [[ ! -f "$stage/knowledge/metadata.json" ]]; then
    cat > "$stage/knowledge/metadata.json" <<'EOF'
{
  "_meta": {
    "description": "Portable global knowledge baseline.",
    "version": "v1",
    "created": "2026-04-15",
    "contracts": [
      "global_patterns",
      "advisories",
      "global_profile",
      "global_memory_maintenance_v1"
    ],
    "last_updated": "2026-04-15"
  }
}
EOF
  fi

  find "$stage" -name '.DS_Store' -delete

  (
    cd "$stage"
    find . -type f | sort | sed 's#^\./##' > "$PORTABLE_LIST"
  )

  jq -Rn '
    [inputs | select(length > 0)] as $paths
    | def component_for($path):
        if ($path | startswith(".portable/")) then "core_manifest"
        elif ($path | startswith("knowledge/")) then "memory"
        elif ($path | startswith("scripts/")) then "core_runtime"
        elif ($path | startswith("workflows/")) then "advanced_workflows"
        elif ($path | startswith("rules/") or startswith("config/") or startswith("state/")) then "core_runtime"
        elif ($path | startswith("logs/")) then "telemetry_on_demand"
        elif ($path | startswith("skills/") or startswith("templates/")) then "advanced_workflows"
        else "core_runtime"
        end;
      {
        version: 1,
        generated_at: now | todateiso8601,
        profile: "portable_minimum",
        portable_root_files: [
          "GEMINI.md",
          "MEMORY.md",
          "GEMINI_BLUEPRINTS.md",
          "portable-kernel.sh",
          "portable-kernel-windows.ps1",
          "minimum-kernel.bundle.tar.gz"
        ],
        component_contract: {
          core: ["rules/", "config/", "state/", ".portable/"],
          memory: ["knowledge/"],
          runtime_scripts: ["scripts/"],
          advanced_workflows: ["workflows/", "skills/autofix/", "templates/autofix/"],
          telemetry_on_demand: ["logs/"]
        },
        artifact_count: ($paths | length),
        categories: ($paths
          | map(split("/")[0])
          | group_by(.)
          | map({category: .[0], count: length})),
        artifacts: ($paths | map({
          path: .,
          category: (split("/")[0]),
          component: component_for(.)
        }))
      }
  ' < "$PORTABLE_LIST" > "$PORTABLE_MANIFEST"

  cp "$PORTABLE_MANIFEST" "$stage/.portable/bundle_manifest.json"

  tar -czf "$PORTABLE_TARBALL" -C "$stage" .
  mkdir -p "$PORTABLE_OUTPUT_DIR"
  cp "$PORTABLE_TARBALL" "$PORTABLE_OUTPUT_TARBALL"
  cp "$PORTABLE_TARBALL" "$PORTABLE_ROOT_TARBALL"
  cp "$PORTABLE_MANIFEST" "$PORTABLE_OUTPUT_MANIFEST"
}

emit_portable_bundle_section() {
  local index="$1"
  stage_portable_bundle

  {
    echo "### 2.${index} Portable Minimum Bundle"
    echo ""
    echo "> [!NOTE]"
    echo '> v9.2.3 mantiene el kit distribuible autocontenido en 6 archivos.'
    echo '> `minimum-kernel.bundle.tar.gz` es el sexto archivo portable oficial y vive en la raíz del kit.'
    echo '> `.portable/` es cache generada localmente por `bootstrap`, `regen` o `pack`; no es canon ni warmup.'
    echo '> Los launchers leen primero `minimum-kernel.bundle.tar.gz` en raíz; si falta, usan `.portable/minimum-kernel.bundle.tar.gz` como cache local.'
    echo '> El bundle incluye runtime scripts, workflows, reglas, configs, estado baseline y las superficies portables de `autofix`; no incluye MCP, registries de skills locales, eval fixtures, checks, scripts evaluate ni experimentos SLM/Hyperlayer.'
    echo ""
    echo "- Official payload: \`minimum-kernel.bundle.tar.gz\`"
    echo "- Generated cache bundle: \`.portable/minimum-kernel.bundle.tar.gz\`"
    echo "- Generated cache manifest: \`.portable/bundle_manifest.json\`"
    echo "- Blueprint policy: no base64 payload is embedded in this Markdown file."
    echo ""
    echo "~~~~json"
    cat "$PORTABLE_MANIFEST"
    echo "~~~~"
    echo ""
  } >> "$SECTION_TMP"
}

if [[ -x "$WORKFLOWS_INDEX_RENDERER" ]]; then
  "$WORKFLOWS_INDEX_RENDERER" --root "$ROOT" --write >/dev/null
fi

if [[ -x "$BLUEPRINT_MANIFEST_BUILDER" ]]; then
  bash "$BLUEPRINT_MANIFEST_BUILDER" "$ROOT" >/dev/null
fi

{
  echo "## 2. PORTABLE RECOVERY MANIFEST"
  echo ""
  echo "> [!NOTE]"
  echo "> Esta seccion ya no pega workflows completos como Markdown humano."
  echo "> El kit portable visible conserva exactamente 6 archivos raíz: \`GEMINI.md\`, \`MEMORY.md\`, \`GEMINI_BLUEPRINTS.md\`, \`portable-kernel.sh\`, \`portable-kernel-windows.ps1\` y \`minimum-kernel.bundle.tar.gz\`."
  echo "> Los tres primeros son canon semantico/documental; los dos launchers son entrypoints de plataforma; el sexto archivo es el payload portable oficial."
  echo "> \`.portable/\` se genera localmente como cache/recovery; no se distribuye como carpeta y no es parte del warmup."
  echo "> Los artefactos se restauran desde \`minimum-kernel.bundle.tar.gz\` o desde la cache local \`.portable/\`."
  echo "> \`autofix\` es el unico nombre canonico y restaurable para el loop eval-driven."
  echo ""
  echo "### 2.1 Artifact Summary"
  echo ""
  echo "| Kind | Count |"
  echo "|------|-------|"
  if [[ -f "$ROOT/blueprints/manifest.json" ]]; then
    jq -r '
      .artifacts
      | to_entries
      | group_by(.value.kind)
      | map({kind: .[0].value.kind, count: length})
      | sort_by(.kind)
      | .[]
      | "| `\(.kind)` | \(.count) |"
    ' "$ROOT/blueprints/manifest.json"
  fi
  echo ""
  echo "### 2.2 Restore Contract"
  echo ""
  echo "- El primer mensaje en Antigravity ejecuta \`probe\`, guia idioma/perfil, llama al launcher de plataforma y luego corre \`doctor\`."
  echo "- \`portable-kernel.sh bootstrap\` y \`portable-kernel-windows.ps1 bootstrap\` expanden el bundle completo sin prompts interactivos cuando el agente ya recopilo preferencias."
  echo "- \`portable-kernel.sh recover workflow:<name>\` restores from marker blocks when present, otherwise from the portable bundle."
  echo "- Core templates remain visible in section 1 for direct restore."
  echo "- User-facing routes and restore ids must use \`autofix\` only."
  echo ""
} > "$SECTION_TMP"

emit_portable_bundle_section 3

line_start="$(grep -nE '^## 2\. (WORKFLOWS CORE \(Contenido Completo\)|PORTABLE RECOVERY MANIFEST)' "$BLUEPRINTS" | cut -d: -f1 || true)"
line_end="$(grep -n '^## 3\. RECUPERACIÓN RÁPIDA' "$BLUEPRINTS" | cut -d: -f1 || true)"

if [[ -z "$line_start" ]]; then
  echo "Error: anchors for BLUEPRINTS section replacement were not found." >&2
  exit 1
fi
if [[ -z "$line_end" ]]; then
  line_end=$(( $(wc -l < "$BLUEPRINTS" | tr -d ' ') + 1 ))
fi

prefix_end=$((line_start - 1))
legacy_system_start="$(grep -n '^## 1\.5 SYSTEM CORE FILES (Runtime Recovery)' "$BLUEPRINTS" | cut -d: -f1 || true)"
if [[ -n "$legacy_system_start" ]]; then
  prefix_end=$((legacy_system_start - 1))
fi

head -n "$prefix_end" "$BLUEPRINTS" > "$TEMP_BLUEPRINT"
cat "$SECTION_TMP" >> "$TEMP_BLUEPRINT"
tail -n +"$line_end" "$BLUEPRINTS" >> "$TEMP_BLUEPRINT"

if cmp -s "$BLUEPRINTS" "$TEMP_BLUEPRINT"; then
  if [[ -x "$BLUEPRINT_MANIFEST_BUILDER" ]]; then
    bash "$BLUEPRINT_MANIFEST_BUILDER" "$ROOT" >/dev/null
  fi
  echo "BLUEPRINT_SYNC_OK_NO_CHANGES"
  exit 0
fi

cp "$TEMP_BLUEPRINT" "$BLUEPRINTS"
if [[ -x "$BLUEPRINT_MANIFEST_BUILDER" ]]; then
  bash "$BLUEPRINT_MANIFEST_BUILDER" "$ROOT" >/dev/null
fi
echo "BLUEPRINT_SYNC_APPLIED"
