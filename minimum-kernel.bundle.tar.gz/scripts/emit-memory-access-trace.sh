#!/usr/bin/env bash
set -euo pipefail

ROOT="$HOME/.gemini"
TRACE_FILE=""
RUN_ID=""
PHASE=""
WORKFLOW=""
MEMORY_SURFACES=""
SELECTION_MODE="strict_budget"
ESTIMATED_TOKENS="0"
FALLBACK_USED="false"
STALE_REJECTED="false"
INJECTED_LOCAL_KI_COUNT="0"
INJECTED_GLOBAL_KI_COUNT="0"
EXCLUDED_BY_BUDGET_COUNT="0"
ACTOR="memory_observer"
NOTES=""

usage() {
  cat <<'EOF'
Usage:
  emit-memory-access-trace.sh [--root PATH] [--trace-file PATH] --run-id ID --phase NAME --workflow FILE --memory-surfaces CSV [--selection-mode MODE] [--estimated-tokens N] [--fallback-used true|false] [--stale-rejected true|false] [--injected-local-ki-count N] [--injected-global-ki-count N] [--excluded-by-budget-count N] [--actor NAME] [--notes CSV]
EOF
}

csv_to_json_array() {
  local raw="$1"
  jq -cn --arg raw "$raw" '$raw | split(",") | map(gsub("^\\s+|\\s+$";"")) | map(select(length > 0))'
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --root) ROOT="$2"; shift 2 ;;
    --trace-file) TRACE_FILE="$2"; shift 2 ;;
    --run-id) RUN_ID="$2"; shift 2 ;;
    --phase) PHASE="$2"; shift 2 ;;
    --workflow) WORKFLOW="$2"; shift 2 ;;
    --memory-surfaces) MEMORY_SURFACES="$2"; shift 2 ;;
    --selection-mode) SELECTION_MODE="$2"; shift 2 ;;
    --estimated-tokens) ESTIMATED_TOKENS="$2"; shift 2 ;;
    --fallback-used) FALLBACK_USED="$2"; shift 2 ;;
    --stale-rejected) STALE_REJECTED="$2"; shift 2 ;;
    --injected-local-ki-count) INJECTED_LOCAL_KI_COUNT="$2"; shift 2 ;;
    --injected-global-ki-count) INJECTED_GLOBAL_KI_COUNT="$2"; shift 2 ;;
    --excluded-by-budget-count) EXCLUDED_BY_BUDGET_COUNT="$2"; shift 2 ;;
    --actor) ACTOR="$2"; shift 2 ;;
    --notes) NOTES="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unexpected argument: $1" >&2; usage; exit 1 ;;
  esac
done

[[ -n "$RUN_ID" && -n "$PHASE" && -n "$WORKFLOW" && -n "$MEMORY_SURFACES" ]] || {
  usage
  exit 1
}

case "$FALLBACK_USED" in
  true|false) ;;
  *) echo "--fallback-used must be true or false" >&2; exit 1 ;;
esac

case "$STALE_REJECTED" in
  true|false) ;;
  *) echo "--stale-rejected must be true or false" >&2; exit 1 ;;
esac

memory_surfaces_json="$(csv_to_json_array "$MEMORY_SURFACES")"

metadata_json="$(jq -cn \
  --argjson memory_surfaces "$memory_surfaces_json" \
  --arg selection_mode "$SELECTION_MODE" \
  --argjson estimated_tokens "${ESTIMATED_TOKENS}" \
  --argjson fallback_used "${FALLBACK_USED}" \
  --argjson stale_rejected "${STALE_REJECTED}" \
  --argjson injected_local_ki_count "${INJECTED_LOCAL_KI_COUNT}" \
  --argjson injected_global_ki_count "${INJECTED_GLOBAL_KI_COUNT}" \
  --argjson excluded_by_budget_count "${EXCLUDED_BY_BUDGET_COUNT}" \
  '{
    memory_surfaces: $memory_surfaces,
    selection_mode: $selection_mode,
    estimated_tokens: $estimated_tokens,
    fallback_used: $fallback_used,
    stale_rejected: $stale_rejected,
    injected_local_ki_count: $injected_local_ki_count,
    injected_global_ki_count: $injected_global_ki_count,
    excluded_by_budget_count: $excluded_by_budget_count
  }')"

cmd=(
  "$ROOT/scripts/emit-trace-event.sh"
  --root "$ROOT"
  --run-id "$RUN_ID"
  --event-type "memory_access"
  --actor "$ACTOR"
  --phase "memory-access:$PHASE"
  --status "passed"
  --workflows "$WORKFLOW"
  --checks "trace-contract,memory-contract"
  --notes "$NOTES"
  --primary-workflow "$WORKFLOW"
  --metadata-json "$metadata_json"
)

if [[ -n "$TRACE_FILE" ]]; then
  cmd+=(--trace-file "$TRACE_FILE")
fi

"${cmd[@]}"
