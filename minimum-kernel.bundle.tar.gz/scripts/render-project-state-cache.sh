#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-$HOME/.gemini}"
MODE="--check"

if [[ "${1:-}" == "--root" ]]; then
  ROOT="$2"
  shift 2
fi

while [[ $# -gt 0 ]]; do
  case "$1" in
    --root)
      ROOT="$2"
      shift 2
      ;;
    --check|--write|--print)
      MODE="$1"
      shift
      ;;
    -h|--help)
      cat <<'EOF'
Usage:
  render-project-state-cache.sh [--root PATH] [--check|--write|--print]

Description:
  Reads machine state from .agent/current_state.json and renders the
  regenerable .agent/project_state.json cache.
EOF
      exit 0
      ;;
    *)
      if [[ "$1" != --* && "$ROOT" == "$HOME/.gemini" ]]; then
        ROOT="$1"
        shift
      else
        echo "Unexpected argument: $1" >&2
        exit 1
      fi
      ;;
  esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CURRENT_STATE_RENDERER="$SCRIPT_DIR/render-current-state-md.sh"

[[ -f "$CURRENT_STATE_RENDERER" ]] || {
  echo "Missing current_state renderer: $CURRENT_STATE_RENDERER" >&2
  exit 1
}

if [[ "$MODE" == "--write" ]]; then
  bash "$CURRENT_STATE_RENDERER" --root "$ROOT" --write >/dev/null
elif [[ "$MODE" == "--check" ]]; then
  bash "$CURRENT_STATE_RENDERER" --root "$ROOT" --check >/dev/null
fi

python3 - "$ROOT" "$MODE" <<'PY'
import json
import pathlib
import sys


root = pathlib.Path(sys.argv[1]).expanduser().resolve()
mode = sys.argv[2]
current_path = root / ".agent" / "current_state.json"
project_path = root / ".agent" / "project_state.json"


def fail(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


def load_current_state() -> dict:
    if not current_path.exists():
        fail(f"Missing {current_path}")
    try:
        return json.loads(current_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        fail(f".agent/current_state.json is not valid JSON: {exc}")


def expect_type(meta: dict, key: str, expected: str) -> None:
    if key not in meta:
        fail(f"current_state missing key: {key}")
    value = meta[key]
    if expected == "array":
        ok = isinstance(value, list) and all(isinstance(item, str) for item in value)
    elif expected == "string":
        ok = isinstance(value, str) and len(value) > 0
    elif expected == "object":
        ok = isinstance(value, dict)
    elif expected == "integer":
        ok = isinstance(value, int)
    else:
        ok = False
    if not ok:
        fail(f"current_state key has wrong type: {key}")


def validate_meta(meta: dict) -> None:
    for key, typ in {
        "schema_version": "integer",
        "project": "string",
        "updated_at": "string",
        "objective": "string",
        "last_completed_task": "array",
        "status": "string",
        "blockers": "array",
        "active_files": "array",
        "resume_commands": "array",
        "next_step": "string",
        "verification_status": "string",
        "freshness_state": "string",
        "plan_state": "object",
    }.items():
        expect_type(meta, key, typ)
    plan_state = meta["plan_state"]
    for key in [
        "required",
        "source",
        "status",
        "updated_at",
        "content_hash",
        "memory_synced",
        "next_action",
        "producer_agent",
        "receipt_ref",
    ]:
        if key not in plan_state:
            fail(f"current_state.plan_state missing key: {key}")
    if not isinstance(plan_state["required"], bool):
        fail("current_state.plan_state.required must be boolean")
    if not isinstance(plan_state["memory_synced"], bool):
        fail("current_state.plan_state.memory_synced must be boolean")


def resume_brief(meta: dict) -> str:
    explicit = meta.get("resume_brief")
    if isinstance(explicit, str) and explicit.strip():
        return explicit.strip()[:220]
    first_task = meta["last_completed_task"][0] if meta["last_completed_task"] else meta["objective"]
    text = f"{first_task} Siguiente paso: {meta['next_step']}"
    return text[:220]


def render_cache(meta: dict, existing: dict) -> dict:
    if not isinstance(existing, dict):
        existing = {}
    plan_state = dict(meta["plan_state"])
    cache = dict(existing)
    cache["version"] = int(existing.get("version", 1) or 1)
    cache["generated_from"] = ".agent/current_state.json"
    cache["generated_by"] = "scripts/render-project-state-cache.sh"
    cache["do_not_edit"] = True
    cache["project"] = meta["project"]
    cache["updated_at"] = meta["updated_at"]
    cache["current_objective"] = meta["objective"]
    cache["current_task"] = meta["last_completed_task"][0] if meta["last_completed_task"] else meta["objective"]
    cache["status"] = meta["status"]
    cache["blockers"] = meta["blockers"]
    cache["active_files"] = meta["active_files"]
    cache["next_steps"] = [meta["next_step"]]
    cache["key_commands"] = meta["resume_commands"]
    if isinstance(meta.get("kernel_install"), dict):
        cache["kernel_install"] = meta["kernel_install"]
    cache.setdefault("notes", [])
    cache.setdefault("memory_refs", [])
    cache["current_session"] = {
        "objective": meta["objective"],
        "last_completed_task": "; ".join(meta["last_completed_task"]) if meta["last_completed_task"] else meta["objective"],
        "blockers": meta["blockers"],
        "active_files": meta["active_files"],
        "resume_commands": meta["resume_commands"],
        "resume_brief": resume_brief(meta),
        "next_step": meta["next_step"],
        "verification_status": meta["verification_status"],
        "last_snapshot_at": meta["updated_at"],
        "freshness_state": meta["freshness_state"],
        "plan_state": plan_state,
    }
    if isinstance(meta.get("kernel_install"), dict):
        cache["current_session"]["kernel_install"] = meta["kernel_install"]
    onboarding = cache.get("agent_onboarding")
    if isinstance(onboarding, dict):
        arch = onboarding.get("architecture_summary")
        if isinstance(arch, list):
            legacy_portable_summaries = {
                "Portable distribution is exactly four root files: GEMINI.md, MEMORY.md, GEMINI_BLUEPRINTS.md, and portable-kernel.sh.",
                "Portable distribution is exactly " + "fi" + "ve root files: GEMINI.md, MEMORY.md, GEMINI_BLUEPRINTS.md, portable-kernel.sh, and portable-kernel-windows.ps1.",
            }
            onboarding["architecture_summary"] = [
                "Portable distribution is exactly six root files: GEMINI.md, MEMORY.md, GEMINI_BLUEPRINTS.md, portable-kernel.sh, portable-kernel-windows.ps1, and minimum-kernel.bundle.tar.gz."
                if item in legacy_portable_summaries
                else item
                for item in arch
            ]
    return cache


def comparable(cache: dict) -> dict:
    session = cache.get("current_session", {})
    return {
        "updated_at": cache.get("updated_at"),
        "current_objective": cache.get("current_objective"),
        "generated_from": cache.get("generated_from"),
        "generated_by": cache.get("generated_by"),
        "do_not_edit": cache.get("do_not_edit"),
        "current_task": cache.get("current_task"),
        "status": cache.get("status"),
        "blockers": cache.get("blockers"),
        "active_files": cache.get("active_files"),
        "next_steps": cache.get("next_steps"),
        "key_commands": cache.get("key_commands"),
        "current_session": {
            "objective": session.get("objective"),
            "last_completed_task": session.get("last_completed_task"),
            "blockers": session.get("blockers"),
            "active_files": session.get("active_files"),
            "resume_commands": session.get("resume_commands"),
            "resume_brief": session.get("resume_brief"),
            "next_step": session.get("next_step"),
            "verification_status": session.get("verification_status"),
            "last_snapshot_at": session.get("last_snapshot_at"),
            "freshness_state": session.get("freshness_state"),
            "plan_state": session.get("plan_state"),
            "kernel_install": session.get("kernel_install"),
        },
        "kernel_install": cache.get("kernel_install"),
    }


meta = load_current_state()
validate_meta(meta)

existing = {}
if project_path.exists():
    try:
        existing = json.loads(project_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        fail(f".agent/project_state.json is not valid JSON: {exc}")

rendered = render_cache(meta, existing)
text = json.dumps(rendered, ensure_ascii=False, indent=2) + "\n"

if mode == "--print":
    print(text, end="")
elif mode == "--write":
    project_path.parent.mkdir(parents=True, exist_ok=True)
    project_path.write_text(text, encoding="utf-8")
    print("PROJECT_STATE_CACHE_WRITTEN")
elif mode == "--check":
    if not project_path.exists():
        fail(".agent/project_state.json is missing")
    if comparable(existing) != comparable(rendered):
        print("ERROR: .agent/project_state.json drifted from .agent/current_state.json", file=sys.stderr)
        print(json.dumps({"expected": comparable(rendered), "actual": comparable(existing)}, ensure_ascii=False, indent=2), file=sys.stderr)
        raise SystemExit(1)
    print("PROJECT_STATE_CACHE_IN_SYNC")
else:
    fail(f"Unknown mode: {mode}")
PY
