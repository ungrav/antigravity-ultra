#!/usr/bin/env bash
set -euo pipefail

ROOT="$HOME/.gemini"
COMMAND="${1:-}"
PATCH_JSON=""
PLAN_JSON=""
OBJECTIVE=""
STATUS=""
NEXT_STEP=""

shift || true

usage() {
  cat <<'EOF'
Usage:
  statectl.sh <check|get|patch|update-session|set-plan-state|regen-cache|assert-sync> [options]

Options:
  --root PATH
  --patch-json JSON
  --json JSON
  --objective TEXT
  --status TEXT
  --next-step TEXT
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --root)
      ROOT="$2"
      shift 2
      ;;
    --patch-json)
      PATCH_JSON="$2"
      shift 2
      ;;
    --json)
      PLAN_JSON="$2"
      shift 2
      ;;
    --objective)
      OBJECTIVE="$2"
      shift 2
      ;;
    --status)
      STATUS="$2"
      shift 2
      ;;
    --next-step)
      NEXT_STEP="$2"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unexpected argument: $1" >&2
      usage
      exit 1
      ;;
  esac
done

[[ -n "$COMMAND" ]] || {
  usage
  exit 1
}

ROOT="$(cd "$ROOT" && pwd -P)"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CURRENT_STATE_JSON="$ROOT/.agent/current_state.json"
CURRENT_STATE_MD="$ROOT/.agent/current_state.md"
if [[ -f "$ROOT/scripts/render-project-state-cache.sh" ]]; then
  CACHE_RENDERER="$ROOT/scripts/render-project-state-cache.sh"
else
  CACHE_RENDERER="$SCRIPT_DIR/render-project-state-cache.sh"
fi
if [[ -f "$ROOT/scripts/render-current-state-md.sh" ]]; then
  CURRENT_STATE_RENDERER="$ROOT/scripts/render-current-state-md.sh"
else
  CURRENT_STATE_RENDERER="$SCRIPT_DIR/render-current-state-md.sh"
fi

require_renderer() {
  [[ -f "$CACHE_RENDERER" ]] || {
    echo "Missing renderer: $CACHE_RENDERER" >&2
    exit 1
  }
  [[ -f "$CURRENT_STATE_RENDERER" ]] || {
    echo "Missing current_state renderer: $CURRENT_STATE_RENDERER" >&2
    exit 1
  }
}

now_utc() {
  date -u +"%Y-%m-%dT%H:%M:%SZ"
}

current_state_get() {
  python3 - "$CURRENT_STATE_JSON" "$CURRENT_STATE_MD" <<'PY'
import json
import pathlib
import sys

json_path = pathlib.Path(sys.argv[1])
md_path = pathlib.Path(sys.argv[2])


def load_legacy(path: pathlib.Path) -> dict:
    lines = path.read_text(encoding="utf-8").splitlines()
    if len(lines) < 3 or lines[0].strip() != "---":
        raise SystemExit("Missing .agent/current_state.json")
    end = None
    for idx, line in enumerate(lines[1:], start=1):
        if line.strip() == "---":
            end = idx
            break
    if end is None:
        raise SystemExit(".agent/current_state.md legacy frontmatter is not closed")
    meta = json.loads("\n".join(lines[1:end]).strip())
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return meta


if json_path.exists():
    meta = json.loads(json_path.read_text(encoding="utf-8"))
elif md_path.exists():
    meta = load_legacy(md_path)
else:
    raise SystemExit("Missing .agent/current_state.json")

if not isinstance(meta.get("plan_state"), dict):
    raise SystemExit("current_state missing plan_state object")
print(json.dumps(meta, ensure_ascii=False, separators=(",", ":")))
PY
}

current_state_write() {
  local mode="$1"
  local payload="${2:-}"
  local now="${3:-$(now_utc)}"
  mkdir -p "$ROOT/.agent"
  local tmp
  tmp="$(mktemp "$ROOT/.agent/current_state.json.XXXXXX")"
  python3 - "$CURRENT_STATE_JSON" "$CURRENT_STATE_MD" "$tmp" "$mode" "$payload" "$now" <<'PY'
import json
import pathlib
import sys

json_path = pathlib.Path(sys.argv[1])
md_path = pathlib.Path(sys.argv[2])
tmp_path = pathlib.Path(sys.argv[3])
mode = sys.argv[4]
payload = sys.argv[5]
now = sys.argv[6]


def deep_merge(base, patch):
    for key, value in patch.items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            deep_merge(base[key], value)
        else:
            base[key] = value
    return base


def load_legacy(path: pathlib.Path) -> dict:
    lines = path.read_text(encoding="utf-8").splitlines()
    if len(lines) < 3 or lines[0].strip() != "---":
        raise SystemExit("Missing .agent/current_state.json")
    end = None
    for idx, line in enumerate(lines[1:], start=1):
        if line.strip() == "---":
            end = idx
            break
    if end is None:
        raise SystemExit(".agent/current_state.md legacy frontmatter is not closed")
    return json.loads("\n".join(lines[1:end]).strip())


if json_path.exists():
    meta = json.loads(json_path.read_text(encoding="utf-8"))
elif md_path.exists():
    meta = load_legacy(md_path)
else:
    raise SystemExit(f"Missing {json_path}")

if mode == "patch":
    patch = json.loads(payload)
    if not isinstance(patch, dict):
        raise SystemExit("--patch-json must be an object")
    meta = deep_merge(meta, patch)
    if "updated_at" not in patch:
        meta["updated_at"] = now
elif mode == "plan":
    plan_state = json.loads(payload)
    if not isinstance(plan_state, dict):
        raise SystemExit("--json must be a plan_state object")
    meta["plan_state"] = plan_state
    meta["updated_at"] = plan_state.get("updated_at") or now
elif mode == "session":
    patch = json.loads(payload)
    for key, value in patch.items():
        if value is not None:
            meta[key] = value
    meta["updated_at"] = now
else:
    raise SystemExit(f"Unknown statectl mode: {mode}")

if not isinstance(meta.get("plan_state"), dict):
    raise SystemExit("current_state missing plan_state object")
tmp_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
PY
  mv "$tmp" "$CURRENT_STATE_JSON"
}

regen_views() {
  require_renderer
  bash "$CURRENT_STATE_RENDERER" --root "$ROOT" --write >/dev/null
  bash "$CURRENT_STATE_RENDERER" --root "$ROOT" --check >/dev/null
  bash "$CACHE_RENDERER" --root "$ROOT" --write >/dev/null
  bash "$CACHE_RENDERER" --root "$ROOT" --check >/dev/null
}

case "$COMMAND" in
  get)
    current_state_get
    ;;
  check|assert-sync)
    require_renderer
    current_state_get >/dev/null
    bash "$CURRENT_STATE_RENDERER" --root "$ROOT" --check >/dev/null
    bash "$CACHE_RENDERER" --root "$ROOT" --check >/dev/null
    echo "STATECTL_OK"
    ;;
  regen-cache)
    regen_views
    echo "STATECTL_CACHE_REGENERATED"
    ;;
  patch)
    [[ -n "$PATCH_JSON" ]] || {
      echo "patch requires --patch-json" >&2
      exit 1
    }
    current_state_write patch "$PATCH_JSON" "$(now_utc)"
    regen_views
    echo "STATECTL_PATCHED"
    ;;
  update-session)
    payload="$(jq -cn \
      --arg objective "$OBJECTIVE" \
      --arg status "$STATUS" \
      --arg next_step "$NEXT_STEP" \
      '{objective:(if $objective == "" then null else $objective end), status:(if $status == "" then null else $status end), next_step:(if $next_step == "" then null else $next_step end)}')"
    current_state_write session "$payload" "$(now_utc)"
    regen_views
    echo "STATECTL_SESSION_UPDATED"
    ;;
  set-plan-state)
    [[ -n "$PLAN_JSON" ]] || {
      echo "set-plan-state requires --json" >&2
      exit 1
    }
    current_state_write plan "$PLAN_JSON" "$(now_utc)"
    regen_views
    echo "STATECTL_PLAN_STATE_UPDATED"
    ;;
  *)
    echo "Unknown command: $COMMAND" >&2
    usage
    exit 1
    ;;
esac
