#!/usr/bin/env bash
set -euo pipefail

ROOT="$HOME/.gemini"
PROJECT_ROOT=""
SOURCE_HOST="manual_script"
PRODUCER_AGENT="codex"
APPROVAL_SOURCE=""
EVENT_ID=""
TIMESTAMP=""
CONTENT_HASH=""
REQUIRED=""
SUMMARY=""
TENANT_DOMAIN="kernel"
NEXT_ACTION=""
ROLLBACK="Emitir plan_superseded o plan_reset."
ORIGIN_WORKFLOW="manual-planctl"
SUBCOMMAND="${1:-}"

shift || true

usage() {
  cat <<'EOF'
Usage:
  planctl.sh <required|drafted|presented|recover-presented|approve|approve-current|supersede|reset> [options]

Common options:
  --root PATH
  --project-root PATH
  --event-id ID
  --timestamp ISO-8601
  --source-host NAME
  --producer-agent antigravity_native|codex|gemini|claude|other
  --content-hash HASH

Subcommands:
  required  --required true|false
  drafted   --content-hash HASH
  presented --content-hash HASH
  recover-presented --content-hash HASH --summary TEXT [receipt flags]
  approve   --content-hash HASH --summary TEXT --approval-source SOURCE [receipt flags]
  approve-current --summary TEXT --approval-source chat|SOURCE [optional receipt flags]
  supersede --content-hash HASH --summary TEXT
  reset

Approve receipt flags:
  --tenant-domain NAME
  --objective TEXT
  --affected-surface VALUE      repeatable
  --impacted-file VALUE         repeatable
  --approved-phase VALUE        repeatable
  --validation-command VALUE    repeatable
  --constraint VALUE            repeatable
  --rollback TEXT
EOF
}

json_array() {
  if [[ "$#" -eq 0 ]]; then
    jq -cn '[]'
  else
    printf '%s\n' "$@" | jq -R . | jq -s .
  fi
}

now_utc() {
  date -u +"%Y-%m-%dT%H:%M:%SZ"
}

event_id() {
  if [[ -n "$EVENT_ID" ]]; then
    printf '%s' "$EVENT_ID"
  else
    printf 'planctl-%s-%s' "$SUBCOMMAND" "$(date -u +%Y%m%d%H%M%S)"
  fi
}

require_value() {
  local name="$1"
  local value="$2"
  [[ -n "$value" ]] || {
    echo "$SUBCOMMAND requires $name" >&2
    exit 1
  }
}

AFFECTED_SURFACES=()
IMPACTED_FILES=()
APPROVED_PHASES=()
VALIDATION_COMMANDS=()
CONSTRAINTS=()
OBJECTIVE=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --root)
      ROOT="$2"
      shift 2
      ;;
    --project-root)
      PROJECT_ROOT="$2"
      shift 2
      ;;
    --event-id)
      EVENT_ID="$2"
      shift 2
      ;;
    --timestamp)
      TIMESTAMP="$2"
      shift 2
      ;;
    --source-host)
      SOURCE_HOST="$2"
      shift 2
      ;;
    --producer-agent)
      PRODUCER_AGENT="$2"
      shift 2
      ;;
    --approval-source)
      APPROVAL_SOURCE="$2"
      shift 2
      ;;
    --content-hash)
      CONTENT_HASH="$2"
      shift 2
      ;;
    --required)
      REQUIRED="$2"
      shift 2
      ;;
    --summary)
      SUMMARY="$2"
      shift 2
      ;;
    --tenant-domain)
      TENANT_DOMAIN="$2"
      shift 2
      ;;
    --objective)
      OBJECTIVE="$2"
      shift 2
      ;;
    --affected-surface)
      AFFECTED_SURFACES+=("$2")
      shift 2
      ;;
    --impacted-file)
      IMPACTED_FILES+=("$2")
      shift 2
      ;;
    --approved-phase)
      APPROVED_PHASES+=("$2")
      shift 2
      ;;
    --validation-command)
      VALIDATION_COMMANDS+=("$2")
      shift 2
      ;;
    --constraint)
      CONSTRAINTS+=("$2")
      shift 2
      ;;
    --rollback)
      ROLLBACK="$2"
      shift 2
      ;;
    --origin-workflow)
      ORIGIN_WORKFLOW="$2"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unexpected argument: $1" >&2
      usage
      exit 1
      ;;
  esac
done

[[ -n "$SUBCOMMAND" ]] || {
  usage
  exit 1
}

ROOT="$(cd "$ROOT" && pwd -P)"
PROJECT_ROOT="${PROJECT_ROOT:-$ROOT}"
TIMESTAMP="${TIMESTAMP:-$(now_utc)}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -f "$ROOT/scripts/ingest-plan-event.sh" ]]; then
  INGESTOR="$ROOT/scripts/ingest-plan-event.sh"
else
  INGESTOR="$SCRIPT_DIR/ingest-plan-event.sh"
fi
if [[ -f "$ROOT/scripts/statectl.sh" ]]; then
  STATECTL="$ROOT/scripts/statectl.sh"
else
  STATECTL="$SCRIPT_DIR/statectl.sh"
fi
[[ -x "$INGESTOR" || -f "$INGESTOR" ]] || {
  echo "Missing plan event ingestor: $INGESTOR" >&2
  exit 1
}
[[ -x "$STATECTL" || -f "$STATECTL" ]] || {
  echo "Missing statectl helper: $STATECTL" >&2
  exit 1
}

if [[ "$APPROVAL_SOURCE" == "chat" ]]; then
  APPROVAL_SOURCE="chat_structured_command"
fi

case "$SUBCOMMAND" in
  required)
    require_value "--required" "$REQUIRED"
    [[ "$REQUIRED" == "true" || "$REQUIRED" == "false" ]] || {
      echo "--required must be true or false" >&2
      exit 1
    }
    EVENT_JSON="$(jq -cn \
      --arg event_id "$(event_id)" \
      --arg source_host "$SOURCE_HOST" \
      --arg producer_agent "$PRODUCER_AGENT" \
      --arg project_root "$PROJECT_ROOT" \
      --arg timestamp "$TIMESTAMP" \
      --arg origin_workflow "$ORIGIN_WORKFLOW" \
      --argjson required "$REQUIRED" \
      '{schema_version:3,event_id:$event_id,event_name:"plan_required_resolved",source_host:$source_host,producer_agent:$producer_agent,approval_source:null,project_root:$project_root,timestamp:$timestamp,origin_workflow:$origin_workflow,required:$required}')"
    ;;
  drafted)
    require_value "--content-hash" "$CONTENT_HASH"
    EVENT_JSON="$(jq -cn \
      --arg event_id "$(event_id)" \
      --arg source_host "$SOURCE_HOST" \
      --arg producer_agent "$PRODUCER_AGENT" \
      --arg project_root "$PROJECT_ROOT" \
      --arg timestamp "$TIMESTAMP" \
      --arg content_hash "$CONTENT_HASH" \
      --arg origin_workflow "$ORIGIN_WORKFLOW" \
      '{schema_version:3,event_id:$event_id,event_name:"plan_drafted",source_host:$source_host,producer_agent:$producer_agent,approval_source:null,project_root:$project_root,timestamp:$timestamp,origin_workflow:$origin_workflow,content_hash:$content_hash,next_action:"present_for_approval"}')"
    ;;
  presented)
    require_value "--content-hash" "$CONTENT_HASH"
    EVENT_JSON="$(jq -cn \
      --arg event_id "$(event_id)" \
      --arg source_host "$SOURCE_HOST" \
      --arg producer_agent "$PRODUCER_AGENT" \
      --arg project_root "$PROJECT_ROOT" \
      --arg timestamp "$TIMESTAMP" \
      --arg content_hash "$CONTENT_HASH" \
      --arg origin_workflow "$ORIGIN_WORKFLOW" \
      '{schema_version:3,event_id:$event_id,event_name:"plan_presented",source_host:$source_host,producer_agent:$producer_agent,approval_source:null,project_root:$project_root,timestamp:$timestamp,origin_workflow:$origin_workflow,content_hash:$content_hash,next_action:"wait_for_user_approval"}')"
    ;;
  recover-presented)
    require_value "--content-hash" "$CONTENT_HASH"
    require_value "--summary" "$SUMMARY"
    BASE_EVENT_ID="$(event_id)"
    RECOVER_ORIGIN="${ORIGIN_WORKFLOW}:recover-presented"
    RESET_JSON="$(jq -cn \
      --arg event_id "${BASE_EVENT_ID}-reset" \
      --arg source_host "$SOURCE_HOST" \
      --arg producer_agent "$PRODUCER_AGENT" \
      --arg project_root "$PROJECT_ROOT" \
      --arg timestamp "$TIMESTAMP" \
      --arg origin_workflow "$RECOVER_ORIGIN" \
      '{schema_version:3,event_id:$event_id,event_name:"plan_reset",source_host:$source_host,producer_agent:$producer_agent,approval_source:null,project_root:$project_root,timestamp:$timestamp,origin_workflow:$origin_workflow}')"
    REQUIRED_JSON="$(jq -cn \
      --arg event_id "${BASE_EVENT_ID}-required" \
      --arg source_host "$SOURCE_HOST" \
      --arg producer_agent "$PRODUCER_AGENT" \
      --arg project_root "$PROJECT_ROOT" \
      --arg timestamp "$TIMESTAMP" \
      --arg origin_workflow "$RECOVER_ORIGIN" \
      '{schema_version:3,event_id:$event_id,event_name:"plan_required_resolved",source_host:$source_host,producer_agent:$producer_agent,approval_source:null,project_root:$project_root,timestamp:$timestamp,origin_workflow:$origin_workflow,required:true}')"
    DRAFTED_JSON="$(jq -cn \
      --arg event_id "${BASE_EVENT_ID}-drafted" \
      --arg source_host "$SOURCE_HOST" \
      --arg producer_agent "$PRODUCER_AGENT" \
      --arg project_root "$PROJECT_ROOT" \
      --arg timestamp "$TIMESTAMP" \
      --arg content_hash "$CONTENT_HASH" \
      --arg origin_workflow "$RECOVER_ORIGIN" \
      '{schema_version:3,event_id:$event_id,event_name:"plan_drafted",source_host:$source_host,producer_agent:$producer_agent,approval_source:null,project_root:$project_root,timestamp:$timestamp,origin_workflow:$origin_workflow,content_hash:$content_hash,next_action:"present_for_approval"}')"
    PRESENTED_JSON="$(jq -cn \
      --arg event_id "${BASE_EVENT_ID}-presented" \
      --arg source_host "$SOURCE_HOST" \
      --arg producer_agent "$PRODUCER_AGENT" \
      --arg project_root "$PROJECT_ROOT" \
      --arg timestamp "$TIMESTAMP" \
      --arg content_hash "$CONTENT_HASH" \
      --arg origin_workflow "$RECOVER_ORIGIN" \
      '{schema_version:3,event_id:$event_id,event_name:"plan_presented",source_host:$source_host,producer_agent:$producer_agent,approval_source:null,project_root:$project_root,timestamp:$timestamp,origin_workflow:$origin_workflow,content_hash:$content_hash,next_action:"wait_for_user_approval"}')"
    bash "$INGESTOR" --root "$ROOT" --event-json "$RESET_JSON" >/dev/null
    bash "$INGESTOR" --root "$ROOT" --event-json "$REQUIRED_JSON" >/dev/null
    bash "$INGESTOR" --root "$ROOT" --event-json "$DRAFTED_JSON" >/dev/null
    bash "$INGESTOR" --root "$ROOT" --event-json "$PRESENTED_JSON"
    exit 0
    ;;
  approve)
    require_value "--content-hash" "$CONTENT_HASH"
    require_value "--summary" "$SUMMARY"
    require_value "--approval-source" "$APPROVAL_SOURCE"
    OBJECTIVE="${OBJECTIVE:-$SUMMARY}"
    [[ "${#AFFECTED_SURFACES[@]}" -gt 0 ]] || AFFECTED_SURFACES=("plan_state")
    [[ "${#IMPACTED_FILES[@]}" -gt 0 ]] || IMPACTED_FILES=(".agent/project_state.json")
    [[ "${#APPROVED_PHASES[@]}" -gt 0 ]] || APPROVED_PHASES=("approve")
    [[ "${#VALIDATION_COMMANDS[@]}" -gt 0 ]] || VALIDATION_COMMANDS=("bash evals/checks/check-plan-event-automation-smoke.sh")
    [[ "${#CONSTRAINTS[@]}" -gt 0 ]] || CONSTRAINTS=("No guardar el cuerpo completo del plan")
    EVENT_JSON="$(jq -cn \
      --arg event_id "$(event_id)" \
      --arg source_host "$SOURCE_HOST" \
      --arg producer_agent "$PRODUCER_AGENT" \
      --arg approval_source "$APPROVAL_SOURCE" \
      --arg project_root "$PROJECT_ROOT" \
      --arg timestamp "$TIMESTAMP" \
      --arg content_hash "$CONTENT_HASH" \
      --arg origin_workflow "$ORIGIN_WORKFLOW" \
      --arg tenant_domain "$TENANT_DOMAIN" \
      --arg summary "$SUMMARY" \
      --arg objective "$OBJECTIVE" \
      --arg rollback "$ROLLBACK" \
      --argjson affected_surfaces "$(json_array "${AFFECTED_SURFACES[@]}")" \
      --argjson impacted_files "$(json_array "${IMPACTED_FILES[@]}")" \
      --argjson approved_phases "$(json_array "${APPROVED_PHASES[@]}")" \
      --argjson validation_commands "$(json_array "${VALIDATION_COMMANDS[@]}")" \
      --argjson constraints "$(json_array "${CONSTRAINTS[@]}")" \
      '{
        schema_version:3,
        event_id:$event_id,
        event_name:"plan_approved",
        source_host:$source_host,
        producer_agent:$producer_agent,
        approval_source:$approval_source,
        project_root:$project_root,
        timestamp:$timestamp,
        origin_workflow:$origin_workflow,
        content_hash:$content_hash,
        next_action:"implementation_unblocked",
        durable_capture:{
          tenant_domain:$tenant_domain,
          summary:$summary,
          alternatives:["No registrar el evento", "Persistir el plan completo en el repo"],
          validation:$validation_commands,
          risks:["Drift entre host y cache si el evento no se ingiere"],
          receipt:{
            objective:$objective,
            affected_surfaces:$affected_surfaces,
            impacted_files:$impacted_files,
            approved_phases:$approved_phases,
            validation_commands:$validation_commands,
            rollback:$rollback,
            constraints:$constraints
          }
        }
      }')"
    ;;
  approve-current)
    require_value "--summary" "$SUMMARY"
    require_value "--approval-source" "$APPROVAL_SOURCE"
    CURRENT_STATE_JSON="$(bash "$STATECTL" get --root "$ROOT")"
    CONTENT_HASH="$(jq -r '.plan_state.content_hash // empty' <<< "$CURRENT_STATE_JSON")"
    [[ -n "$CONTENT_HASH" ]] || {
      echo "approve-current requires current_state.plan_state.content_hash from a presented plan." >&2
      exit 1
    }
    OBJECTIVE="${OBJECTIVE:-$SUMMARY}"
    if [[ "${#AFFECTED_SURFACES[@]}" -eq 0 ]]; then
      AFFECTED_SURFACES=("sensitive_change")
    fi
    if [[ "${#IMPACTED_FILES[@]}" -eq 0 ]]; then
      while IFS= read -r item; do
        [[ -n "$item" ]] && IMPACTED_FILES+=("$item")
      done < <(jq -r '.active_files[]?' <<< "$CURRENT_STATE_JSON")
      [[ "${#IMPACTED_FILES[@]}" -gt 0 ]] || IMPACTED_FILES=(".agent/current_state.json")
    fi
    if [[ "${#APPROVED_PHASES[@]}" -eq 0 ]]; then
      APPROVED_PHASES=("implement" "verify" "update-memory")
    fi
    if [[ "${#VALIDATION_COMMANDS[@]}" -eq 0 ]]; then
      while IFS= read -r item; do
        [[ -n "$item" ]] && VALIDATION_COMMANDS+=("$item")
      done < <(jq -r '.resume_commands[]?' <<< "$CURRENT_STATE_JSON")
      [[ "${#VALIDATION_COMMANDS[@]}" -gt 0 ]] || VALIDATION_COMMANDS=("bash scripts/gemini-doctor.sh")
    fi
    [[ "${#CONSTRAINTS[@]}" -gt 0 ]] || CONSTRAINTS=("No guardar el cuerpo completo del plan")
    EVENT_JSON="$(jq -cn \
      --arg event_id "$(event_id)" \
      --arg source_host "$SOURCE_HOST" \
      --arg producer_agent "$PRODUCER_AGENT" \
      --arg approval_source "$APPROVAL_SOURCE" \
      --arg project_root "$PROJECT_ROOT" \
      --arg timestamp "$TIMESTAMP" \
      --arg content_hash "$CONTENT_HASH" \
      --arg origin_workflow "$ORIGIN_WORKFLOW" \
      --arg tenant_domain "$TENANT_DOMAIN" \
      --arg summary "$SUMMARY" \
      --arg objective "$OBJECTIVE" \
      --arg rollback "$ROLLBACK" \
      --argjson affected_surfaces "$(json_array "${AFFECTED_SURFACES[@]}")" \
      --argjson impacted_files "$(json_array "${IMPACTED_FILES[@]}")" \
      --argjson approved_phases "$(json_array "${APPROVED_PHASES[@]}")" \
      --argjson validation_commands "$(json_array "${VALIDATION_COMMANDS[@]}")" \
      --argjson constraints "$(json_array "${CONSTRAINTS[@]}")" \
      '{
        schema_version:3,
        event_id:$event_id,
        event_name:"plan_approved",
        source_host:$source_host,
        producer_agent:$producer_agent,
        approval_source:$approval_source,
        project_root:$project_root,
        timestamp:$timestamp,
        origin_workflow:$origin_workflow,
        content_hash:$content_hash,
        next_action:"implementation_unblocked",
        durable_capture:{
          tenant_domain:$tenant_domain,
          summary:$summary,
          alternatives:["No registrar el evento", "Guardar el cuerpo completo del plan en el repo"],
          validation:$validation_commands,
          risks:["Drift si el evento no se ingiere correctamente"],
          receipt:{
            objective:$objective,
            affected_surfaces:$affected_surfaces,
            impacted_files:$impacted_files,
            approved_phases:$approved_phases,
            validation_commands:$validation_commands,
            rollback:$rollback,
            constraints:$constraints
          }
        }
      }')"
    ;;
  supersede)
    require_value "--content-hash" "$CONTENT_HASH"
    require_value "--summary" "$SUMMARY"
    EVENT_JSON="$(jq -cn \
      --arg event_id "$(event_id)" \
      --arg source_host "$SOURCE_HOST" \
      --arg producer_agent "$PRODUCER_AGENT" \
      --arg project_root "$PROJECT_ROOT" \
      --arg timestamp "$TIMESTAMP" \
      --arg content_hash "$CONTENT_HASH" \
      --arg summary "$SUMMARY" \
      --arg origin_workflow "$ORIGIN_WORKFLOW" \
      '{schema_version:3,event_id:$event_id,event_name:"plan_superseded",source_host:$source_host,producer_agent:$producer_agent,approval_source:null,project_root:$project_root,timestamp:$timestamp,origin_workflow:$origin_workflow,content_hash:$content_hash,next_action:"draft_replacement_plan",durable_capture:{summary:$summary}}')"
    ;;
  reset)
    EVENT_JSON="$(jq -cn \
      --arg event_id "$(event_id)" \
      --arg source_host "$SOURCE_HOST" \
      --arg producer_agent "$PRODUCER_AGENT" \
      --arg project_root "$PROJECT_ROOT" \
      --arg timestamp "$TIMESTAMP" \
      --arg origin_workflow "$ORIGIN_WORKFLOW" \
      '{schema_version:3,event_id:$event_id,event_name:"plan_reset",source_host:$source_host,producer_agent:$producer_agent,approval_source:null,project_root:$project_root,timestamp:$timestamp,origin_workflow:$origin_workflow}')"
    ;;
  *)
    echo "Unknown subcommand: $SUBCOMMAND" >&2
    usage
    exit 1
    ;;
esac

bash "$INGESTOR" --root "$ROOT" --event-json "$EVENT_JSON"
