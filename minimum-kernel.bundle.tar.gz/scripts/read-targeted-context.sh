#!/usr/bin/env bash
set -euo pipefail

FILE=""
NEEDLE=""
CONTEXT_LINES="3"
MAX_SCAN_BYTES=""

usage() {
  cat <<'EOF'
Usage:
  read-targeted-context.sh --file PATH --needle TEXT [--context-lines N] [--max-scan-bytes N]

Returns JSON:
  {
    "file": "...",
    "needle": "...",
    "matched": true|false,
    "line_offset": <1-based line number or null>,
    "truncated": true|false,
    "content": "..."
  }
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --file) FILE="$2"; shift 2 ;;
    --needle) NEEDLE="$2"; shift 2 ;;
    --context-lines) CONTEXT_LINES="$2"; shift 2 ;;
    --max-scan-bytes) MAX_SCAN_BYTES="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unexpected argument: $1" >&2; usage; exit 1 ;;
  esac
done

[[ -n "$FILE" && -n "$NEEDLE" ]] || {
  usage
  exit 1
}

[[ -f "$FILE" ]] || {
  echo "Missing file: $FILE" >&2
  exit 1
}

python3 - "$FILE" "$NEEDLE" "$CONTEXT_LINES" "${MAX_SCAN_BYTES:-}" <<'PY'
import json
import os
import sys

path, needle, context_raw, max_scan_raw = sys.argv[1:5]

try:
    context_lines = int(context_raw)
except ValueError:
    raise SystemExit("--context-lines must be an integer")

if context_lines < 0:
    raise SystemExit("--context-lines must be >= 0")

max_scan_bytes = None
if max_scan_raw:
    try:
        max_scan_bytes = int(max_scan_raw)
    except ValueError:
        raise SystemExit("--max-scan-bytes must be an integer")
    if max_scan_bytes <= 0:
        raise SystemExit("--max-scan-bytes must be > 0")

file_size = os.path.getsize(path)
read_limit = max_scan_bytes if max_scan_bytes is not None else file_size

with open(path, "rb") as fh:
    raw = fh.read(read_limit)

truncated = file_size > len(raw)
text = raw.decode("utf-8", errors="replace")
lines = text.splitlines()

match_index = None
for idx, line in enumerate(lines):
    if needle in line:
        match_index = idx
        break

if match_index is None:
    payload = {
        "file": path,
        "needle": needle,
        "matched": False,
        "line_offset": None,
        "truncated": truncated,
        "content": "",
    }
else:
    start = max(0, match_index - context_lines)
    end = min(len(lines), match_index + context_lines + 1)
    payload = {
        "file": path,
        "needle": needle,
        "matched": True,
        "line_offset": start + 1,
        "truncated": truncated,
        "content": "\n".join(lines[start:end]),
    }

print(json.dumps(payload, ensure_ascii=True))
PY
