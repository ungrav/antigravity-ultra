#!/usr/bin/env bash
set -euo pipefail

ROOT="$HOME/.gemini"
COMMAND="${1:-}"
SUMMARY=""
PROBLEM=""
ROOT_CAUSE=""
FIX=""
STATUS="Resuelto"

shift || true

usage() {
  cat <<'EOF'
Usage:
  logctl.sh history --summary TEXT [--root PATH]
  logctl.sh incident --problem TEXT --root-cause TEXT --fix TEXT [--status TEXT] [--root PATH]

Description:
  Writes durable human ledgers only when features.project_ledgers=true.
  If disabled, prints SKIPPED_FEATURE_DISABLED and exits 0 without creating files.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --root)
      ROOT="$2"
      shift 2
      ;;
    --summary)
      SUMMARY="$2"
      shift 2
      ;;
    --problem)
      PROBLEM="$2"
      shift 2
      ;;
    --root-cause)
      ROOT_CAUSE="$2"
      shift 2
      ;;
    --fix)
      FIX="$2"
      shift 2
      ;;
    --status)
      STATUS="$2"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unexpected argument: $1" >&2
      usage
      exit 1
      ;;
  esac
done

[[ -n "$COMMAND" ]] || {
  usage
  exit 1
}

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -f "$ROOT/scripts/kernel-feature-enabled.sh" ]]; then
  FEATURE_HELPER="$ROOT/scripts/kernel-feature-enabled.sh"
else
  FEATURE_HELPER="$SCRIPT_DIR/kernel-feature-enabled.sh"
fi

ROOT="$(cd "$ROOT" && pwd -P)"
if [[ -f "$FEATURE_HELPER" ]] && ! bash "$FEATURE_HELPER" project_ledgers --root "$ROOT" >/dev/null 2>&1; then
  echo "SKIPPED_FEATURE_DISABLED project_ledgers=false"
  exit 0
fi

now_day() {
  date -u +"%Y-%m-%d"
}

now_stamp() {
  date -u +"%Y-%m-%d %H:%M"
}

ensure_history() {
  local file="$ROOT/PROJECT_HISTORY.md"
  if [[ ! -f "$file" ]]; then
    cat > "$file" <<'EOF'
# PROJECT HISTORY

> Estado vivo maquina: `.agent/current_state.json`
> Vista viva legible por agentes: `.agent/current_state.md`
> Cache/script output legible por maquina: `.agent/project_state.json`

EOF
  fi
}

ensure_error_log() {
  local file="$ROOT/ERROR_LOG.md"
  if [[ ! -f "$file" ]]; then
    cat > "$file" <<'EOF'
# ERROR_LOG.md

Registro centralizado de errores operativos y de infraestructura del sistema.

| Timestamp | ID | Severidad | Problema | Causa Raíz | Solución(Fix) | Estado |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
EOF
  fi
}

append_history() {
  [[ -n "$SUMMARY" ]] || {
    echo "history requires --summary" >&2
    exit 1
  }
  ensure_history
  local file="$ROOT/PROJECT_HISTORY.md"
  local day tmp
  day="$(now_day)"
  tmp="$(mktemp "${TMPDIR:-/tmp}/logctl-history.XXXXXX")"
  python3 - "$file" "$tmp" "$day" "$SUMMARY" <<'PY'
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
tmp = pathlib.Path(sys.argv[2])
day = sys.argv[3]
summary = sys.argv[4]
lines = path.read_text(encoding="utf-8").splitlines()
heading = f"## [{day}] - logctl"
entry = f"- {summary}"

if heading in lines:
    idx = lines.index(heading)
    insert_at = idx + 1
    while insert_at < len(lines) and lines[insert_at].strip() == "":
        insert_at += 1
    lines.insert(insert_at, entry)
else:
    insert_at = next((i for i, line in enumerate(lines) if line.startswith("## [")), len(lines))
    block = [heading, "", entry, ""]
    lines[insert_at:insert_at] = block

tmp.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
PY
  mv "$tmp" "$file"
  echo "LOGCTL_HISTORY_WRITTEN"
}

append_incident() {
  [[ -n "$PROBLEM" ]] || {
    echo "incident requires --problem" >&2
    exit 1
  }
  [[ -n "$ROOT_CAUSE" ]] || {
    echo "incident requires --root-cause" >&2
    exit 1
  }
  [[ -n "$FIX" ]] || {
    echo "incident requires --fix" >&2
    exit 1
  }
  ensure_error_log
  local file="$ROOT/ERROR_LOG.md"
  local stamp id
  stamp="$(now_stamp)"
  id="E$(date -u +%Y%m%d%H%M%S)"
  printf '| %s | %s | MEDIUM | %s | %s | %s | %s |\n' \
    "$stamp" "$id" "$PROBLEM" "$ROOT_CAUSE" "$FIX" "$STATUS" >> "$file"
  echo "LOGCTL_INCIDENT_WRITTEN"
}

case "$COMMAND" in
  history)
    append_history
    ;;
  incident)
    append_incident
    ;;
  -h|--help|help)
    usage
    ;;
  *)
    echo "Unknown command: $COMMAND" >&2
    usage
    exit 1
    ;;
esac
