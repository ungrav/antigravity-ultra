#!/usr/bin/env bash
set -euo pipefail

ROOT="$HOME/.gemini"
REASON="manual-safe-trash"
JSON_OUTPUT=0
declare -a TARGETS=()

usage() {
  cat <<'EOF'
Usage:
  safe-trash.sh --path PATH [--path PATH...] [--reason TEXT] [--root PATH] [--json]

Description:
  Moves project-local files/directories into _DEPRECATED_TRASH with a manifest.
  This is the executable SAFE DELETE contract; it never deletes directly.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --root)
      ROOT="$2"
      shift 2
      ;;
    --reason)
      REASON="$2"
      shift 2
      ;;
    --path)
      TARGETS+=("$2")
      shift 2
      ;;
    --json)
      JSON_OUTPUT=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      printf 'Unexpected argument: %s\n' "$1" >&2
      usage >&2
      exit 1
      ;;
  esac
done

ROOT="$(cd "$ROOT" && pwd -P)"
[[ "${#TARGETS[@]}" -gt 0 ]] || {
  printf 'At least one --path is required.\n' >&2
  exit 1
}

for cmd in date jq mkdir mv python3; do
  command -v "$cmd" >/dev/null 2>&1 || {
    printf 'Missing required command: %s\n' "$cmd" >&2
    exit 1
  }
done

TIMESTAMP="$(date -u '+%Y%m%dT%H%M%SZ')"
TRASH_ROOT="$ROOT/_DEPRECATED_TRASH/safe-delete/$TIMESTAMP"
mkdir -p "$TRASH_ROOT"

manifest_json="$(python3 - "$ROOT" "$TRASH_ROOT" "$REASON" "${TARGETS[@]}" <<'PY'
import json
import os
import pathlib
import shutil
import sys

root = pathlib.Path(sys.argv[1]).resolve()
trash_root = pathlib.Path(sys.argv[2]).resolve()
reason = sys.argv[3]
targets = sys.argv[4:]
entries = []

def within_root(path):
    try:
        path.resolve().relative_to(root)
        return True
    except ValueError:
        return False

for raw in targets:
    source = (root / raw).resolve() if not pathlib.Path(raw).is_absolute() else pathlib.Path(raw).resolve()
    if not within_root(source):
        raise SystemExit(f"Refusing to safe-trash outside project root: {source}")
    if not source.exists():
        raise SystemExit(f"Target does not exist: {source}")
    rel = source.relative_to(root)
    destination = trash_root / rel
    destination.parent.mkdir(parents=True, exist_ok=True)
    candidate = destination
    suffix = 1
    while candidate.exists():
        candidate = destination.with_name(f"{destination.name}--{suffix}")
        suffix += 1
    shutil.move(str(source), str(candidate))
    entries.append({
        "source": str(rel),
        "destination": str(candidate.relative_to(root)),
        "reason": reason,
        "restore_command": f"mkdir -p {str((root / rel).parent)!r} && mv {str(candidate)!r} {str(root / rel)!r}"
    })

manifest = {
    "schema_version": 1,
    "reason": reason,
    "trash_root": str(trash_root.relative_to(root)),
    "entries": entries
}
(trash_root / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print(json.dumps(manifest, indent=2))
PY
)"

if (( JSON_OUTPUT == 1 )); then
  printf '%s\n' "$manifest_json"
else
  printf 'SUMMARY: moved %s item(s) to %s\n' "${#TARGETS[@]}" "$TRASH_ROOT"
fi
