#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage: normalize-foreign-project-context.sh --project-root <path> [--check | --write]

Options:
  --project-root <path>  Project root to inspect.
  --check                Validate the current foreign-context normalization state without writing.
  --write                Normalize foreign context and persist .agent/project_state.json / GEMINI.md when needed.
EOF
}

emit_info() {
  printf 'INFO: %s\n' "$1"
}

emit_error() {
  printf 'ERROR: %s\n' "$1" >&2
}

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || {
    emit_error "Missing required command: $1"
    exit 1
  }
}

exact_file_exists() {
  local path="$1"
  local dir
  local base
  dir="$(dirname "$path")"
  base="$(basename "$path")"
  [[ -d "$dir" ]] || return 1
  while IFS= read -r entry; do
    [[ "$(basename "$entry")" == "$base" ]] && return 0
  done < <(find "$dir" -maxdepth 1 -mindepth 1 -type f 2>/dev/null)
  return 1
}

trim_copy() {
  local source="$1"
  local target="$2"
  awk '
    {
      lines[++count] = $0
      if ($0 !~ /^[[:space:]]*$/) {
        last_non_blank = count
      }
    }
    END {
      first_non_blank = 0
      for (i = 1; i <= count; i++) {
        if (lines[i] !~ /^[[:space:]]*$/) {
          first_non_blank = i
          break
        }
      }
      if (first_non_blank == 0) {
        exit
      }
      for (i = first_non_blank; i <= last_non_blank; i++) {
        print lines[i]
      }
    }
  ' "$source" > "$target"
}

extract_markdown_section() {
  local file="$1"
  local heading="$2"
  local target="$3"
  local raw="$TMP_DIR/raw.$$.md"
  awk -v heading="$heading" '
    $0 == heading { capture = 1; next }
    capture && /^## / { exit }
    capture { print }
  ' "$file" > "$raw"
  trim_copy "$raw" "$target"
}

filter_bullets() {
  local file="$1"
  local pattern="$2"
  local target="$3"
  awk -v pattern="$pattern" '
    BEGIN { IGNORECASE = 1 }
    /^[@\/]/ { next }
    /^>/ { next }
    /^#/ { next }
    /^(You are|You should|Please|Persona:|Role:)/ { next }
    {
      line = $0
      sub(/^[[:space:]]*[-*][[:space:]]*/, "", line)
      if ($0 ~ /^[[:space:]]*[-*][[:space:]]+/ && line ~ pattern) {
        print "- " line
      }
    }
  ' "$file" > "$target"
}

append_unique_lines() {
  local source="$1"
  local target="$2"
  [[ -s "$source" ]] || return 0
  while IFS= read -r line; do
    [[ -z "$line" ]] && continue
    if ! rg -Fqx -- "$line" "$target" 2>/dev/null; then
      printf '%s\n' "$line" >> "$target"
    fi
  done < "$source"
}

ensure_section_content() {
  local target="$1"
  local default_line="$2"
  if [[ ! -s "$target" ]]; then
    printf -- '- %s\n' "$default_line" > "$target"
  fi
}

MODE="check"
PROJECT_ROOT=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --project-root)
      PROJECT_ROOT="${2:-}"
      shift 2
      ;;
    --check)
      MODE="check"
      shift
      ;;
    --write)
      MODE="write"
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      emit_error "Unknown argument: $1"
      usage
      exit 1
      ;;
  esac
done

[[ -n "$PROJECT_ROOT" ]] || {
  emit_error "--project-root is required"
  usage
  exit 1
}

require_cmd jq
require_cmd rg
require_cmd awk
require_cmd sed
require_cmd perl

PROJECT_ROOT="$(cd "$PROJECT_ROOT" && pwd)"
STATE_PATH="$PROJECT_ROOT/.agent/project_state.json"
GEMINI_PATH="$PROJECT_ROOT/GEMINI.md"
LEGACY_GEMINI_PATH="$PROJECT_ROOT/gemini.md"
AGENTS_PATH="$PROJECT_ROOT/AGENTS.md"
CLAUDE_PATH="$PROJECT_ROOT/CLAUDE.md"

[[ -f "$STATE_PATH" ]] || {
  emit_error "Missing required state file: $STATE_PATH"
  exit 1
}

TMP_DIR="$(mktemp -d "${TMPDIR:-/tmp}/normalize-foreign-context.XXXXXX")"
trap 'rm -rf "$TMP_DIR"' EXIT

QUICKSTART_FILE="$TMP_DIR/quickstart.md"
RULES_FILE="$TMP_DIR/rules.md"
ARCH_FILE="$TMP_DIR/architecture.md"
DOCS_FILE="$TMP_DIR/docs.md"
: > "$QUICKSTART_FILE"
: > "$RULES_FILE"
: > "$ARCH_FILE"
: > "$DOCS_FILE"

SOURCE_TYPE=""
SOURCE_PATH=""
IMPORT_MODE=""
NEEDS_SEED="false"

HAS_GEMINI="false"
HAS_LEGACY_GEMINI="false"
HAS_AGENTS="false"
HAS_CLAUDE="false"

exact_file_exists "$GEMINI_PATH" && HAS_GEMINI="true"
exact_file_exists "$LEGACY_GEMINI_PATH" && HAS_LEGACY_GEMINI="true"
exact_file_exists "$AGENTS_PATH" && HAS_AGENTS="true"
exact_file_exists "$CLAUDE_PATH" && HAS_CLAUDE="true"

if [[ "$HAS_GEMINI" == "true" ]]; then
  SOURCE_TYPE="native_gemini"
  SOURCE_PATH="GEMINI.md"
  IMPORT_MODE="preserve"
elif [[ "$HAS_LEGACY_GEMINI" == "true" ]]; then
  SOURCE_TYPE="legacy_gemini"
  SOURCE_PATH="gemini.md"
  IMPORT_MODE="preserve"
elif [[ "$HAS_AGENTS" == "true" && "$HAS_CLAUDE" == "true" ]]; then
  SOURCE_TYPE="foreign_combo"
  SOURCE_PATH="AGENTS.md"
  IMPORT_MODE="migrate_agents"
  NEEDS_SEED="true"
elif [[ "$HAS_AGENTS" == "true" ]]; then
  SOURCE_TYPE="foreign_agents"
  SOURCE_PATH="AGENTS.md"
  IMPORT_MODE="migrate_agents"
  NEEDS_SEED="true"
elif [[ "$HAS_CLAUDE" == "true" ]]; then
  SOURCE_TYPE="foreign_claude"
  SOURCE_PATH="CLAUDE.md"
  IMPORT_MODE="seed_from_claude"
  NEEDS_SEED="true"
fi

if [[ -z "$SOURCE_TYPE" ]]; then
  emit_info "No native or foreign context files detected. Nothing to normalize."
  exit 0
fi

if [[ "$SOURCE_TYPE" == "foreign_agents" || "$SOURCE_TYPE" == "foreign_combo" ]]; then
  extract_markdown_section "$AGENTS_PATH" "## How To Start" "$QUICKSTART_FILE"
  extract_markdown_section "$AGENTS_PATH" "## Essential Working Rules" "$RULES_FILE"
  extract_markdown_section "$AGENTS_PATH" "## Architecture & Boundaries" "$ARCH_FILE"

  AGENT_FALLBACK_QUICKSTART="$TMP_DIR/agents-fallback-quickstart.md"
  AGENT_FALLBACK_RULES="$TMP_DIR/agents-fallback-rules.md"
  AGENT_FALLBACK_ARCH="$TMP_DIR/agents-fallback-arch.md"
  filter_bullets "$AGENTS_PATH" '(npm|pnpm|yarn|bun|uv|pytest|cargo|make|run|test|lint|build|dev)' "$AGENT_FALLBACK_QUICKSTART"
  filter_bullets "$AGENTS_PATH" '(safe delete|never|always|must|do not|update .*PROJECT_HISTORY|ERROR_LOG|verification)' "$AGENT_FALLBACK_RULES"
  filter_bullets "$AGENTS_PATH" '(architecture|boundary|boundaries|module|service|layer|invariant|topology|manifest)' "$AGENT_FALLBACK_ARCH"
  append_unique_lines "$AGENT_FALLBACK_QUICKSTART" "$QUICKSTART_FILE"
  append_unique_lines "$AGENT_FALLBACK_RULES" "$RULES_FILE"
  append_unique_lines "$AGENT_FALLBACK_ARCH" "$ARCH_FILE"
fi

if [[ "$SOURCE_TYPE" == "foreign_claude" || "$SOURCE_TYPE" == "foreign_combo" ]]; then
  CLAUDE_QUICKSTART="$TMP_DIR/claude-quickstart.md"
  CLAUDE_RULES="$TMP_DIR/claude-rules.md"
  CLAUDE_ARCH="$TMP_DIR/claude-arch.md"
  : > "$CLAUDE_QUICKSTART"
  : > "$CLAUDE_RULES"
  : > "$CLAUDE_ARCH"

  for heading in "## Quickstart" "## Commands" "## Development"; do
    extract_markdown_section "$CLAUDE_PATH" "$heading" "$TMP_DIR/section.md"
    append_unique_lines "$TMP_DIR/section.md" "$CLAUDE_QUICKSTART"
  done
  for heading in "## Rules" "## Working Rules" "## Constraints"; do
    extract_markdown_section "$CLAUDE_PATH" "$heading" "$TMP_DIR/section.md"
    append_unique_lines "$TMP_DIR/section.md" "$CLAUDE_RULES"
  done
  for heading in "## Architecture" "## Architecture Notes" "## Boundaries"; do
    extract_markdown_section "$CLAUDE_PATH" "$heading" "$TMP_DIR/section.md"
    append_unique_lines "$TMP_DIR/section.md" "$CLAUDE_ARCH"
  done

  CLAUDE_FALLBACK_QUICKSTART="$TMP_DIR/claude-fallback-quickstart.md"
  CLAUDE_FALLBACK_RULES="$TMP_DIR/claude-fallback-rules.md"
  CLAUDE_FALLBACK_ARCH="$TMP_DIR/claude-fallback-arch.md"
  filter_bullets "$CLAUDE_PATH" '(npm|pnpm|yarn|bun|uv|pytest|cargo|make|run|test|lint|build|dev)' "$CLAUDE_FALLBACK_QUICKSTART"
  filter_bullets "$CLAUDE_PATH" '(safe delete|never|always|must|do not|update .*PROJECT_HISTORY|ERROR_LOG|verification)' "$CLAUDE_FALLBACK_RULES"
  filter_bullets "$CLAUDE_PATH" '(architecture|boundary|boundaries|module|service|layer|invariant|topology|manifest)' "$CLAUDE_FALLBACK_ARCH"

  append_unique_lines "$CLAUDE_QUICKSTART" "$QUICKSTART_FILE"
  append_unique_lines "$CLAUDE_RULES" "$RULES_FILE"
  append_unique_lines "$CLAUDE_ARCH" "$ARCH_FILE"
  append_unique_lines "$CLAUDE_FALLBACK_QUICKSTART" "$QUICKSTART_FILE"
  append_unique_lines "$CLAUDE_FALLBACK_RULES" "$RULES_FILE"
  append_unique_lines "$CLAUDE_FALLBACK_ARCH" "$ARCH_FILE"
fi

if [[ "$HAS_AGENTS" == "true" ]]; then
  rg -o '`[^`]+`|[A-Za-z0-9_./-]+\.md' "$AGENTS_PATH" | sed 's/^`//; s/`$//' | sort -u > "$TMP_DIR/agents-docs.txt" || true
  append_unique_lines "$TMP_DIR/agents-docs.txt" "$DOCS_FILE"
fi
if [[ "$HAS_CLAUDE" == "true" ]]; then
  rg -o '`[^`]+`|[A-Za-z0-9_./-]+\.md' "$CLAUDE_PATH" | sed 's/^`//; s/`$//' | sort -u > "$TMP_DIR/claude-docs.txt" || true
  append_unique_lines "$TMP_DIR/claude-docs.txt" "$DOCS_FILE"
fi

ensure_section_content "$QUICKSTART_FILE" "Review the repository entrypoints before running commands."
ensure_section_content "$RULES_FILE" "Use safe, minimal, and reversible edits until project-specific rules are confirmed."
ensure_section_content "$ARCH_FILE" "Review repository structure and manifests before making structural changes."

if [[ "$MODE" == "check" ]]; then
  if ! jq -e --arg source_type "$SOURCE_TYPE" --arg source_path "$SOURCE_PATH" --arg mode "$IMPORT_MODE" '
      if $source_type == "" then
        true
      else
        (.context_import.source_type // "") == $source_type and
        (.context_import.source_path // "") == $source_path and
        (.context_import.mode // "") == $mode
      end
    ' "$STATE_PATH" >/dev/null 2>&1; then
    emit_error "context_import metadata is stale or missing for detected context source."
    exit 1
  fi

  if [[ "$NEEDS_SEED" == "true" && "$HAS_GEMINI" != "true" ]]; then
    emit_error "Foreign context was detected but GEMINI.md has not been seeded yet."
    exit 1
  fi

  emit_info "Foreign context normalization is consistent."
  exit 0
fi

STATE_TMP="$TMP_DIR/project_state.updated.json"
jq \
  --arg source_type "$SOURCE_TYPE" \
  --arg source_path "$SOURCE_PATH" \
  --arg mode "$IMPORT_MODE" \
  --arg last_normalized_at "$(date -u +"%Y-%m-%dT%H:%M:%SZ")" \
  '
    .context_import = {
      source_type: $source_type,
      source_path: $source_path,
      mode: $mode,
      last_normalized_at: $last_normalized_at
    }
  ' "$STATE_PATH" > "$STATE_TMP"
cp "$STATE_TMP" "$STATE_PATH"

if [[ "$NEEDS_SEED" == "true" && "$HAS_GEMINI" != "true" ]]; then
  IMPORT_NOTE="- Seeded from imported project context: ${SOURCE_PATH}."
  CLAUDE_NOTE=""
  if [[ "$HAS_CLAUDE" == "true" ]]; then
    CLAUDE_NOTE="- Preserve \`CLAUDE.md\` untouched and consult it only for host-specific detail when needed."
  fi

  {
    printf '# Proyecto Gemini: Reglas Locales y Contexto\n\n'
    printf '> **HUMAN ZONE**: Escribe aquí tus preferencias manuales, librerías favoritas, reglas de estilo, etc. El orquestador nunca borrará esta sección.\n\n'
    printf '%s\n' "$IMPORT_NOTE"
    if [[ -n "$CLAUDE_NOTE" ]]; then
      printf '%s\n' "$CLAUDE_NOTE"
    fi
    printf '\n<!-- GEMINI_STATE_START -->\n'
    printf '## Shared Quickstart\n'
    cat "$QUICKSTART_FILE"
    printf '\n## Shared Agent Rules\n'
    cat "$RULES_FILE"
    printf '\n## Shared Architecture Notes\n'
    cat "$ARCH_FILE"
    printf '\n**Stack:** Imported context bootstrap\n'
    printf '**State:** Imported\n\n'
    printf '**Local Services:**\n'
    printf -- '- Confirm local services and ports after the first runtime scan.\n\n'
    printf '**Repo Constraints:**\n'
    printf -- '- Imported foreign context is a seed only; future runtime canon lives in `GEMINI.md`.\n'
    printf -- '- `AGENTS.md` remains onboarding/export only and `CLAUDE.md` remains host-specific.\n\n'
    printf '**Docs Pointers:**\n'
    if [[ -s "$DOCS_FILE" ]]; then
      while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        printf -- '- %s\n' "$line"
      done < "$DOCS_FILE"
    else
      printf -- '- Review repository docs and manifests during the first context refresh.\n'
    fi
    printf '<!-- GEMINI_STATE_END -->\n'
  } > "$GEMINI_PATH"

  emit_info "Seeded GEMINI.md from imported foreign context."
else
  emit_info "Recorded context_import metadata without seeding GEMINI.md."
fi
