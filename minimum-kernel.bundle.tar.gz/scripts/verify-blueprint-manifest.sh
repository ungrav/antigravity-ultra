#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-$HOME/.gemini}"
BLUEPRINTS="$ROOT/GEMINI_BLUEPRINTS.md"
MANIFEST="$ROOT/blueprints/manifest.json"

ERRORS=0

emit_error() {
  printf 'ERROR: %s\n' "$1"
  ERRORS=$((ERRORS + 1))
}

emit_info() {
  printf 'INFO: %s\n' "$1"
}

TMP_EXTRACT="$(mktemp "${TMPDIR:-/tmp}/gemini-blueprint-verify.XXXXXX")"
trap 'rm -f "$TMP_EXTRACT"' EXIT

if jq -e '[.artifacts | keys[] | startswith("system:")] | any' "$MANIFEST" >/dev/null 2>&1; then
  emit_error "Blueprint manifest still exposes unsupported system:* artifacts"
fi

if ! jq -e '[.artifacts | to_entries[] | (.value.kind == "workflow" or .value.kind == "template" or .value.kind == "skill")] | all' "$MANIFEST" >/dev/null 2>&1; then
  emit_error "Blueprint manifest contains artifact kinds outside workflow/template/skill"
fi

extract_marker() {
  local marker_name="$1"
  awk -v begin="<!-- BEGIN: ${marker_name} -->" -v end="<!-- END: ${marker_name} -->" '
    $0 == begin { capture = 1; next }
    $0 == end { capture = 0; exit }
    capture { print }
  ' "$BLUEPRINTS" > "$TMP_EXTRACT"
}

while IFS= read -r artifact_id; do
  [[ -z "$artifact_id" ]] && continue

  entry="$(jq -er --arg id "$artifact_id" '.artifacts[$id]' "$MANIFEST")"
  marker_name="$(printf '%s' "$entry" | jq -r '.marker_name')"
  expected_sha="$(printf '%s' "$entry" | jq -r '.sha256')"
  kind="$(printf '%s' "$entry" | jq -r '.kind')"
  canonical_path="$(printf '%s' "$entry" | jq -r '.canonical_path')"

  extract_marker "$marker_name"
  if [[ ! -s "$TMP_EXTRACT" ]]; then
    if [[ "$canonical_path" != "GEMINI_BLUEPRINTS.md" && -f "$ROOT/$canonical_path" ]]; then
      canonical_sha="$(shasum -a 256 "$ROOT/$canonical_path" | awk '{print $1}')"
      if [[ "$canonical_sha" == "$expected_sha" ]]; then
        continue
      fi
    fi
    emit_error "Missing or empty blueprint block for ${artifact_id}"
    continue
  fi

  extracted_sha="$(shasum -a 256 "$TMP_EXTRACT" | awk '{print $1}')"
  if [[ "$extracted_sha" != "$expected_sha" ]]; then
    emit_error "Hash mismatch in BLUEPRINTS for ${artifact_id}"
    continue
  fi

  if [[ "$canonical_path" != "GEMINI_BLUEPRINTS.md" ]]; then
    canonical_file="$ROOT/$canonical_path"
    if [[ ! -f "$canonical_file" ]]; then
      emit_error "Canonical artifact missing on disk for ${artifact_id}: $canonical_file"
      continue
    fi

    canonical_sha="$(shasum -a 256 "$canonical_file" | awk '{print $1}')"
    if [[ "$canonical_sha" != "$expected_sha" ]]; then
      emit_error "Canonical artifact hash mismatch for ${artifact_id}"
      continue
    fi
  fi
done < <(jq -r '.artifacts | keys[]' "$MANIFEST")

if (( ERRORS > 0 )); then
  printf 'SUMMARY: %s error(s)\n' "$ERRORS"
  exit 1
fi

emit_info "Blueprint manifest hashes verified."
printf 'SUMMARY: 0 error(s)\n'
