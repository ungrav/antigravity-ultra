#!/usr/bin/env python3
"""Run a bounded, serialized local-engine benchmark without storing responses."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import time
from typing import Any
from urllib import error, parse, request


CASES = [
    {
        "task_class": "instruction_following",
        "prompt": "Reply with exactly ORBIT-17 and no other text.",
        "score": lambda text: text.strip() == "ORBIT-17",
    },
    {
        "task_class": "extraction",
        "prompt": "Return JSON only with vendor, total, and date. Invoice: vendor Acme, total 42.50, date 2026-07-13.",
        "score": lambda text: parse_json(text) == {"vendor": "Acme", "total": 42.5, "date": "2026-07-13"},
    },
    {
        "task_class": "coding",
        "prompt": "Return only one JavaScript statement implementing clamp(value, min, max) inside the function body.",
        "score": lambda text: all(token in text for token in ("return", "Math.max", "Math.min")),
    },
    {
        "task_class": "review",
        "prompt": "Review: db.query(`SELECT * FROM users WHERE id = ${userInput}`). Return JSON only as {\"risks\":[CODE]}; allowed CODE is SQL_INJECTION.",
        "score": lambda text: parse_json(text) == {"risks": ["SQL_INJECTION"]},
    },
    {
        "task_class": "tool_selection",
        "prompt": "You changed a parser and must verify behavior. Available tools: search_files, run_tests. Return JSON only as {\"tool\":NAME}.",
        "score": lambda text: parse_json(text) == {"tool": "run_tests"},
    },
]


def utc_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return default


def write_json_private(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(f"{path.name}.{os.getpid()}.tmp")
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8")
    os.chmod(temp, 0o600)
    temp.replace(path)
    os.chmod(path, 0o600)


def parse_json(text: str) -> Any:
    cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip(), flags=re.I | re.S)
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", cleaned, flags=re.S)
        if not match:
            return None
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError:
            return None


def http_json(
    url: str,
    payload: dict[str, Any] | None = None,
    timeout: float = 300,
    method: str | None = None,
) -> tuple[int, Any, float, str | None]:
    headers = {"Content-Type": "application/json"}
    token = os.environ.get("LM_API_TOKEN", "")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = request.Request(url, data=data, headers=headers, method=method or ("POST" if payload is not None else "GET"))
    started = time.monotonic()
    try:
        with request.urlopen(req, timeout=timeout) as response:
            return response.status, json.loads(response.read() or b"{}"), (time.monotonic() - started) * 1000, None
    except error.HTTPError as exc:
        raw = exc.read()
        try:
            body = json.loads(raw or b"{}")
        except json.JSONDecodeError:
            body = {}
        return exc.code, body, (time.monotonic() - started) * 1000, str(body.get("error") or body.get("message") or f"HTTP {exc.code}")
    except (error.URLError, TimeoutError, OSError) as exc:
        return 0, {}, (time.monotonic() - started) * 1000, str(exc)


def models_state(endpoint: str, engine: str) -> list[dict[str, Any]]:
    path = "/api/v1/models" if engine == "lmstudio" else "/v1/models/status"
    status, body, _, message = http_json(endpoint + path, timeout=15)
    if status != 200:
        raise RuntimeError(message or f"model list HTTP {status}")
    return body.get("models", []) if isinstance(body, dict) else []


def loaded_instances(endpoint: str, engine: str) -> dict[str, list[str]]:
    result: dict[str, list[str]] = {}
    for item in models_state(endpoint, engine):
        key = str(item.get("key") or item.get("id") or "")
        if engine == "lmstudio":
            ids = [str(instance.get("id")) for instance in item.get("loaded_instances", []) if isinstance(instance, dict) and instance.get("id")]
        else:
            ids = [key] if item.get("loaded") else []
        if key and ids:
            result[key] = ids
    return result


def load_model(endpoint: str, engine: str, model_id: str) -> tuple[list[str], bool, str | None]:
    before = loaded_instances(endpoint, engine)
    other = {key: ids for key, ids in before.items() if key != model_id and ids}
    if other:
        return [], False, "other_loaded_model_present"
    if before.get(model_id):
        return before[model_id], False, None
    if engine == "lmstudio":
        status, _, _, message = http_json(endpoint + "/api/v1/models/load", {"model": model_id, "context_length": 8192, "flash_attention": True, "echo_load_config": True}, timeout=600)
    else:
        encoded_id = parse.quote(model_id, safe="")
        status, _, _, message = http_json(endpoint + f"/v1/models/{encoded_id}/load", timeout=600, method="POST")
    if status != 200:
        return [], False, message or f"load_http_{status}"
    for _ in range(120):
        current_state = loaded_instances(endpoint, engine)
        current = current_state.get(model_id, [])
        if current:
            if engine == "omlx":
                newly_loaded = [handle for key, handles in current_state.items() if key not in before for handle in handles]
                return newly_loaded or current, True, None
            return current, True, None
        time.sleep(1)
    return [], True, "load_timeout"


def unload_instances(endpoint: str, engine: str, instance_ids: list[str]) -> None:
    for instance_id in instance_ids:
        if engine == "lmstudio":
            http_json(endpoint + "/api/v1/models/unload", {"instance_id": instance_id}, timeout=120)
        else:
            encoded_id = parse.quote(instance_id, safe="")
            http_json(endpoint + f"/v1/models/{encoded_id}/unload", timeout=120, method="POST")


def chat(endpoint: str, model_id: str, prompt: str) -> tuple[int, str, float, str | None]:
    status, body, latency, message = http_json(
        endpoint + "/v1/chat/completions",
        {"model": model_id, "messages": [{"role": "user", "content": prompt}], "temperature": 0, "max_tokens": 192, "stream": False},
        timeout=180,
    )
    choices = body.get("choices", []) if isinstance(body, dict) else []
    text = str(choices[0].get("message", {}).get("content", "")) if choices and isinstance(choices[0], dict) else ""
    return status, text, latency, message


def update_qualification(root: Path, backend_id: str, engine: str, model_id: str, results: list[dict[str, Any]], aggregate: str, average_latency: float | None) -> None:
    path = root / ".kernel/model-qualification.local.json"
    doc = read_json(path, {"version": 1, "kind": "model_qualification_local", "records": []})
    records = doc.setdefault("records", [])
    task_classes = {item["task_class"] for item in results} | {"general"}
    records[:] = [item for item in records if not (item.get("backend_id") == backend_id and item.get("model_id") == model_id and item.get("task_class") in task_classes)]
    now_epoch = int(time.time())
    for item in results:
        records.append({
            "backend_id": backend_id,
            "model_id": model_id,
            "task_class": item["task_class"],
            "status": "qualified" if item["passed"] else "unqualified",
            "checked_at": utc_iso(),
            "checked_at_epoch": now_epoch,
            "protocol": f"{engine}_openai_chat_benchmark_v1",
            "latency_ms": item.get("latency_ms"),
            "summary": "deterministic_case_pass" if item["passed"] else "deterministic_case_fail",
            "response_sha256": item.get("response_sha256"),
        })
    records.append({
        "backend_id": backend_id,
        "model_id": model_id,
        "task_class": "general",
        "status": aggregate,
        "checked_at": utc_iso(),
        "checked_at_epoch": now_epoch,
        "protocol": f"{engine}_openai_chat_benchmark_v1",
        "latency_ms": average_latency,
        "summary": f"{sum(1 for item in results if item['passed'])}/{len(results)} deterministic cases passed",
    })
    doc["updated_at"] = utc_iso()
    write_json_private(path, doc)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--backend", default="lmstudio")
    parser.add_argument("--models", default="")
    parser.add_argument("--allow-load", action="store_true")
    parser.add_argument("--output")
    args = parser.parse_args()
    root = Path(args.root).expanduser().resolve()
    backends = read_json(root / ".kernel/execution-backends.local.json", {"backends": []})
    inventory = read_json(root / ".kernel/model-inventory.local.json", {"models": []})
    backend = next((item for item in backends.get("backends", []) if item.get("id") == args.backend), None)
    engine = str(backend.get("engine", "")) if backend else ""
    if not backend or backend.get("status") != "available" or engine not in {"lmstudio", "omlx"}:
        raise SystemExit("Supported local model backend is not available; run backend discovery first")
    endpoint = str(backend.get("endpoint", "")).rstrip("/")
    requested = {item.strip() for item in args.models.split(",") if item.strip()}
    candidates = [item for item in inventory.get("models", []) if item.get("backend_id") == args.backend and "generation" in item.get("capabilities", []) and (not requested or item.get("model_id") in requested)]
    if not candidates:
        raise SystemExit("No benchmarkable models selected")
    output_path = Path(args.output).expanduser().resolve() if args.output else root / ".kernel/local-model-benchmarks.local.json"
    benchmark = {"version": 1, "kind": "local_model_benchmarks", "generated_at": utc_iso(), "backend_id": args.backend, "serialized": True, "auto_load": bool(args.allow_load), "models": []}
    for model in candidates:
        model_id = str(model["model_id"])
        instances = loaded_instances(endpoint, engine).get(model_id, [])
        loaded_by_script = False
        load_error = None
        if not instances and args.allow_load:
            instances, loaded_by_script, load_error = load_model(endpoint, engine, model_id)
        if not instances:
            benchmark["models"].append({"model_id": model_id, "status": "untested", "reason": load_error or "not_loaded_no_autoload", "cases": []})
            continue
        case_results: list[dict[str, Any]] = []
        try:
            for case in CASES:
                status, text, latency, message = chat(endpoint, model_id, case["prompt"])
                passed = status == 200 and bool(case["score"](text))
                case_results.append({
                    "task_class": case["task_class"],
                    "passed": passed,
                    "status_code": status,
                    "latency_ms": round(latency, 1),
                    "response_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
                    "error": message[:120] if message else None,
                })
        finally:
            if loaded_by_script:
                unload_instances(endpoint, engine, instances)
        passed_count = sum(1 for item in case_results if item["passed"])
        aggregate = "qualified" if passed_count >= 4 else "limited" if passed_count >= 2 else "unqualified"
        latencies = [float(item["latency_ms"]) for item in case_results if item.get("latency_ms") is not None]
        average_latency = round(sum(latencies) / len(latencies), 1) if latencies else None
        benchmark["models"].append({"model_id": model_id, "status": aggregate, "passed": passed_count, "total": len(case_results), "average_latency_ms": average_latency, "cases": case_results})
        update_qualification(root, args.backend, engine, model_id, case_results, aggregate, average_latency)
    write_json_private(output_path, benchmark)
    print(json.dumps(benchmark, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
