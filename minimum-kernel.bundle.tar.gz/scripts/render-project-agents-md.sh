#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KERNEL_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

usage() {
  cat <<'EOF'
Usage: render-project-agents-md.sh --project-root <path> [--check | --write] [--force]

Options:
  --project-root <path>  Project root to inspect.
  --check                Validate whether AGENTS.md is fresh for the current project state.
  --write                Render or refresh AGENTS.md and update .agent/project_state.json.
  --force                Force write even if the structural source hash has not changed.
EOF
}

emit_info() {
  printf 'INFO: %s\n' "$1"
}

emit_error() {
  printf 'ERROR: %s\n' "$1" >&2
}

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || {
    emit_error "Missing required command: $1"
    exit 1
  }
}

trim_copy() {
  local source="$1"
  local target="$2"
  awk '
    {
      lines[++count] = $0
      if ($0 !~ /^[[:space:]]*$/) {
        last_non_blank = count
      }
    }
    END {
      first_non_blank = 0
      for (i = 1; i <= count; i++) {
        if (lines[i] !~ /^[[:space:]]*$/) {
          first_non_blank = i
          break
        }
      }
      if (first_non_blank == 0) {
        exit
      }
      for (i = first_non_blank; i <= last_non_blank; i++) {
        print lines[i]
      }
    }
  ' "$source" > "$target"
}

extract_section() {
  local file="$1"
  local heading="$2"
  local target="$3"
  local raw
  raw="$(mktemp "${TMPDIR:-/tmp}/agents-section-raw.XXXXXX")"
  awk -v heading="$heading" '
    $0 == heading { capture = 1; next }
    capture && (/^## / || /^<!-- GEMINI_STATE_END -->$/ || /^\*\*Stack:\*\*/ || /^\*\*State:\*\*/ || /^\*\*Local Services:\*\*/ || /^\*\*Repo Constraints:\*\*/ || /^\*\*Docs Pointers:\*\*/) { exit }
    capture { print }
  ' "$file" > "$raw"
  trim_copy "$raw" "$target"
  rm -f "$raw"
}

extract_between_markers() {
  local file="$1"
  local begin="$2"
  local end="$3"
  local target="$4"
  awk -v begin="$begin" -v end="$end" '
    $0 == begin { capture = 1; next }
    $0 == end { capture = 0; exit }
    capture { print }
  ' "$file" > "$target"
}

json_array_from_file() {
  local file="$1"
  jq -Rn '
    [
      inputs
      | gsub("\r$"; "")
      | gsub("^\\s*[-*]\\s*"; "")
      | gsub("^\\s+"; "")
      | gsub("\\s+$"; "")
      | select(length > 0)
    ]
  ' < "$file"
}

render_section_from_source() {
  local title="$1"
  local section_file="$2"
  local fallback_json="$3"
  local default_line="$4"

  printf '## %s\n' "$title"
  if [[ -s "$section_file" ]]; then
    cat "$section_file"
  elif jq -e 'length > 0' >/dev/null 2>&1 <<< "$fallback_json"; then
    jq -r '.[] | "- " + .' <<< "$fallback_json"
  else
    printf -- '- %s\n' "$default_line"
  fi
  printf '\n'
}

json_bool() {
  if [[ "$1" == "true" ]]; then
    printf 'true'
  else
    printf 'false'
  fi
}

MODE="check"
FORCE="false"
PROJECT_ROOT=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --project-root)
      PROJECT_ROOT="${2:-}"
      shift 2
      ;;
    --check)
      MODE="check"
      shift
      ;;
    --write)
      MODE="write"
      shift
      ;;
    --force)
      FORCE="true"
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      emit_error "Unknown argument: $1"
      usage
      exit 1
      ;;
  esac
done

if [[ -z "$PROJECT_ROOT" ]]; then
  emit_error "--project-root is required"
  usage
  exit 1
fi

require_cmd jq
require_cmd awk
require_cmd sed
require_cmd shasum
require_cmd rg
require_cmd python3

PROJECT_ROOT="$(cd "$PROJECT_ROOT" && pwd)"
GEMINI_PATH="$PROJECT_ROOT/GEMINI.md"
STATE_PATH="$PROJECT_ROOT/.agent/project_state.json"
AGENTS_PATH="$PROJECT_ROOT/AGENTS.md"
CURRENT_STATE_PATH="$PROJECT_ROOT/.agent/current_state.md"
CURRENT_STATE_JSON_PATH="$PROJECT_ROOT/.agent/current_state.json"
PROJECT_DNA_PATH="$PROJECT_ROOT/.agent/knowledge/.project_dna.md"
PROJECT_HISTORY_PATH="$PROJECT_ROOT/PROJECT_HISTORY.md"
ERROR_LOG_PATH="$PROJECT_ROOT/ERROR_LOG.md"
DESIGN_SYSTEM_PATH="$PROJECT_ROOT/DESIGN_SYSTEM.md"
LLMS_PATH="$PROJECT_ROOT/llms.txt"
SERVER_JSON_PATH="$PROJECT_ROOT/server.json"
MCP_JSON_PATH="$PROJECT_ROOT/.mcp.json"
AGENT_CARD_PATH="$PROJECT_ROOT/.well-known/agent-card.json"
AGENT_TOOLS_PATH="$PROJECT_ROOT/agent-tools.js"
READ_CONTRACT_PATH="$KERNEL_ROOT/state/read_contract.json"
READ_CONTRACT_RENDERER="$KERNEL_ROOT/scripts/render-read-contract.py"

[[ -f "$STATE_PATH" ]] || {
  emit_error "Missing required state file: $STATE_PATH"
  exit 1
}
[[ -f "$GEMINI_PATH" ]] || {
  emit_error "Missing required project context file: $GEMINI_PATH"
  exit 1
}
[[ -f "$READ_CONTRACT_PATH" ]] || {
  emit_error "Missing read contract: $READ_CONTRACT_PATH"
  exit 1
}
[[ -f "$READ_CONTRACT_RENDERER" ]] || {
  emit_error "Missing read-contract renderer: $READ_CONTRACT_RENDERER"
  exit 1
}

TMP_DIR="$(mktemp -d "${TMPDIR:-/tmp}/render-project-agents.XXXXXX")"
trap 'rm -rf "$TMP_DIR"' EXIT

QUICKSTART_FILE="$TMP_DIR/shared-quickstart.md"
RULES_FILE="$TMP_DIR/shared-agent-rules.md"
ARCH_FILE="$TMP_DIR/shared-architecture-notes.md"
HUMAN_FILE="$TMP_DIR/agents-human.md"
GENERATED_FILE="$TMP_DIR/agents-generated.md"
RENDERED_FILE="$TMP_DIR/agents-rendered.md"
EXISTING_GENERATED_FILE="$TMP_DIR/agents-existing-generated.md"
READ_CONTRACT_FILE="$TMP_DIR/read-contract-generated.md"
EMPTY_FILE="$TMP_DIR/empty"
: > "$EMPTY_FILE"

extract_section "$GEMINI_PATH" "## Shared Quickstart" "$QUICKSTART_FILE"
extract_section "$GEMINI_PATH" "## Shared Agent Rules" "$RULES_FILE"
extract_section "$GEMINI_PATH" "## Shared Architecture Notes" "$ARCH_FILE"

STATE_PROJECT="$(jq -r '.project // "unknown-project"' "$STATE_PATH")"
EXISTING_PROJECT_TYPE="$(jq -r '.agent_onboarding.project_type // empty' "$STATE_PATH")"
EXISTING_UI_PROJECT="$(jq -r '.agent_onboarding.ui_project // false' "$STATE_PATH")"
EXISTING_RULES_JSON="$(jq -c '.agent_onboarding.shared_rules // []' "$STATE_PATH")"
EXISTING_ARCH_JSON="$(jq -c '.agent_onboarding.architecture_summary // []' "$STATE_PATH")"
EXISTING_QUICKSTART_JSON="$(jq -c '.agent_onboarding.quickstart_commands // []' "$STATE_PATH")"
EXISTING_SURFACES_JSON="$(jq -c '.agent_onboarding.agentic_surfaces // []' "$STATE_PATH")"
EXISTING_SOURCE_HASH="$(jq -r '.agent_onboarding.source_hash // ""' "$STATE_PATH")"
EXISTING_RENDER_HASH="$(jq -r '.agent_onboarding.render_hash // ""' "$STATE_PATH")"

SECTION_RULES_JSON="$(json_array_from_file "$RULES_FILE")"
SECTION_ARCH_JSON="$(json_array_from_file "$ARCH_FILE")"
SECTION_QUICKSTART_JSON="$(json_array_from_file "$QUICKSTART_FILE")"

if jq -e 'length > 0' >/dev/null 2>&1 <<< "$SECTION_RULES_JSON"; then
  SHARED_RULES_JSON="$SECTION_RULES_JSON"
else
  SHARED_RULES_JSON="$EXISTING_RULES_JSON"
fi

if jq -e 'length > 0' >/dev/null 2>&1 <<< "$SECTION_ARCH_JSON"; then
  ARCH_SUMMARY_JSON="$SECTION_ARCH_JSON"
else
  ARCH_SUMMARY_JSON="$EXISTING_ARCH_JSON"
fi

ARCH_SUMMARY_JSON="$(
  jq -c '
    map(
      if . == "Global runtime policy lives in GEMINI.md, memory governance in MEMORY.md, and portable recovery in GEMINI_BLUEPRINTS.md." then
        "Global runtime policy lives in GEMINI.md, memory governance in MEMORY.md, and portable recovery lives in the recovery bundle GEMINI_BLUEPRINTS.md."
      elif . == "Human live state is anchored in .agent/current_state.md; .agent/project_state.json is regenerable script/cache output." then
        "Live handoff is read from .agent/current_state.md; .agent/current_state.json is the structured state source while fresh; .agent/project_state.json is regenerable script/cache output."
      elif . == "Machine live state is anchored in .agent/current_state.json; .agent/current_state.md is the rendered human handoff view; .agent/project_state.json is regenerable script/cache output." then
        "Live handoff is read from .agent/current_state.md; .agent/current_state.json is the structured state source while fresh; .agent/project_state.json is regenerable script/cache output."
      elif . == "Machine live state is anchored in .agent/current_state.json; .agent/current_state.md is the agent-readable live handoff view; .agent/project_state.json is regenerable script/cache output." then
        "Live handoff is read from .agent/current_state.md; .agent/current_state.json is the structured state source while fresh; .agent/project_state.json is regenerable script/cache output."
      else
        .
      end
    )
  ' <<< "$ARCH_SUMMARY_JSON"
)"

if jq -e 'length > 0' >/dev/null 2>&1 <<< "$SECTION_QUICKSTART_JSON"; then
  QUICKSTART_JSON="$SECTION_QUICKSTART_JSON"
else
  QUICKSTART_JSON="$EXISTING_QUICKSTART_JSON"
fi

QUICKSTART_JSON="$(
  jq -c '
    if . == [
      "bash scripts/gemini-doctor.sh",
      "bash scripts/run-core-evals.sh",
      "bash scripts/build-blueprints.sh"
    ] then
      [
        "Read AGENTS.md, then .agent/current_state.md; inspect target files after task classification.",
        "Run bash scripts/gemini-doctor.sh --runtime after live-state or kernel-surface edits.",
        "Run bash scripts/run-core-evals.sh only for broad kernel validation."
      ]
    else
      .
    end
  ' <<< "$QUICKSTART_JSON"
)"

HAS_SHARED_EXPORTS="false"
if [[ -s "$QUICKSTART_FILE" || -s "$RULES_FILE" || -s "$ARCH_FILE" ]]; then
  HAS_SHARED_EXPORTS="true"
fi

DETECTED_PROJECT_TYPE="general"
if [[ -n "$EXISTING_PROJECT_TYPE" ]]; then
  DETECTED_PROJECT_TYPE="$EXISTING_PROJECT_TYPE"
elif [[ -f "$PROJECT_ROOT/package.json" ]]; then
  PKG_DEPS="$(jq -r '[(.dependencies // {}), (.devDependencies // {}), (.peerDependencies // {})] | add | keys[]?' "$PROJECT_ROOT/package.json" 2>/dev/null || true)"
  if grep -Eq '^(next|remix|nuxt)$' <<< "$PKG_DEPS"; then
    DETECTED_PROJECT_TYPE="full-stack"
  elif grep -Eq '^(express|fastify|@nestjs/core|hono)$' <<< "$PKG_DEPS"; then
    DETECTED_PROJECT_TYPE="backend-api"
  elif grep -Eq '^(react|vue|svelte)$' <<< "$PKG_DEPS"; then
    DETECTED_PROJECT_TYPE="frontend"
  else
    DETECTED_PROJECT_TYPE="node-project"
  fi
elif [[ -f "$PROJECT_ROOT/pyproject.toml" ]]; then
  if rg -q 'fastapi|django|flask' "$PROJECT_ROOT/pyproject.toml"; then
    DETECTED_PROJECT_TYPE="backend-api"
  else
    DETECTED_PROJECT_TYPE="python-project"
  fi
elif [[ -f "$PROJECT_ROOT/Cargo.toml" ]]; then
  DETECTED_PROJECT_TYPE="cli-library"
fi

UI_PROJECT="false"
if [[ "$EXISTING_UI_PROJECT" == "true" || -f "$DESIGN_SYSTEM_PATH" ]]; then
  UI_PROJECT="true"
elif [[ "$DETECTED_PROJECT_TYPE" == "frontend" || "$DETECTED_PROJECT_TYPE" == "full-stack" ]]; then
  UI_PROJECT="true"
fi

HAS_GEMINI="true"
HAS_CURRENT_STATE="false"
HAS_PROJECT_DNA="false"
HAS_PROJECT_HISTORY="false"
HAS_ERROR_LOG="false"
HAS_DESIGN_SYSTEM="false"

if [[ -f "$CURRENT_STATE_PATH" || -f "$CURRENT_STATE_JSON_PATH" ]]; then
  HAS_CURRENT_STATE="true"
fi
[[ -f "$PROJECT_DNA_PATH" ]] && HAS_PROJECT_DNA="true"
[[ -f "$PROJECT_HISTORY_PATH" ]] && HAS_PROJECT_HISTORY="true"
[[ -f "$ERROR_LOG_PATH" ]] && HAS_ERROR_LOG="true"
[[ -f "$DESIGN_SYSTEM_PATH" ]] && HAS_DESIGN_SYSTEM="true"

python3 "$READ_CONTRACT_RENDERER" \
  --kernel-root "$KERNEL_ROOT" \
  --target agents-block \
  --shared-exports "$HAS_SHARED_EXPORTS" \
  --has-design-system "$HAS_DESIGN_SYSTEM" \
  --has-error-log "$HAS_ERROR_LOG" \
  --has-project-history "$HAS_PROJECT_HISTORY" \
  > "$READ_CONTRACT_FILE"

DETECTED_SURFACES_JSON="$(
  jq -nc \
    --arg llms "$( [[ -f "$LLMS_PATH" ]] && printf 'llms.txt' || printf '' )" \
    --arg server "$( [[ -f "$SERVER_JSON_PATH" ]] && printf 'server.json' || printf '' )" \
    --arg mcp "$( [[ -f "$MCP_JSON_PATH" ]] && printf '.mcp.json' || printf '' )" \
    --arg card "$( [[ -f "$AGENT_CARD_PATH" ]] && printf '.well-known/agent-card.json' || printf '' )" \
    --arg tools "$( [[ -f "$AGENT_TOOLS_PATH" ]] && printf 'agent-tools.js' || printf '' )" \
    '[$llms, $server, $mcp, $card, $tools] | map(select(length > 0))'
)"

AGENTIC_SURFACES_JSON="$(
  jq -nc \
    --argjson detected "$DETECTED_SURFACES_JSON" \
    --argjson existing "$EXISTING_SURFACES_JSON" \
    '$detected + $existing | unique'
)"

DOCS_PRESENCE_JSON="$(
  jq -nc \
    --argjson gemini "$(json_bool "$HAS_GEMINI")" \
    --argjson project_history "$(json_bool "$HAS_PROJECT_HISTORY")" \
    --argjson error_log "$(json_bool "$HAS_ERROR_LOG")" \
    --argjson design_system "$(json_bool "$HAS_DESIGN_SYSTEM")" \
    --argjson project_dna "$(json_bool "$HAS_PROJECT_DNA")" \
    --argjson current_state "$(json_bool "$HAS_CURRENT_STATE")" \
    '{
      gemini: $gemini,
      project_history: $project_history,
      error_log: $error_log,
      design_system: $design_system,
      project_dna: $project_dna,
      current_state: $current_state
    }'
)"

SOURCE_BLOB="$(cat <<EOF
project=${STATE_PROJECT}
project_type=${DETECTED_PROJECT_TYPE}
ui_project=${UI_PROJECT}
docs_presence=$(jq -c -S . <<< "$DOCS_PRESENCE_JSON")
agentic_surfaces=$(jq -c -S . <<< "$AGENTIC_SURFACES_JSON")
read_contract=$(cat "$READ_CONTRACT_PATH")
rendered_read_contract=$(cat "$READ_CONTRACT_FILE")
shared_quickstart=$(cat "$QUICKSTART_FILE")
shared_rules=$(cat "$RULES_FILE")
shared_architecture=$(cat "$ARCH_FILE")
fallback_quickstart=$(jq -c -S . <<< "$QUICKSTART_JSON")
fallback_rules=$(jq -c -S . <<< "$SHARED_RULES_JSON")
fallback_architecture=$(jq -c -S . <<< "$ARCH_SUMMARY_JSON")
EOF
)"
SOURCE_HASH="$(printf '%s' "$SOURCE_BLOB" | shasum -a 256 | awk '{print $1}')"

if [[ -f "$AGENTS_PATH" ]]; then
  if rg -q '^<!-- AGENTS_HUMAN_START -->$' "$AGENTS_PATH" && rg -q '^<!-- AGENTS_HUMAN_END -->$' "$AGENTS_PATH"; then
    extract_between_markers "$AGENTS_PATH" "<!-- AGENTS_HUMAN_START -->" "<!-- AGENTS_HUMAN_END -->" "$HUMAN_FILE"
  else
    cp "$AGENTS_PATH" "$HUMAN_FILE"
  fi

  if rg -q '^<!-- AGENTS_GENERATED_START -->$' "$AGENTS_PATH" && rg -q '^<!-- AGENTS_GENERATED_END -->$' "$AGENTS_PATH"; then
    extract_between_markers "$AGENTS_PATH" "<!-- AGENTS_GENERATED_START -->" "<!-- AGENTS_GENERATED_END -->" "$EXISTING_GENERATED_FILE"
  else
    : > "$EXISTING_GENERATED_FILE"
  fi
else
  : > "$HUMAN_FILE"
  : > "$EXISTING_GENERATED_FILE"
fi

render_section_from_source \
  "Project Summary" \
  "$EMPTY_FILE" \
  "$(jq -nc --arg project "$STATE_PROJECT" --arg project_type "$DETECTED_PROJECT_TYPE" '
    [
      ("Project: " + $project + " (" + $project_type + ")"),
      "Canon: GEMINI.md; live handoff: .agent/current_state.md; structured state: .agent/current_state.json."
    ]
  ')" \
  "Review GEMINI.md before mutating the project." \
  > "$GENERATED_FILE"

render_section_from_source \
  "How To Start" \
  "$QUICKSTART_FILE" \
  "$QUICKSTART_JSON" \
  "Read this file first, then .agent/current_state.md; inspect GEMINI.md only after task classification." \
  >> "$GENERATED_FILE"

cat "$READ_CONTRACT_FILE" >> "$GENERATED_FILE"

if [[ -s "$ARCH_FILE" ]]; then
  render_section_from_source \
    "Architecture & Boundaries" \
    "$ARCH_FILE" \
    "$ARCH_SUMMARY_JSON" \
    "No shared architecture notes were exported yet; inspect GEMINI.md before structural changes." \
    >> "$GENERATED_FILE"
fi

if [[ -s "$RULES_FILE" ]]; then
  render_section_from_source \
    "Essential Working Rules" \
    "$RULES_FILE" \
    "$SHARED_RULES_JSON" \
    "No shared rules were exported yet; default to safe, minimal, reversible edits." \
    >> "$GENERATED_FILE"
fi

if jq -e 'length > 0' >/dev/null 2>&1 <<< "$AGENTIC_SURFACES_JSON"; then
  cat >> "$GENERATED_FILE" <<EOF

## Agentic Surfaces
EOF
  while IFS= read -r surface; do
    case "$surface" in
      "llms.txt")
        printf -- '- `llms.txt`: semantic map for external agents.\n' >> "$GENERATED_FILE"
        ;;
      "server.json")
        printf -- '- `server.json`: primary MCP capability manifest.\n' >> "$GENERATED_FILE"
        ;;
      ".mcp.json")
        printf -- '- `.mcp.json`: supplemental MCP surface that should stay aligned with `server.json`.\n' >> "$GENERATED_FILE"
        ;;
      ".well-known/agent-card.json")
        printf -- '- `.well-known/agent-card.json`: machine-readable A2A identity and capability card.\n' >> "$GENERATED_FILE"
        ;;
      "agent-tools.js")
        printf -- '- `agent-tools.js`: browser-oriented tool exposure or fallback registration surface.\n' >> "$GENERATED_FILE"
        ;;
      *)
        printf -- '- `%s`: custom agentic surface recorded in project state.\n' "$surface" >> "$GENERATED_FILE"
        ;;
    esac
  done < <(jq -r '.[]' <<< "$AGENTIC_SURFACES_JSON")
fi

RENDER_HASH="$(shasum -a 256 "$GENERATED_FILE" | awk '{print $1}')"
EXISTING_GENERATED_HASH=""
if [[ -s "$EXISTING_GENERATED_FILE" ]]; then
  EXISTING_GENERATED_HASH="$(shasum -a 256 "$EXISTING_GENERATED_FILE" | awk '{print $1}')"
fi

{
  printf '# AGENTS.md\n\n'
  printf '> Stable onboarding for external agents. The generated block is maintained by `scripts/render-project-agents-md.sh`.\n\n'
  printf '<!-- AGENTS_HUMAN_START -->\n'
  if [[ -s "$HUMAN_FILE" ]]; then
    cat "$HUMAN_FILE"
    if [[ -n "$(tail -c 1 "$HUMAN_FILE" 2>/dev/null)" ]]; then
      printf '\n'
    fi
  fi
  printf '<!-- AGENTS_HUMAN_END -->\n\n'
  printf '<!-- AGENTS_GENERATED_START -->\n'
  cat "$GENERATED_FILE"
  if [[ -n "$(tail -c 1 "$GENERATED_FILE" 2>/dev/null)" ]]; then
    printf '\n'
  fi
  printf '<!-- AGENTS_GENERATED_END -->\n'
} > "$RENDERED_FILE"

if [[ "$MODE" == "check" ]]; then
  if [[ ! -f "$AGENTS_PATH" ]]; then
    emit_error "AGENTS.md is missing."
    exit 1
  fi

  if [[ ! -s "$EXISTING_GENERATED_FILE" ]]; then
    emit_error "AGENTS.md is not managed by the renderer yet."
    exit 1
  fi

  if [[ "$EXISTING_SOURCE_HASH" != "$SOURCE_HASH" ]]; then
    emit_error "AGENTS.md is stale: structural source hash changed."
    exit 1
  fi

  if [[ "$EXISTING_RENDER_HASH" != "$RENDER_HASH" ]]; then
    emit_error "AGENTS.md is stale: stored render hash differs from expected output."
    exit 1
  fi

  if [[ "$EXISTING_GENERATED_HASH" != "$RENDER_HASH" ]]; then
    emit_error "AGENTS.md generated block differs from the deterministic render."
    exit 1
  fi

  emit_info "AGENTS.md is fresh."
  exit 0
fi

STATE_TMP="$TMP_DIR/project_state.updated.json"
jq \
  --arg project_type "$DETECTED_PROJECT_TYPE" \
  --argjson ui_project "$(json_bool "$UI_PROJECT")" \
  --argjson shared_rules "$SHARED_RULES_JSON" \
  --argjson architecture_summary "$ARCH_SUMMARY_JSON" \
  --argjson quickstart_commands "$QUICKSTART_JSON" \
  --argjson docs_presence "$DOCS_PRESENCE_JSON" \
  --argjson agentic_surfaces "$AGENTIC_SURFACES_JSON" \
  --arg source_hash "$SOURCE_HASH" \
  --arg render_hash "$RENDER_HASH" \
  --arg last_rendered_at "$(date -u +"%Y-%m-%dT%H:%M:%SZ")" \
  '
    .agent_onboarding = ((.agent_onboarding // {}) + {
      project_type: $project_type,
      ui_project: $ui_project,
      shared_rules: $shared_rules,
      architecture_summary: $architecture_summary,
      quickstart_commands: $quickstart_commands,
      docs_presence: $docs_presence,
      agentic_surfaces: $agentic_surfaces,
      source_hash: $source_hash,
      render_hash: $render_hash,
      last_rendered_at: $last_rendered_at
    })
  ' "$STATE_PATH" > "$STATE_TMP"

cp "$STATE_TMP" "$STATE_PATH"

if [[ "$FORCE" == "true" || ! -f "$AGENTS_PATH" || "$EXISTING_GENERATED_HASH" != "$RENDER_HASH" ]]; then
  cp "$RENDERED_FILE" "$AGENTS_PATH"
  emit_info "Rendered AGENTS.md."
else
  emit_info "AGENTS.md already matches the deterministic render."
fi

printf 'source_hash=%s\n' "$SOURCE_HASH"
printf 'render_hash=%s\n' "$RENDER_HASH"
