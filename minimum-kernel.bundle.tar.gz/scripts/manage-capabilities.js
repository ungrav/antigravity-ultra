#!/usr/bin/env node
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

function usage(code = 0) {
  const out = code === 0 ? process.stdout : process.stderr;
  out.write(`Usage:
  manage-capabilities.sh scan [--root PATH] [--json]
  manage-capabilities.sh configure-context7 [--root PATH] [--json]
  manage-capabilities.sh doctor [CAPABILITY] [--root PATH] [--json]
  manage-capabilities.sh recommend --task TEXT [--root PATH] [--json]
  manage-capabilities.sh guide CAPABILITY [--root PATH] [--json]
`);
  process.exit(code);
}

function parseArgs(argv) {
  const out = {
    command: argv[0] || '',
    root: process.cwd(),
    capability: '',
    task: '',
    json: false
  };
  for (let i = 1; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--root') out.root = path.resolve(argv[++i] || out.root);
    else if (arg === '--task') out.task = argv[++i] || '';
    else if (arg === '--json') out.json = true;
    else if (!arg.startsWith('-') && !out.capability) out.capability = arg;
    else usage(1);
  }
  if (!out.command) usage(1);
  return out;
}

function readJson(filePath, fallback = {}) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return fallback;
  }
}

function writeJsonAtomic(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const temp = `${filePath}.${process.pid}.tmp`;
  fs.writeFileSync(temp, `${JSON.stringify(value, null, 2)}\n`, { mode: 0o600 });
  fs.renameSync(temp, filePath);
}

function antigravityConfigPath(root) {
  if (process.env.ANTIGRAVITY_MCP_CONFIG) {
    return path.resolve(process.env.ANTIGRAVITY_MCP_CONFIG);
  }
  const local = path.join(root, 'antigravity', 'mcp_config.json');
  if (fs.existsSync(local) || root === path.join(os.homedir(), '.gemini')) return local;
  return path.join(os.homedir(), '.gemini', 'antigravity', 'mcp_config.json');
}

function commandAvailable(command) {
  if (!command) return false;
  if (path.isAbsolute(command)) {
    try {
      fs.accessSync(command, fs.constants.X_OK);
      return true;
    } catch {
      return false;
    }
  }
  return spawnSync('sh', ['-c', `command -v "${command.replace(/"/g, '\\"')}" >/dev/null 2>&1`]).status === 0;
}

function commandVersion(command) {
  if (!command || !commandAvailable(command)) return null;
  const result = spawnSync(command, ['--version'], {
    encoding: 'utf8',
    timeout: 15000
  });
  if (result.error || result.status !== 0) return null;
  return String(result.stdout || result.stderr || '').trim().split(/\s+/)[0] || null;
}

function context7Reachable() {
  if (process.env.CAPABILITY_SKIP_NETWORK === '1') return false;
  const curl = spawnSync('curl', [
    '-sS',
    '--max-time', '5',
    '-o', '/dev/null',
    '-w', '%{http_code}',
    'https://mcp.context7.com/mcp'
  ], { encoding: 'utf8' });
  if (curl.error || curl.status !== 0) return false;
  const status = Number(String(curl.stdout || '').trim());
  return status >= 200 && status < 500;
}

function scan(root) {
  const catalog = readJson(path.join(root, 'config', 'capability-catalog.json'), { capabilities: {} });
  const packageAllowlist = readJson(path.join(root, 'state', 'dependency-package-allowlist.json'), { packages: [] });
  const configPath = antigravityConfigPath(root);
  const config = readJson(configPath, { mcpServers: {} });
  const servers = config.mcpServers || {};
  const now = new Date().toISOString();
  const capabilities = {};

  for (const [id, definition] of Object.entries(catalog.capabilities || {})) {
    const server = servers[id];
    let status = 'missing';
    const approvedPackage = (packageAllowlist.packages || [])
      .find((entry) => definition.package && entry.name === definition.package);
    let installedVersion = approvedPackage?.version || null;
    if (id === 'context7') {
      const configured = Boolean(server && (server.serverUrl === definition.remote_url || server.httpUrl === definition.remote_url));
      status = configured ? (context7Reachable() ? 'available' : 'degraded') : 'missing';
    } else if (definition.kind === 'local_mcp' && server) {
      status = server.disabled === true ? 'disabled' : (commandAvailable(server.command) ? 'available' : 'degraded');
    } else if (definition.kind === 'cli_workflow') {
      const generatedSkill = path.join(root, '.agent', 'skills', 'openspec-propose', 'SKILL.md');
      const projectShim = path.join(root, '.kernel', 'dependency-safety', 'bin', id);
      const command = commandAvailable(id)
        ? id
        : commandAvailable(projectShim)
          ? projectShim
          : null;
      const detectedVersion = command ? commandVersion(command) : null;
      if (detectedVersion) {
        status = 'available';
        installedVersion = detectedVersion;
      } else {
        status = id === 'openspec' && fs.existsSync(generatedSkill) ? 'degraded' : 'missing';
      }
    }
    capabilities[id] = {
      kind: definition.kind,
      status,
      source: definition.official_source,
      installed_version: installedVersion,
      consent: id === 'context7'
        ? 'foundation'
        : status === 'available'
          ? 'existing_configuration'
          : 'not_recorded',
      checked_at: now
    };
  }

  const inventory = {
    version: 1,
    host: 'antigravity',
    config_path: configPath,
    generated_at: now,
    capabilities
  };
  writeJsonAtomic(path.join(root, '.kernel', 'capabilities.local.json'), inventory);
  return inventory;
}

function configureContext7(root) {
  const configPath = antigravityConfigPath(root);
  const config = readJson(configPath, {});
  const servers = config.mcpServers && typeof config.mcpServers === 'object' ? config.mcpServers : {};
  const previous = servers.context7 && typeof servers.context7 === 'object' ? servers.context7 : {};
  servers.context7 = {
    ...previous,
    serverUrl: 'https://mcp.context7.com/mcp'
  };
  config.mcpServers = servers;
  writeJsonAtomic(configPath, config);
  return scan(root);
}

function recommend(root, task) {
  const catalog = readJson(path.join(root, 'config', 'capability-catalog.json'), { capabilities: {} });
  const inventory = scan(root);
  const normalized = String(task || '').toLowerCase();
  const rules = {
    context7: /(library|biblioteca|sdk|framework|api|cli|cloud|version|versi[oó]n|docs|documentaci|configur|migrat|dependenc)/,
    openspec: /(feature|public behavior|api|auth|payment|storage|architecture|arquitectura|dependency|tooling|deploy|broad refactor|multi-file)/,
    serena: /(refactor|rename|extract|move|symbol|call hierarchy|ownership|multi-file)/,
    playwright: /(web ui|browser|route|form|modal|navigation|visual|accessibility|frontend)/,
    graphify: /(large repo|unfamiliar repo|architecture map|blast radius|cross-cutting|4\\+|repo grande|repositorio grande|mapa de arquitectura|an[aá]lisis de impacto)/,
    insforge: /(insforge|backend metadata|database schema|storage bucket|edge function|backend logs)/
  };
  const recommendations = Object.keys(catalog.capabilities || {})
    .filter((id) => rules[id] && rules[id].test(normalized))
    .map((id) => ({
      id,
      status: inventory.capabilities[id]?.status || 'missing',
      action: inventory.capabilities[id]?.status === 'available' ? 'use' : 'recommend_install_or_fallback',
      official_source: catalog.capabilities[id].official_source,
      fallback: catalog.capabilities[id].fallback || null
    }));
  return { task, recommendations };
}

function guide(root, capabilityId) {
  const catalog = readJson(path.join(root, 'config', 'capability-catalog.json'), { capabilities: {} });
  const definition = catalog.capabilities?.[capabilityId];
  if (!definition) return { error: 'unknown capability', capability: capabilityId };
  return {
    capability: capabilityId,
    kind: definition.kind,
    official_source: definition.official_source,
    package: definition.package || null,
    policy: definition.default_policy,
    instructions: capabilityId === 'context7'
      ? ['Run configure-context7.', 'An API key is optional and must stay in protected local configuration.']
      : [
          'Use Context7 to read the current official installation instructions.',
          'Resolve and approve an exact version through the dependency-safety guard.',
          'Request user consent before changing local Antigravity configuration.',
          'Run scan and doctor after installation.'
        ],
    project_output: definition.project_output || null,
    project_output_policy: definition.project_output_policy || null
  };
}

function print(value, json) {
  if (json) process.stdout.write(`${JSON.stringify(value, null, 2)}\n`);
  else process.stdout.write(`${JSON.stringify(value)}\n`);
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.command === 'scan') return print(scan(args.root), args.json);
  if (args.command === 'configure-context7') return print(configureContext7(args.root), args.json);
  if (args.command === 'doctor') {
    const inventory = scan(args.root);
    const result = args.capability ? inventory.capabilities[args.capability] : inventory;
    if (!result) process.exitCode = 1;
    return print(result || { error: 'unknown capability' }, args.json);
  }
  if (args.command === 'recommend') return print(recommend(args.root, args.task), args.json);
  if (args.command === 'guide') {
    const result = guide(args.root, args.capability);
    if (result.error) process.exitCode = 1;
    return print(result, args.json);
  }
  usage(1);
}

main();
