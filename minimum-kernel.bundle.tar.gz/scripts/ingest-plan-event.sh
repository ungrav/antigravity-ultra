#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KERNELCTL="$SCRIPT_DIR/kernelctl.py"

usage() {
  cat <<'EOF'
Usage:
  ingest-plan-event.sh [--root PATH] (--event-file PATH | --event-json JSON)

Description:
  Compatibility wrapper for host-emitted implementation-plan lifecycle events.
  The transition engine lives in scripts/kernelctl.py.
EOF
}

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  usage
  exit 0
fi

[[ -f "$KERNELCTL" ]] || {
  echo "Missing kernel control helper: $KERNELCTL" >&2
  exit 1
}

exec python3 "$KERNELCTL" plan ingest "$@"
