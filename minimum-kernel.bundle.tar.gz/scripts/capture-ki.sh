#!/usr/bin/env bash
set -euo pipefail

ROOT="$HOME/.gemini"
TITLE=""
SUMMARY=""
TENANT_DOMAIN=""
KIND="auto"
ENTITIES_INPUT=""
RELATED_INPUT=""
SOURCE_WORKFLOW=""
WRITE=0
SUGGEST_FROM_CURRENT_STATE=0
JSON_OUTPUT=0

usage() {
  cat <<'EOF'
Usage:
  capture-ki.sh --root PATH --summary TEXT [options] --write
  capture-ki.sh --root PATH --suggest-from-current-state [--json] [--write]

Options:
  --title TEXT
  --tenant-domain DOMAIN
  --kind KIND|auto
  --entities JSON_OR_CSV
  --related-kis JSON_OR_CSV
  --source-workflow NAME
  --suggest-from-current-state
  --json
  --write

Description:
  Canonical memory-note capture entrypoint. Normal flow requires only
  --summary and --write; the helper infers title, tenant, kind, family, and
  lightweight metadata unless you override them.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --root)
      ROOT="$2"
      shift 2
      ;;
    --title)
      TITLE="$2"
      shift 2
      ;;
    --summary)
      SUMMARY="$2"
      shift 2
      ;;
    --tenant-domain)
      TENANT_DOMAIN="$2"
      shift 2
      ;;
    --kind)
      KIND="$2"
      shift 2
      ;;
    --entities)
      ENTITIES_INPUT="$2"
      shift 2
      ;;
    --related-kis)
      RELATED_INPUT="$2"
      shift 2
      ;;
    --source-workflow)
      SOURCE_WORKFLOW="$2"
      shift 2
      ;;
    --suggest-from-current-state)
      SUGGEST_FROM_CURRENT_STATE=1
      shift
      ;;
    --json)
      JSON_OUTPUT=1
      shift
      ;;
    --write)
      WRITE=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unexpected argument: $1" >&2
      usage
      exit 1
      ;;
  esac
done

ROOT="$(cd "$ROOT" && pwd -P)"
FEATURE_HELPER="$ROOT/scripts/kernel-feature-enabled.sh"

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || {
    echo "Missing required command: $1" >&2
    exit 1
  }
}

emit_json() {
  local result="$1"
  local path="${2:-}"
  local reason="${3:-}"
  jq -n \
    --arg result "$result" \
    --arg path "$path" \
    --arg reason "$reason" \
    '{result:$result} + (if $path != "" then {ki_path:$path} else {} end) + (if $reason != "" then {reason:$reason} else {} end)'
}

require_cmd jq
require_cmd shasum
require_cmd python3

suggest_from_current_state() {
  python3 - "$ROOT" <<'PY'
import json
import pathlib
import re
import sys

root = pathlib.Path(sys.argv[1])
path = root / ".agent" / "current_state.json"
if not path.exists():
    print(json.dumps({
        "result": "SUGGESTION",
        "should_capture": False,
        "reason": "missing_current_state",
        "suggested_summary": "",
        "suggested_kind": "decision",
    }, ensure_ascii=False))
    raise SystemExit(0)

try:
    state = json.loads(path.read_text(encoding="utf-8"))
except json.JSONDecodeError:
    print(json.dumps({
        "result": "SUGGESTION",
        "should_capture": False,
        "reason": "invalid_current_state",
        "suggested_summary": "",
        "suggested_kind": "decision",
    }, ensure_ascii=False))
    raise SystemExit(0)

parts = []
for key in ["objective", "next_step", "verification_status"]:
    value = state.get(key)
    if isinstance(value, str):
        parts.append(value)
for item in state.get("last_completed_task", []):
    if isinstance(item, str):
        parts.append(item)
text = " ".join(parts)
text_lc = text.lower()

trivial_re = re.compile(r"\b(fast_local|micro|typo|copy edit|format|rename-only|minor|pequeñ[oa]|trivial)\b")
durable_re = re.compile(
    r"\b(v[0-9]+\.[0-9]+|architecture|architectural|contract|resolver|memory|kernel|portable|blueprints?|"
    r"doctor|run-core-evals|migration|incident|regression|api|schema|workflow|core script|plan gate|"
    r"arquitectura|contrato|memoria|n[uú]cleo|port[aá]til|migraci[oó]n|incidente|regresi[oó]n)\b",
    re.I,
)
verified = "pass:" in text_lc or "0 errores" in text_lc or "0 error(s)" in text_lc
durable = bool(durable_re.search(text))
trivial = bool(trivial_re.search(text))
should_capture = durable and verified and not (trivial and not durable)

if not text.strip():
    reason = "no_current_state_signal"
elif should_capture:
    reason = "durable_verified_change"
elif trivial:
    reason = "fast_local_or_trivial"
elif durable and not verified:
    reason = "durable_but_unverified"
else:
    reason = "no_durable_signal"

if re.search(r"\b(incident|regression|error|failure|bug|incidente|regresi[oó]n|fallo)\b", text, re.I):
    kind = "bug_resolution"
elif re.search(r"\b(api|schema|contract|contrato|esquema)\b", text, re.I):
    kind = "api_contract"
elif re.search(r"\b(test|smoke|eval|verification|validaci[oó]n)\b", text, re.I):
    kind = "test_insight"
elif re.search(r"\b(pattern|convention|policy|pol[ií]tica)\b", text, re.I):
    kind = "pattern"
else:
    kind = "decision"

summary = " ".join(text.split())
if len(summary) > 360:
    summary = summary[:357].rstrip() + "..."

print(json.dumps({
    "result": "SUGGESTION",
    "should_capture": should_capture,
    "reason": reason,
    "suggested_summary": summary if should_capture else "",
    "suggested_kind": kind,
}, ensure_ascii=False))
PY
}

if [[ -f "$FEATURE_HELPER" ]] && ! bash "$FEATURE_HELPER" memory_vault --root "$ROOT" >/dev/null 2>&1; then
  if (( SUGGEST_FROM_CURRENT_STATE == 1 )); then
    jq -n '{result:"SUGGESTION", should_capture:false, reason:"memory_vault=false", suggested_summary:"", suggested_kind:"decision"}'
    exit 0
  fi
  emit_json "SKIPPED_FEATURE_DISABLED" "" "memory_vault=false"
  exit 0
fi

if (( SUGGEST_FROM_CURRENT_STATE == 1 )); then
  SUGGESTION="$(suggest_from_current_state)"
  if (( WRITE != 1 )); then
    printf '%s\n' "$SUGGESTION"
    exit 0
  fi
  if ! jq -e '.should_capture == true and (.suggested_summary | length >= 30)' >/dev/null <<< "$SUGGESTION"; then
    printf '%s\n' "$SUGGESTION"
    exit 0
  fi
  SUMMARY="$(jq -r '.suggested_summary' <<< "$SUGGESTION")"
  if [[ "$KIND" == "auto" || -z "$KIND" ]]; then
    KIND="$(jq -r '.suggested_kind' <<< "$SUGGESTION")"
  fi
fi

if [[ -z "$SUMMARY" ]]; then
  emit_json "SKIPPED_NO_DURABLE_SIGNAL" "" "missing summary"
  exit 0
fi

if [[ "${#SUMMARY}" -lt 30 ]]; then
  emit_json "SKIPPED_NO_DURABLE_SIGNAL" "" "summary too short"
  exit 0
fi

slugify() {
  printf '%s' "$1" \
    | tr '[:upper:]' '[:lower:]' \
    | tr -cs 'a-z0-9' '-' \
    | sed -E 's/^-+//; s/-+$//; s/-{2,}/-/g' \
    | cut -c1-56
}

project_default_domain() {
  local name
  name="$(basename "$ROOT")"
  if [[ "$ROOT" == "$HOME/.gemini" || "$name" == ".gemini" ]]; then
    printf 'kernel\n'
  else
    name="$(slugify "$name")"
    [[ -n "$name" ]] || name="project"
    printf '%s\n' "$name"
  fi
}

derive_title() {
  python3 - "$SUMMARY" <<'PY'
import re
import sys

text = " ".join(sys.argv[1].split())
parts = re.split(r"(?<=[.!?])\s+", text, maxsplit=1)
title = parts[0].strip() if parts and parts[0].strip() else text
title = title[:72].rstrip(" ,;:-")
print(title or text[:72].strip())
PY
}

infer_kind() {
  local summary_lc
  summary_lc="$(printf '%s' "$SUMMARY" | tr '[:upper:]' '[:lower:]')"
  case "$summary_lc" in
    *bug*|*fix*|*incident*|*regression*|*error*|*failure*)
      printf 'bug_resolution\n'
      ;;
    *dependency*|*package*|*library*|*version*|*npm*|*pip*|*cargo*)
      printf 'dependency\n'
      ;;
    *config*|*setting*|*flag*|*env*|*variable*|*profile*)
      printf 'config\n'
      ;;
    *handoff*|*resume*|*context\ state*|*contexto*)
      printf 'handoff\n'
      ;;
    *audit*|*review*|*finding*|*hallazgo*)
      printf 'audit\n'
      ;;
    *research*|*investigation*|*compare*|*evaluat*|*benchmark*)
      printf 'research\n'
      ;;
    *pattern*|*convention*|*best\ practice*)
      printf 'pattern\n'
      ;;
    *api*|*contract*|*schema*)
      printf 'api_contract\n'
      ;;
    *)
      printf 'decision\n'
      ;;
  esac
}

category_for_kind() {
  case "$1" in
    decision|pattern|api_contract|schema_migration)
      printf 'architecture\n'
      ;;
    bug_resolution|test_insight|debug_dead_end)
      printf 'incidents\n'
      ;;
    dependency|config)
      printf 'ecosystem\n'
      ;;
    research|skill_insight|conclusion|audit)
      printf 'research\n'
      ;;
    context_state|handoff)
      printf 'context\n'
      ;;
    *)
      echo "Unsupported KI kind: $1" >&2
      exit 1
      ;;
  esac
}

array_json() {
  local input="$1"
  if [[ -z "$input" ]]; then
    jq -cn '[]'
    return 0
  fi
  if jq -e 'type == "array"' >/dev/null 2>&1 <<< "$input"; then
    jq -c '[.[] | tostring]' <<< "$input"
  else
    printf '%s' "$input" | jq -R -c 'split(",") | map(gsub("^\\s+|\\s+$"; "")) | map(select(length > 0))'
  fi
}

infer_entities_json() {
  python3 - "$SUMMARY" <<'PY'
import json
import re
import sys

text = sys.argv[1]
candidates = []
for value in re.findall(r"`([^`]+)`", text):
    cleaned = value.strip()
    if cleaned:
        candidates.append(cleaned)
for value in re.findall(r"\b[A-Z][A-Za-z0-9._/-]{2,}\b", text):
    cleaned = value.strip()
    if cleaned and cleaned.lower() not in {"this", "that"}:
        candidates.append(cleaned)
seen = []
for item in candidates:
    if item not in seen:
        seen.append(item)
print(json.dumps(seen[:6], ensure_ascii=False))
PY
}

yaml_array() {
  jq -r '[.[] | @json] | "[" + join(", ") + "]"'
}

if [[ "$KIND" == "auto" || -z "$KIND" ]]; then
  KIND="$(infer_kind)"
fi
[[ -n "$TITLE" ]] || TITLE="$(derive_title)"
[[ -n "$TENANT_DOMAIN" ]] || TENANT_DOMAIN="$(project_default_domain)"

CATEGORY="$(category_for_kind "$KIND")"
if [[ -n "$ENTITIES_INPUT" ]]; then
  ENTITIES_JSON="$(array_json "$ENTITIES_INPUT")"
else
  ENTITIES_JSON="$(infer_entities_json)"
fi
RELATED_JSON="$(array_json "$RELATED_INPUT")"
DAY="$(date -u +"%Y-%m-%d")"
EPOCH="$(date -u +%s)"
SLUG="$(slugify "$TITLE")"
[[ -n "$SLUG" ]] || SLUG="$(slugify "$KIND-$TENANT_DOMAIN")"
REL_PATH=".agent/knowledge/$CATEGORY/${DAY}_${SLUG}.md"
ABS_PATH="$ROOT/$REL_PATH"
KI_ID="$(printf '%s' "$ROOT|$KIND|$TENANT_DOMAIN|$TITLE|$SUMMARY|$EPOCH" | shasum -a 256 | awk '{print $1}' | cut -c1-32)"
ENTITIES_YAML="$(yaml_array <<< "$ENTITIES_JSON")"
RELATED_YAML="$(yaml_array <<< "$RELATED_JSON")"

if (( WRITE != 1 )); then
  emit_json "DRY_RUN" "$REL_PATH" "pass --write to persist"
  exit 0
fi

mkdir -p "$(dirname "$ABS_PATH")"
TMP_PATH="$(mktemp "$ROOT/.agent/knowledge/$CATEGORY/.capture-ki.XXXXXX")"
cat > "$TMP_PATH" <<EOF
---
ki_id: "$KI_ID"
category: "$CATEGORY"
kind: "$KIND"
status: "active"
timestamp: $EPOCH
tenant_domain: "$TENANT_DOMAIN"
entities: $ENTITIES_YAML
related_kis: $RELATED_YAML
---
# $TITLE

## Summary
$SUMMARY

## Source
- workflow: ${SOURCE_WORKFLOW:-manual}
EOF
mv "$TMP_PATH" "$ABS_PATH"

if [[ -f "$FEATURE_HELPER" ]] && bash "$FEATURE_HELPER" telemetry_tooling --root "$ROOT" >/dev/null 2>&1; then
  printf '[%s] KNOWLEDGE_CAPTURE: %s - %s\n' "$(date -u +"%Y-%m-%dT%H:%M:%SZ")" "$KIND" "$SLUG" >> "$ROOT/.agent/knowledge/.wal_journal"
fi

emit_json "CREATED" "$REL_PATH"
