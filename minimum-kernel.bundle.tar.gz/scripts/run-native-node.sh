#!/usr/bin/env bash
set -euo pipefail

PRINT_ONLY=0
if [[ "${1:-}" == "--print" ]]; then
  PRINT_ONLY=1
  shift
fi

case "$(uname -s)" in
  Darwin) EXPECTED_PLATFORM="darwin" ;;
  Linux) EXPECTED_PLATFORM="linux" ;;
  *) EXPECTED_PLATFORM="" ;;
esac

candidate_matches_host() {
  local candidate="$1"
  [[ -x "$candidate" ]] || return 1

  if command -v file >/dev/null 2>&1; then
    local description
    description="$(file -L -b "$candidate" 2>/dev/null || true)"
    case "$EXPECTED_PLATFORM" in
      darwin) [[ "$description" == *"Mach-O"* ]] || return 1 ;;
      linux) [[ "$description" == *"ELF"* ]] || return 1 ;;
    esac
  fi

  if [[ -n "$EXPECTED_PLATFORM" ]]; then
    [[ "$("$candidate" -p 'process.platform' 2>/dev/null || true)" == "$EXPECTED_PLATFORM" ]] || return 1
  else
    "$candidate" --version >/dev/null 2>&1 || return 1
  fi
}

if [[ -n "${GEMINI_NODE_BIN:-}" ]]; then
  if ! candidate_matches_host "$GEMINI_NODE_BIN"; then
    printf 'ERROR: GEMINI_NODE_BIN is not an executable Node binary for this host: %s\n' "$GEMINI_NODE_BIN" >&2
    exit 1
  fi
  NODE_BIN="$GEMINI_NODE_BIN"
else
  NODE_BIN=""
  candidates=()
  [[ -n "${NVM_BIN:-}" ]] && candidates+=("$NVM_BIN/node")
  candidates+=("/usr/local/bin/node" "/opt/homebrew/bin/node")

  for candidate in "$HOME"/.nvm/versions/node/*/bin/node; do
    [[ -e "$candidate" ]] && candidates+=("$candidate")
  done

  ambient_node="$(command -v node 2>/dev/null || true)"
  [[ -n "$ambient_node" ]] && candidates+=("$ambient_node")

  for candidate in "${candidates[@]}"; do
    if candidate_matches_host "$candidate"; then
      NODE_BIN="$candidate"
      break
    fi
  done

  if [[ -z "$NODE_BIN" ]]; then
    printf 'ERROR: No host-native Node executable was found. Set GEMINI_NODE_BIN to an approved Node binary.\n' >&2
    exit 1
  fi
fi

if (( PRINT_ONLY == 1 )); then
  printf '%s\n' "$NODE_BIN"
  exit 0
fi

if (( $# == 0 )); then
  printf 'Usage: run-native-node.sh [--print] <javascript-entrypoint> [args...]\n' >&2
  exit 2
fi

exec "$NODE_BIN" "$@"
