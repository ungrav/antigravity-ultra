#!/usr/bin/env python3
"""Incremental, provider-neutral project context index and bounded resolver."""

from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
from typing import Any


TOKEN_RE = re.compile(r"[\w.-]+", re.UNICODE)


def utc_iso(epoch: float | None = None) -> str:
    value = time.time() if epoch is None else epoch
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(value))


def read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return default


def write_json_private(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(f"{path.name}.{os.getpid()}.tmp")
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8")
    os.chmod(temp, 0o600)
    temp.replace(path)
    os.chmod(path, 0o600)


def load_policy(kernel_root: Path, explicit: str | None) -> dict[str, Any]:
    path = Path(explicit).expanduser().resolve() if explicit else kernel_root / "config/project-context-policy.json"
    policy = read_json(path, None)
    if not isinstance(policy, dict):
        raise SystemExit(f"Invalid project context policy: {path}")
    return policy


def apply_local_overrides(project_root: Path, policy: dict[str, Any]) -> dict[str, Any]:
    merged = json.loads(json.dumps(policy))
    override_path = project_root / str(policy.get("local_override_path", ".kernel/project-context-overrides.local.json"))
    overrides = read_json(override_path, {})
    if not isinstance(overrides, dict):
        return merged
    for key in ("exclude_directories", "exclude_names", "exclude_suffixes", "exclude_relative_prefixes"):
        additions = overrides.get(key, [])
        if isinstance(additions, list):
            merged[key] = sorted(set(merged.get(key, [])) | {str(item) for item in additions})
    for key in ("max_file_bytes", "max_index_files", "graphify_min_files", "refresh_ttl_seconds"):
        if key in overrides and isinstance(overrides[key], int):
            merged[key] = overrides[key]
    return merged


def state_path(project_root: Path, policy: dict[str, Any], explicit: str | None) -> Path:
    if explicit:
        return Path(explicit).expanduser().resolve()
    return project_root / str(policy.get("state_path", ".kernel/project-context.local.json"))


def normalized_tokens(value: str) -> set[str]:
    return {token.casefold() for token in TOKEN_RE.findall(value) if len(token) > 1}


def is_secret_name(name: str, policy: dict[str, Any]) -> bool:
    folded = name.casefold()
    excluded = {item.casefold() for item in policy.get("exclude_names", [])}
    if folded in excluded or folded.startswith(".env."):
        return True
    return any(part in folded for part in ("credential", "secret", "private_key", "auth_token", "api_key"))


def eligible(path: Path, relative: str, policy: dict[str, Any]) -> bool:
    if any(relative.startswith(prefix) for prefix in policy.get("exclude_relative_prefixes", [])):
        return False
    if path.is_symlink() or not path.is_file() or is_secret_name(path.name, policy):
        return False
    suffix = path.suffix.casefold()
    if suffix in {item.casefold() for item in policy.get("exclude_suffixes", [])}:
        return False
    if suffix:
        return suffix in {item.casefold() for item in policy.get("text_extensions", [])}
    return path.name in set(policy.get("allowed_extensionless", []))


def fingerprint(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def language_bucket(path: Path) -> str:
    suffix = path.suffix.casefold().lstrip(".")
    return suffix or path.name.casefold()


def complexity_profile(file_count: int, thresholds: dict[str, Any]) -> str:
    if file_count <= int(thresholds.get("tiny", 80)):
        return "tiny"
    if file_count <= int(thresholds.get("small", 500)):
        return "small"
    if file_count <= int(thresholds.get("medium", 2000)):
        return "medium"
    return "large"


def walk_candidates(project_root: Path, policy: dict[str, Any]):
    excluded_dirs = set(policy.get("exclude_directories", []))
    max_bytes = int(policy.get("max_file_bytes", 1048576))
    max_files = int(policy.get("max_index_files", 25000))
    count = 0
    for current, directories, files in os.walk(project_root, topdown=True, followlinks=False):
        directories[:] = sorted(item for item in directories if item not in excluded_dirs and not (Path(current) / item).is_symlink())
        for name in sorted(files):
            path = Path(current) / name
            relative = path.relative_to(project_root).as_posix()
            try:
                size = path.stat().st_size
            except OSError:
                continue
            if size > max_bytes or not eligible(path, relative, policy):
                continue
            yield path, relative, size
            count += 1
            if count >= max_files:
                return


def scan(project_root: Path, kernel_root: Path, policy: dict[str, Any], output: Path) -> dict[str, Any]:
    previous = read_json(output, {})
    old_files = previous.get("files", {}) if previous.get("policy_version") == policy.get("version") else {}
    files: dict[str, Any] = {}
    hashed = 0
    reused = 0
    total_bytes = 0
    directories: set[str] = set()
    languages: Counter[str] = Counter()
    manifests = 0
    manifest_names = set(policy.get("always_read_candidates", []))
    for path, relative, size in walk_candidates(project_root, policy):
        info = path.stat()
        cached = old_files.get(relative, {})
        unchanged = cached.get("size") == size and cached.get("mtime_ns") == info.st_mtime_ns and cached.get("fingerprint")
        digest = str(cached["fingerprint"]) if unchanged else fingerprint(path)
        hashed += 0 if unchanged else 1
        reused += 1 if unchanged else 0
        bucket = language_bucket(path)
        entry = {
            "size": size,
            "mtime_ns": info.st_mtime_ns,
            "fingerprint": digest,
            "language": bucket,
            "depth": relative.count("/"),
            "manifest": relative in manifest_names or path.name in manifest_names,
        }
        files[relative] = entry
        total_bytes += size
        directories.add(str(Path(relative).parent))
        languages[bucket] += 1
        manifests += int(entry["manifest"])
    removed = len(set(old_files) - set(files))
    profile = complexity_profile(len(files), policy.get("complexity_thresholds", {}))
    now = time.time()
    state = {
        "version": 1,
        "policy_version": policy.get("version", 1),
        "kind": "project_context_local",
        "project_root": str(project_root),
        "generated_at": utc_iso(now),
        "generated_at_epoch": int(now),
        "complexity": {
            "profile": profile,
            "file_count": len(files),
            "directory_count": len(directories),
            "total_indexed_bytes": total_bytes,
            "manifest_count": manifests,
            "language_counts": dict(languages.most_common()),
        },
        "last_scan": {"hashed": hashed, "reused": reused, "removed": removed},
        "files": files,
    }
    write_json_private(output, state)
    return state


def git_changed(project_root: Path) -> list[str]:
    result = subprocess.run(
        ["git", "-C", str(project_root), "status", "--porcelain=v1", "-z", "--untracked-files=all"],
        capture_output=True,
    )
    if result.returncode != 0:
        return []
    changed: set[str] = set()
    fields = [item for item in result.stdout.split(b"\0") if item]
    index = 0
    while index < len(fields):
        text = fields[index].decode("utf-8", "surrogateescape")
        path = text[3:] if len(text) >= 4 else ""
        if " -> " in path:
            path = path.split(" -> ", 1)[1]
        if path:
            changed.add(path)
        if text[:1] in {"R", "C"} and index + 1 < len(fields):
            index += 1
            changed.add(fields[index].decode("utf-8", "surrogateescape"))
        index += 1
    return sorted(changed)


def ensure_state(project_root: Path, kernel_root: Path, policy: dict[str, Any], output: Path, refresh: bool) -> tuple[dict[str, Any], str]:
    state = read_json(output, {})
    now = int(time.time())
    ttl = int(policy.get("refresh_ttl_seconds", 300))
    stale = not state or now - int(state.get("generated_at_epoch", 0)) >= ttl
    if refresh or stale:
        return scan(project_root, kernel_root, policy, output), "refreshed"
    return state, "cached"


def resolve_plan(project_root: Path, state: dict[str, Any], policy: dict[str, Any], task: str, freshness: str) -> dict[str, Any]:
    files = state.get("files", {})
    profile = state.get("complexity", {}).get("profile", "small")
    budget = policy.get("budgets", {}).get(profile, policy.get("budgets", {}).get("small", {"max_files": 16, "max_bytes": 393216}))
    max_files = int(budget.get("max_files", 16))
    max_bytes = int(budget.get("max_bytes", 393216))
    task_tokens = normalized_tokens(task)
    changed = [path for path in git_changed(project_root) if path in files]
    changed_set = set(changed)
    always_candidates = policy.get("always_read_candidates", [])
    always = [path for path in always_candidates if path in files]
    scores: list[tuple[int, str, list[str]]] = []
    for relative, entry in files.items():
        score = 0
        reasons: list[str] = []
        if relative in always:
            score += 1000
            reasons.append("project authority/current state/manifest")
        if relative in changed_set:
            score += 900
            reasons.append("git changed")
        path_tokens = normalized_tokens(relative.replace("/", " "))
        overlap = sorted(task_tokens & path_tokens)
        if overlap:
            score += 150 * len(overlap)
            reasons.append("task terms: " + ", ".join(overlap[:5]))
        if entry.get("manifest") and Path(relative).parent == Path("."):
            score += 300
            reasons.append("top-level manifest")
        if score > 0:
            score -= int(entry.get("depth", 0))
            scores.append((score, relative, reasons))
    scores.sort(key=lambda item: (-item[0], item[1]))
    selected: list[dict[str, Any]] = []
    selected_bytes = 0
    for score, relative, reasons in scores:
        size = int(files[relative].get("size", 0))
        if len(selected) >= max_files or (selected and selected_bytes + size > max_bytes):
            continue
        selected.append({"path": relative, "size": size, "score": score, "reasons": reasons})
        selected_bytes += size
    folded_task = task.casefold()
    memory = any(term.casefold() in folded_task for term in policy.get("memory_task_terms", []))
    graph_task = any(term.casefold() in folded_task for term in policy.get("graphify_task_terms", []))
    graphify = graph_task and int(state.get("complexity", {}).get("file_count", 0)) >= int(policy.get("graphify_min_files", 500))
    return {
        "version": 1,
        "kind": "project_context_plan",
        "project_root": str(project_root),
        "task": task,
        "index_freshness": freshness,
        "index_generated_at": state.get("generated_at"),
        "scan_summary": state.get("last_scan", {}),
        "complexity": state.get("complexity", {}),
        "budget": {"max_files": max_files, "max_bytes": max_bytes},
        "always_read": always,
        "changed_files": changed,
        "target_files": selected,
        "estimated_context_bytes": selected_bytes,
        "memory_recommended": memory,
        "graphify_recommended": graphify,
        "fallback": "Read target_files only; use the project manual read table if the resolver is unavailable.",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("scan", "resolve", "status"))
    parser.add_argument("--kernel-root", default=str(Path(__file__).resolve().parents[1]))
    parser.add_argument("--project-root", default=".")
    parser.add_argument("--policy")
    parser.add_argument("--state")
    parser.add_argument("--task", default="")
    parser.add_argument("--refresh", action="store_true")
    args = parser.parse_args()
    kernel_root = Path(args.kernel_root).expanduser().resolve()
    project_root = Path(args.project_root).expanduser().resolve()
    policy = apply_local_overrides(project_root, load_policy(kernel_root, args.policy))
    output = state_path(project_root, policy, args.state)
    if args.command == "scan":
        state = scan(project_root, kernel_root, policy, output)
        print(json.dumps({key: state[key] for key in ("version", "kind", "project_root", "generated_at", "complexity", "last_scan")}, indent=2, ensure_ascii=False))
        return 0
    if args.command == "status":
        state = read_json(output, {})
        if not state:
            print(json.dumps({"status": "missing", "state_path": str(output)}, indent=2))
            return 1
        print(json.dumps({"status": "available", "state_path": str(output), "generated_at": state.get("generated_at"), "complexity": state.get("complexity"), "last_scan": state.get("last_scan")}, indent=2, ensure_ascii=False))
        return 0
    if not args.task.strip():
        parser.error("resolve requires --task")
    state, freshness = ensure_state(project_root, kernel_root, policy, output, args.refresh)
    print(json.dumps(resolve_plan(project_root, state, policy, args.task, freshness), indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
