#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-$HOME/.gemini}"
MODE="--check"

if [[ "${1:-}" == "--root" ]]; then
  ROOT="$2"
  shift 2
fi

while [[ $# -gt 0 ]]; do
  case "$1" in
    --root)
      ROOT="$2"
      shift 2
      ;;
    --check|--write|--print)
      MODE="$1"
      shift
      ;;
    -h|--help)
      cat <<'EOF'
Usage:
  render-current-state-md.sh [--root PATH] [--check|--write|--print]

Description:
  Renders the agent-readable .agent/current_state.md live handoff from
  .agent/current_state.json. If only legacy Markdown frontmatter exists,
  imports it once into current_state.json before rendering.
EOF
      exit 0
      ;;
    *)
      if [[ "$1" != --* && "$ROOT" == "$HOME/.gemini" ]]; then
        ROOT="$1"
        shift
      else
        echo "Unexpected argument: $1" >&2
        exit 1
      fi
      ;;
  esac
done

python3 - "$ROOT" "$MODE" <<'PY'
import json
import pathlib
import sys


root = pathlib.Path(sys.argv[1]).expanduser().resolve()
mode = sys.argv[2]
json_path = root / ".agent" / "current_state.json"
md_path = root / ".agent" / "current_state.md"


def fail(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


def load_legacy_frontmatter(path: pathlib.Path) -> dict:
    if not path.exists():
        fail(f"Missing {json_path}")
    lines = path.read_text(encoding="utf-8").splitlines()
    if len(lines) < 3 or lines[0].strip() != "---":
        fail(f"Missing {json_path}")
    end = None
    for idx, line in enumerate(lines[1:], start=1):
        if line.strip() == "---":
            end = idx
            break
    if end is None:
        fail(".agent/current_state.md legacy frontmatter is not closed")
    raw = "\n".join(lines[1:end]).strip()
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        fail(f".agent/current_state.md legacy frontmatter is not valid JSON: {exc}")


def load_current_state() -> dict:
    if json_path.exists():
        try:
            return json.loads(json_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            fail(f".agent/current_state.json is not valid JSON: {exc}")
    meta = load_legacy_frontmatter(md_path)
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return meta


def expect_type(meta: dict, key: str, expected: str) -> None:
    if key not in meta:
        fail(f"current_state missing key: {key}")
    value = meta[key]
    if expected == "array":
        ok = isinstance(value, list) and all(isinstance(item, str) for item in value)
    elif expected == "string":
        ok = isinstance(value, str) and len(value) > 0
    elif expected == "object":
        ok = isinstance(value, dict)
    elif expected == "integer":
        ok = isinstance(value, int)
    else:
        ok = False
    if not ok:
        fail(f"current_state key has wrong type: {key}")


def validate_meta(meta: dict) -> None:
    for key, expected in {
        "schema_version": "integer",
        "project": "string",
        "updated_at": "string",
        "objective": "string",
        "last_completed_task": "array",
        "status": "string",
        "blockers": "array",
        "active_files": "array",
        "resume_commands": "array",
        "next_step": "string",
        "verification_status": "string",
        "freshness_state": "string",
        "plan_state": "object",
    }.items():
        expect_type(meta, key, expected)
    plan_state = meta["plan_state"]
    for key in [
        "required",
        "source",
        "status",
        "updated_at",
        "content_hash",
        "memory_synced",
        "next_action",
        "producer_agent",
        "receipt_ref",
    ]:
        if key not in plan_state:
            fail(f"current_state.plan_state missing key: {key}")
    if not isinstance(plan_state["required"], bool):
        fail("current_state.plan_state.required must be boolean")
    if not isinstance(plan_state["memory_synced"], bool):
        fail("current_state.plan_state.memory_synced must be boolean")


def chunk_inline(items: list[str], prefix: str = "- ", sep: str = ", ", width: int = 110) -> list[str]:
    if not items:
        return [f"{prefix}Ninguno."]
    lines: list[str] = []
    current = prefix
    for item in items:
        candidate = item if current == prefix else f"{sep}{item}"
        if current != prefix and len(current) + len(candidate) > width:
            lines.append(current)
            current = prefix + item
        else:
            current += candidate
    lines.append(current)
    return lines


def quoted(items: list[str]) -> list[str]:
    return [f"`{item}`" for item in items]


def render_features(meta: dict) -> list[str]:
    kernel_install = meta.get("kernel_install")
    if not isinstance(kernel_install, dict):
        return []
    ordered = []
    for key in ["platform", "launcher_used", "install_tier", "language", "first_user_intent_summary"]:
        value = kernel_install.get(key)
        if value not in (None, ""):
            ordered.append(f"{key}: {value}")
    features = kernel_install.get("features")
    if isinstance(features, dict):
        for key in sorted(features):
            ordered.append(f"{key}: {features[key]}")
    if not ordered:
        return []
    return ["## Active Kernel Features", *chunk_inline(ordered, sep="; ", width=120), ""]


def render_markdown(meta: dict) -> str:
    blockers = meta["blockers"] if meta["blockers"] else ["Ninguno."]
    last_completed = meta["last_completed_task"] if meta["last_completed_task"] else ["Ninguna."]
    lines = [
        "# Current State",
        "",
        "## Current Objective",
        f"- {meta['objective']}",
        "",
        "## Last Completed Task",
        *chunk_inline(last_completed, sep="; ", width=120),
        "",
        "## Blockers",
        *chunk_inline(blockers, sep="; ", width=120),
        "",
        "## Active Files",
        *chunk_inline(quoted(meta["active_files"])),
        "",
        "## Resume Commands",
        *chunk_inline(quoted(meta["resume_commands"]), sep="; ", width=140),
        "",
        *render_features(meta),
        "## Next Step",
        f"- {meta['next_step']}",
        "",
        "## Verification Status",
        f"- `{meta['verification_status']}`",
        "",
        "## Freshness",
        f"- `{meta['freshness_state']}` al `{meta['updated_at']}`.",
    ]
    return "\n".join(lines).rstrip() + "\n"


meta = load_current_state()
validate_meta(meta)
rendered = render_markdown(meta)

if mode == "--print":
    print(rendered, end="")
elif mode == "--write":
    md_path.parent.mkdir(parents=True, exist_ok=True)
    md_path.write_text(rendered, encoding="utf-8")
    print("CURRENT_STATE_MD_WRITTEN")
elif mode == "--check":
    if not md_path.exists():
        fail(".agent/current_state.md is missing")
    current = md_path.read_text(encoding="utf-8")
    if current != rendered:
        fail(".agent/current_state.md drifted from .agent/current_state.json")
    print("CURRENT_STATE_MD_IN_SYNC")
else:
    fail(f"Unknown mode: {mode}")
PY
