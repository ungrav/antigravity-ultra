#!/usr/bin/env python3
"""Kernel control helpers for Antigravity runtime state.

The first supported surface is the implementation-plan event lifecycle. Bash
entrypoints remain as compatibility wrappers, while this module owns the state
transition logic and structured JSON/file updates.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


VALID_EVENTS = {
    "plan_required_resolved",
    "plan_drafted",
    "plan_presented",
    "plan_approved",
    "plan_superseded",
    "plan_audit_completed",
    "plan_reset",
}
VALID_NEXT_ACTIONS = {
    "present_for_approval",
    "wait_for_user_approval",
    "implementation_unblocked",
    "draft_replacement_plan",
}
VALID_PRODUCERS = {"antigravity_native", "codex", "gemini", "claude", "other"}
VALID_APPROVAL_SOURCES = {
    "host_ui_button",
    "host_ui_command",
    "chat_structured_command",
    "manual_script",
}


class KernelError(RuntimeError):
    def __init__(self, message: str, trace_result: str | None = None):
        super().__init__(message)
        self.trace_result = trace_result


def canonical_dir(path: str | Path) -> Path:
    return Path(path).expanduser().resolve()


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)


def _load_legacy_current_state(path: Path) -> dict[str, Any]:
    lines = path.read_text(encoding="utf-8").splitlines()
    if len(lines) < 3 or lines[0].strip() != "---":
        raise KernelError("Missing .agent/current_state.json")
    end = None
    for idx, line in enumerate(lines[1:], start=1):
        if line.strip() == "---":
            end = idx
            break
    if end is None:
        raise KernelError(".agent/current_state.md legacy frontmatter is not closed")
    meta = json.loads("\n".join(lines[1:end]).strip())
    if not isinstance(meta.get("plan_state"), dict):
        raise KernelError(".agent/current_state.md legacy frontmatter is missing plan_state")
    return meta


def parse_current_state(json_path: Path, md_path: Path) -> dict[str, Any]:
    if json_path.exists():
        meta = load_json(json_path)
    elif md_path.exists():
        meta = _load_legacy_current_state(md_path)
        write_json(json_path, meta)
    else:
        raise KernelError(f"Missing required path: {json_path}")
    if not isinstance(meta.get("plan_state"), dict):
        raise KernelError(".agent/current_state.json is missing plan_state")
    return meta


def write_current_state(path: Path, meta: dict[str, Any]) -> None:
    write_json(path, meta)


def script_dir() -> Path:
    return Path(__file__).resolve().parent


def ensure_paths(root: Path) -> dict[str, Path]:
    renderer = root / "scripts" / "render-project-state-cache.sh"
    if not renderer.exists():
        renderer = script_dir() / "render-project-state-cache.sh"
    current_state_renderer = root / "scripts" / "render-current-state-md.sh"
    if not current_state_renderer.exists():
        current_state_renderer = script_dir() / "render-current-state-md.sh"
    paths = {
        "schema": root / "state" / "plan-event.schema.json",
        "current_state": root / ".agent" / "current_state.json",
        "current_state_md": root / ".agent" / "current_state.md",
        "run_state": root / "state" / "run_state.json",
        "renderer": renderer,
        "current_state_renderer": current_state_renderer,
        "trace": root / "state" / "traces" / "observability.jsonl",
        "journal": root / "state" / "plan-events" / "journal.jsonl",
    }
    optional_names = {"journal.jsonl", "observability.jsonl"}
    missing = []
    for key, path in paths.items():
        if key == "current_state" and not path.exists() and paths["current_state_md"].exists():
            continue
        if not path.exists() and path.name not in optional_names:
            missing.append(str(path))
    if missing:
        raise KernelError(f"Missing required path: {missing[0]}")
    return paths


def parse_iso(value: str) -> datetime:
    raw = value[:-1] + "+00:00" if value.endswith("Z") else value
    dt = datetime.fromisoformat(raw)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def iso_day(value: str) -> str:
    return parse_iso(value).strftime("%Y-%m-%d")


def iso_clock(value: str) -> str:
    return parse_iso(value).strftime("%H%M%S")


def iso_epoch(value: str) -> int:
    return int(parse_iso(value).timestamp())


def slugify(value: str, limit: int = 48) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    slug = re.sub(r"-{2,}", "-", slug)
    return slug[:limit].strip("-")


def json_to_markdown_list(value: Any) -> str:
    if value is None:
        items = ["No especificado."]
    elif isinstance(value, list):
        items = [str(item) for item in value] or ["No especificado."]
    else:
        items = [str(value)]
    return "\n".join(f"- {item}" for item in items)


def derive_producer_agent(source_host: str) -> str:
    mapping = {
        "antigravity_internal": "antigravity_native",
        "codex_internal": "codex",
        "codex_ephemeral": "codex",
        "gemini_internal": "gemini",
        "gemini_ephemeral": "gemini",
        "claude_internal": "claude",
        "claude_ephemeral": "claude",
    }
    return mapping.get(source_host, "other")


def sha256_short(seed: str) -> str:
    return hashlib.sha256(seed.encode("utf-8")).hexdigest()[:32]


def validate_event(event: dict[str, Any]) -> None:
    if not isinstance(event, dict):
        raise KernelError("Event payload must be a JSON object.")
    for key in ["schema_version", "event_id", "event_name", "source_host", "project_root", "timestamp"]:
        if key not in event:
            raise KernelError("Event payload violates the plan-event contract.")
    if event["schema_version"] not in {1, 2, 3}:
        raise KernelError("Event payload violates the plan-event contract.")
    if not isinstance(event["event_id"], str) or not event["event_id"]:
        raise KernelError("Event payload violates the plan-event contract.")
    if event["event_name"] not in VALID_EVENTS:
        raise KernelError("Event payload violates the plan-event contract.")
    if not isinstance(event["source_host"], str) or not event["source_host"]:
        raise KernelError("Event payload violates the plan-event contract.")
    if not isinstance(event["project_root"], str) or not event["project_root"]:
        raise KernelError("Event payload violates the plan-event contract.")
    if not isinstance(event["timestamp"], str) or not event["timestamp"]:
        raise KernelError("Event payload violates the plan-event contract.")
    parse_iso(event["timestamp"])

    if "required" in event and not isinstance(event["required"], bool):
        raise KernelError("Event payload violates the plan-event contract.")
    if event.get("content_hash") is not None and (
        not isinstance(event.get("content_hash"), str) or not event["content_hash"]
    ):
        raise KernelError("Event payload violates the plan-event contract.")
    if event.get("next_action") is not None and event["next_action"] not in VALID_NEXT_ACTIONS:
        raise KernelError("Event payload violates the plan-event contract.")
    if event.get("origin_workflow") is not None and (
        not isinstance(event["origin_workflow"], str) or not event["origin_workflow"]
    ):
        raise KernelError("Event payload violates the plan-event contract.")
    if event.get("supersede_active_plan") is not None and not isinstance(
        event["supersede_active_plan"], bool
    ):
        raise KernelError("Event payload violates the plan-event contract.")
    if event.get("durable_capture") is not None and not isinstance(event["durable_capture"], dict):
        raise KernelError("Event payload violates the plan-event contract.")

    if event["schema_version"] >= 2:
        if event.get("producer_agent") not in VALID_PRODUCERS:
            raise KernelError("Event payload violates the plan-event contract.")
        approval = event.get("approval_source")
        if approval is not None and approval not in VALID_APPROVAL_SOURCES:
            raise KernelError("Event payload violates the plan-event contract.")

    event_name = event["event_name"]
    if event_name == "plan_required_resolved" and not isinstance(event.get("required"), bool):
        raise KernelError("plan_required_resolved requires boolean field 'required'.")
    if event_name in {
        "plan_drafted",
        "plan_presented",
        "plan_approved",
        "plan_superseded",
        "plan_audit_completed",
    } and not event.get("content_hash"):
        raise KernelError(f"{event_name} requires a non-empty content_hash.")

    capture = event.get("durable_capture")
    if event_name == "plan_approved":
        if event["schema_version"] >= 2 and not event.get("approval_source"):
            raise KernelError("plan_approved requires non-null approval_source in schema_version 2+.")
        if not isinstance(capture, dict):
            raise KernelError(
                "plan_approved requires durable_capture with tenant_domain, summary, alternatives, validation, and risks."
            )
        for key in ["tenant_domain", "summary", "alternatives", "validation", "risks"]:
            if key not in capture or capture[key] in (None, ""):
                raise KernelError(
                    "plan_approved requires durable_capture with tenant_domain, summary, alternatives, validation, and risks."
                )
        if event["schema_version"] == 3:
            receipt = capture.get("receipt")
            if not isinstance(receipt, dict):
                raise KernelError("schema_version 3 plan_approved requires durable_capture.receipt.")
            for key in [
                "objective",
                "affected_surfaces",
                "impacted_files",
                "approved_phases",
                "validation_commands",
                "rollback",
                "constraints",
            ]:
                if key not in receipt:
                    raise KernelError("schema_version 3 plan_approved requires durable_capture.receipt.")
            if not isinstance(receipt["objective"], str) or not receipt["objective"]:
                raise KernelError("schema_version 3 plan_approved requires durable_capture.receipt.")
            for key in ["affected_surfaces", "impacted_files", "approved_phases", "validation_commands", "constraints"]:
                if not isinstance(receipt[key], list):
                    raise KernelError("schema_version 3 plan_approved requires durable_capture.receipt.")
            if not isinstance(receipt["rollback"], str) or not receipt["rollback"]:
                raise KernelError("schema_version 3 plan_approved requires durable_capture.receipt.")
    elif event_name == "plan_audit_completed":
        if not isinstance(capture, dict) or not capture.get("tenant_domain") or not capture.get("summary") or "findings" not in capture:
            raise KernelError("plan_audit_completed requires durable_capture with tenant_domain, summary, and findings.")
    elif event_name == "plan_superseded":
        if not isinstance(capture, dict) or not capture.get("summary"):
            raise KernelError("plan_superseded requires durable_capture.summary.")


def journal_has_event(path: Path, event_id: str) -> bool:
    if not path.exists():
        return False
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            if json.loads(line).get("event_id") == event_id:
                return True
        except json.JSONDecodeError:
            if f'"event_id":"{event_id}"' in line or f'"event_id": "{event_id}"' in line:
                return True
    return False


def append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n")


def emit_plan_trace(
    trace_file: Path,
    event: dict[str, Any],
    producer_agent: str,
    approval_source: str | None,
    status: str,
    transition_result: str,
    ki_path: str,
    no_op: bool,
    origin_workflow: str,
) -> None:
    metadata = {
        "event_name": event["event_name"],
        "source_host": event["source_host"],
        "producer_agent": producer_agent,
        "transition_result": transition_result,
        "no_op": no_op,
    }
    if approval_source:
        metadata["approval_source"] = approval_source
    if ki_path:
        metadata["ki_path"] = ki_path
    payload = {
        "schema_version": 2,
        "run_id": event["event_id"],
        "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "phase": "plan-state-sync",
        "event_type": "phase",
        "actor": "plan_event_ingestor",
        "status": status if status in {"started", "passed", "failed", "blocked", "confirm_required"} else "passed",
        "workflows": [origin_workflow],
        "checks": ["plan-event-schema", "plan-state-transition", "plan-memory-sync"],
        "notes": [event["event_name"]],
        "metadata": metadata,
    }
    append_jsonl(trace_file, payload)


def reset_plan_runtime_fields(timestamp: str) -> dict[str, Any]:
    return {
        "required": False,
        "source": "none",
        "status": "not_required",
        "updated_at": timestamp,
        "content_hash": None,
        "memory_synced": True,
        "next_action": None,
        "producer_agent": None,
        "receipt_ref": None,
    }


def ensure_next_action_matches(event: dict[str, Any], expected: str | None) -> None:
    if "next_action" in event and event.get("next_action") is not None:
        if event["next_action"] != expected:
            raise KernelError(
                f"Event next_action '{event['next_action']}' does not match canonical transition '{expected or ''}'.",
                "rejected_next_action_mismatch",
            )


def mark_ki_superseded(path: Path) -> None:
    if not path.exists():
        raise KernelError(f"Missing KI to supersede: {path}", "rejected_missing_active_decision")
    text = path.read_text(encoding="utf-8")
    text = text.replace('status: "active"', 'status: "superseded"')
    text = text.replace('promotion_state: "promoted"', 'promotion_state: "superseded"')
    path.write_text(text, encoding="utf-8")


def create_decision_ki(root: Path, event: dict[str, Any], producer_agent: str, approval_source: str | None) -> str:
    capture = event["durable_capture"]
    summary = str(capture["summary"])
    tenant_domain = str(capture["tenant_domain"])
    content_hash = str(event["content_hash"])
    timestamp = str(event["timestamp"])
    day = iso_day(timestamp)
    clock = iso_clock(timestamp)
    epoch = iso_epoch(timestamp)
    slug = slugify(summary) or "plan-aprobado"
    rel = f".agent/knowledge/architecture/{day}_{clock}_delivery_decision_{slug}.md"
    path = root / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    ki_id = sha256_short(f"{event['event_id']}|{event['source_host']}|{content_hash}|{summary}|{tenant_domain}")

    receipt_md = ""
    receipt = capture.get("receipt")
    if isinstance(receipt, dict):
        receipt_md = f"""

## Recibo aprobado
- objetivo: {receipt['objective']}
- content_hash: `{content_hash}`

### Superficies afectadas
{json_to_markdown_list(receipt.get('affected_surfaces'))}

### Archivos impactados
{json_to_markdown_list(receipt.get('impacted_files'))}

### Fases aprobadas
{json_to_markdown_list(receipt.get('approved_phases'))}

### Validación aprobada
{json_to_markdown_list(receipt.get('validation_commands'))}

### Rollback
- {receipt['rollback']}

### Restricciones
{json_to_markdown_list(receipt.get('constraints'))}
"""

    approval_line = f"- approval_source: `{approval_source}`\n" if approval_source else ""
    content = f"""---
ki_id: "{ki_id}"
category: "architecture"
kind: "decision"
status: "active"
is_consolidated: false
timestamp: {epoch}
tenant_domain: "{tenant_domain}"
entities: {json.dumps(["implementation_plan", "host_event", event["source_host"], tenant_domain], ensure_ascii=False)}
related_kis: []
---
# Decisión de entrega: {summary}

## Evento de origen
- host: `{event['source_host']}`
- productor: `{producer_agent}`
- event_id: `{event['event_id']}`
- content_hash: `{content_hash}`
- timestamp: `{timestamp}`
{approval_line}
## Resumen aprobado
{summary}
{receipt_md}
## Alternativas consideradas
{json_to_markdown_list(capture.get('alternatives'))}

## Validación esperada
{json_to_markdown_list(capture.get('validation'))}

## Riesgos y rollback
{json_to_markdown_list(capture.get('risks'))}
"""
    path.write_text(content, encoding="utf-8")
    return rel


def create_audit_ki(root: Path, event: dict[str, Any], producer_agent: str, approval_source: str | None) -> str:
    capture = event["durable_capture"]
    summary = str(capture["summary"])
    tenant_domain = str(capture["tenant_domain"])
    content_hash = str(event["content_hash"])
    timestamp = str(event["timestamp"])
    day = iso_day(timestamp)
    clock = iso_clock(timestamp)
    epoch = iso_epoch(timestamp)
    slug = slugify(summary) or "plan-review"
    rel = f".agent/knowledge/research/{day}_{clock}_plan_review_{slug}.md"
    path = root / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    ki_id = sha256_short(f"{event['event_id']}|{event['source_host']}|{content_hash}|{summary}|audit")
    approval_line = f"- approval_source: `{approval_source}`\n" if approval_source else ""
    content = f"""---
ki_id: "{ki_id}"
category: "research"
kind: "conclusion"
status: "active"
is_consolidated: false
timestamp: {epoch}
tenant_domain: "{tenant_domain}"
entities: {json.dumps(["implementation_plan", "plan_audit", event["source_host"], tenant_domain], ensure_ascii=False)}
related_kis: []
---
# Revisión durable del plan: {summary}

## Evento de origen
- host: `{event['source_host']}`
- productor: `{producer_agent}`
- event_id: `{event['event_id']}`
- content_hash: `{content_hash}`
- timestamp: `{timestamp}`
{approval_line}
## Resumen
{summary}

## Hallazgos
{json_to_markdown_list(capture.get('findings'))}
"""
    path.write_text(content, encoding="utf-8")
    return rel


def render_views(root: Path, renderer: Path, current_state_renderer: Path) -> None:
    subprocess.run(
        ["bash", str(current_state_renderer), "--root", str(root), "--write"],
        check=True,
        stdout=subprocess.DEVNULL,
    )
    subprocess.run(
        ["bash", str(current_state_renderer), "--root", str(root), "--check"],
        check=True,
        stdout=subprocess.DEVNULL,
    )
    subprocess.run(["bash", str(renderer), "--root", str(root), "--write"], check=True, stdout=subprocess.DEVNULL)
    subprocess.run(["bash", str(renderer), "--root", str(root), "--check"], check=True, stdout=subprocess.DEVNULL)


def apply_plan_event(root: Path, event: dict[str, Any]) -> dict[str, Any]:
    paths = ensure_paths(root)
    validate_event(event)

    event_root = canonical_dir(event["project_root"])
    if event_root != root:
        raise KernelError("Event project_root does not match the target ROOT.")

    producer_agent = (
        str(event["producer_agent"])
        if event["schema_version"] >= 2
        else derive_producer_agent(str(event["source_host"]))
    )
    approval_source = event.get("approval_source") or None
    origin_workflow = event.get("origin_workflow") or "auto-pilot-workflow.md"

    if journal_has_event(paths["journal"], str(event["event_id"])):
        emit_plan_trace(
            paths["trace"],
            event,
            producer_agent,
            approval_source,
            "passed",
            "noop_duplicate",
            "",
            True,
            origin_workflow,
        )
        return {
            "schema_version": event["schema_version"],
            "event_id": event["event_id"],
            "event_name": event["event_name"],
            "producer_agent": producer_agent,
            "result": "noop_duplicate",
            "no_op": True,
            **({"approval_source": approval_source} if approval_source else {}),
        }

    meta = parse_current_state(paths["current_state"], paths["current_state_md"])
    current = dict(meta["plan_state"])
    run_state = load_json(paths["run_state"])

    active_decision_ki = run_state.get("implementation_plan_active_decision_ki") or ""
    last_audit_ki = run_state.get("implementation_plan_last_audit_ki") or ""
    last_approval_source = run_state.get("implementation_plan_last_approval_source") or ""
    receipt_run_ref = run_state.get("implementation_plan_receipt_ref") or ""

    new_plan = {
        "required": bool(current.get("required")),
        "source": current.get("source") or "none",
        "status": current.get("status") or "not_required",
        "updated_at": event["timestamp"],
        "content_hash": current.get("content_hash"),
        "memory_synced": bool(current.get("memory_synced")),
        "next_action": current.get("next_action"),
        "producer_agent": current.get("producer_agent"),
        "receipt_ref": current.get("receipt_ref"),
    }
    new_active_decision_ki = active_decision_ki
    new_last_audit_ki = last_audit_ki
    new_last_approval_source = last_approval_source
    new_receipt_run_ref = receipt_run_ref
    primary_ki = ""
    transition_result = "applied"

    event_name = event["event_name"]
    content_hash = event.get("content_hash") or ""

    try:
        if event_name == "plan_required_resolved":
            ensure_next_action_matches(event, None)
            if event["required"]:
                new_plan.update(
                    {
                        "required": True,
                        "source": "none",
                        "status": "not_required",
                        "content_hash": None,
                        "memory_synced": False,
                        "next_action": None,
                        "producer_agent": None,
                        "receipt_ref": None,
                    }
                )
                new_last_approval_source = ""
                new_active_decision_ki = ""
                new_receipt_run_ref = ""
            else:
                new_plan = reset_plan_runtime_fields(str(event["timestamp"]))
                new_last_approval_source = ""
                new_active_decision_ki = ""
                new_receipt_run_ref = ""

        elif event_name == "plan_drafted":
            if current.get("required") is not True:
                raise KernelError("plan_drafted requires plan_state.required = true.", "rejected_invalid_transition")
            if current.get("status") not in {"not_required", "draft", "superseded"}:
                raise KernelError(
                    "plan_drafted is only valid from not_required, draft, or superseded.",
                    "rejected_invalid_transition",
                )
            ensure_next_action_matches(event, "present_for_approval")
            new_plan.update(
                {
                    "required": True,
                    "source": "host_internal",
                    "status": "draft",
                    "content_hash": content_hash,
                    "memory_synced": False,
                    "next_action": "present_for_approval",
                    "producer_agent": producer_agent,
                    "receipt_ref": None,
                }
            )
            new_receipt_run_ref = ""

        elif event_name == "plan_presented":
            if current.get("status") not in {"draft", "pending_user"}:
                raise KernelError(
                    "plan_presented is only valid from draft or pending_user.",
                    "rejected_invalid_transition",
                )
            ensure_next_action_matches(event, "wait_for_user_approval")
            new_plan.update(
                {
                    "required": True,
                    "source": "host_internal",
                    "status": "pending_user",
                    "content_hash": content_hash,
                    "memory_synced": False,
                    "next_action": "wait_for_user_approval",
                    "producer_agent": producer_agent,
                }
            )

        elif event_name == "plan_approved":
            if current.get("status") != "pending_user":
                raise KernelError("plan_approved is only valid from pending_user.", "rejected_invalid_transition")
            if active_decision_ki:
                raise KernelError(
                    "plan_approved found an active decision KI without a prior supersede/reset.",
                    "rejected_stale_active_decision",
                )
            ensure_next_action_matches(event, "implementation_unblocked")
            primary_ki = create_decision_ki(root, event, producer_agent, approval_source)
            new_plan.update(
                {
                    "required": True,
                    "source": "host_internal",
                    "status": "approved",
                    "content_hash": content_hash,
                    "memory_synced": True,
                    "next_action": "implementation_unblocked",
                    "producer_agent": producer_agent,
                    "receipt_ref": primary_ki,
                }
            )
            new_last_approval_source = approval_source or ""
            new_active_decision_ki = primary_ki
            new_receipt_run_ref = primary_ki

        elif event_name == "plan_superseded":
            if current.get("status") != "approved":
                raise KernelError("plan_superseded is only valid from approved.", "rejected_invalid_transition")
            if not active_decision_ki:
                raise KernelError(
                    "plan_superseded requires implementation_plan_active_decision_ki.",
                    "rejected_missing_active_decision",
                )
            ensure_next_action_matches(event, "draft_replacement_plan")
            mark_ki_superseded(root / active_decision_ki)
            new_plan.update(
                {
                    "required": True,
                    "source": "host_internal",
                    "status": "superseded",
                    "content_hash": content_hash,
                    "memory_synced": True,
                    "next_action": "draft_replacement_plan",
                    "producer_agent": producer_agent,
                    "receipt_ref": None,
                }
            )
            new_active_decision_ki = ""
            new_receipt_run_ref = ""

        elif event_name == "plan_audit_completed":
            if current.get("status") not in {"draft", "pending_user", "approved", "superseded"}:
                raise KernelError(
                    "plan_audit_completed requires an existing plan lifecycle state.",
                    "rejected_invalid_transition",
                )
            primary_ki = create_audit_ki(root, event, producer_agent, approval_source)
            new_last_audit_ki = primary_ki
            new_plan["memory_synced"] = True
            new_plan["producer_agent"] = producer_agent
            if event.get("supersede_active_plan") is True:
                ensure_next_action_matches(event, "draft_replacement_plan")
                if current.get("status") != "approved":
                    raise KernelError(
                        "supersede_active_plan=true requires current status approved.",
                        "rejected_invalid_transition",
                    )
                if not active_decision_ki:
                    raise KernelError(
                        "supersede_active_plan=true requires implementation_plan_active_decision_ki.",
                        "rejected_missing_active_decision",
                    )
                mark_ki_superseded(root / active_decision_ki)
                new_plan.update({"status": "superseded", "next_action": "draft_replacement_plan", "receipt_ref": None})
                new_active_decision_ki = ""
                new_receipt_run_ref = ""
            else:
                ensure_next_action_matches(event, current.get("next_action"))

        elif event_name == "plan_reset":
            ensure_next_action_matches(event, None)
            new_plan = reset_plan_runtime_fields(str(event["timestamp"]))
            new_last_approval_source = ""
            new_active_decision_ki = ""
            new_receipt_run_ref = ""

    except KernelError as exc:
        emit_plan_trace(
            paths["trace"],
            event,
            producer_agent,
            approval_source,
            "failed",
            exc.trace_result or "rejected_invalid_transition",
            "",
            False,
            origin_workflow,
        )
        raise

    meta["plan_state"] = new_plan
    meta["updated_at"] = new_plan["updated_at"]
    write_current_state(paths["current_state"], meta)
    render_views(root, paths["renderer"], paths["current_state_renderer"])

    run_state.update(
        {
            "implementation_plan_required": new_plan["required"],
            "implementation_plan_status": new_plan["status"],
            "implementation_plan_source": new_plan["source"],
            "implementation_plan_last_hash": new_plan["content_hash"],
            "implementation_plan_memory_synced": new_plan["memory_synced"],
            "implementation_plan_producer_agent": new_plan["producer_agent"],
            "implementation_plan_last_event_id": event["event_id"],
            "implementation_plan_last_event_name": event_name,
            "implementation_plan_last_transition_at": event["timestamp"],
            "implementation_plan_last_approval_source": new_last_approval_source or None,
            "implementation_plan_active_decision_ki": new_active_decision_ki or None,
            "implementation_plan_last_audit_ki": new_last_audit_ki or None,
            "implementation_plan_receipt_ref": new_receipt_run_ref or None,
            "lastUpdated": event["timestamp"],
        }
    )
    write_json(paths["run_state"], run_state)

    journal_line = {
        "schema_version": event["schema_version"],
        "event_id": event["event_id"],
        "event_name": event_name,
        "source_host": event["source_host"],
        "producer_agent": producer_agent,
        "timestamp": event["timestamp"],
        "transition_result": transition_result,
        "event": event,
        "state_after": new_plan,
    }
    if approval_source:
        journal_line["approval_source"] = approval_source
    if primary_ki:
        journal_line["ki_path"] = primary_ki
    append_jsonl(paths["journal"], journal_line)

    emit_plan_trace(
        paths["trace"],
        event,
        producer_agent,
        approval_source,
        "passed",
        transition_result,
        primary_ki,
        False,
        origin_workflow,
    )

    result = {
        "schema_version": event["schema_version"],
        "event_id": event["event_id"],
        "event_name": event_name,
        "producer_agent": producer_agent,
        "result": transition_result,
        "plan_state": {
            "required": new_plan["required"],
            "status": new_plan["status"],
            "memory_synced": new_plan["memory_synced"],
            "next_action": new_plan["next_action"],
            "producer_agent": new_plan["producer_agent"],
            "receipt_ref": new_plan["receipt_ref"],
        },
    }
    if approval_source:
        result["approval_source"] = approval_source
    if primary_ki:
        result["ki_path"] = primary_ki
    return result


def cmd_plan_ingest(args: argparse.Namespace) -> int:
    root = canonical_dir(args.root)
    try:
        if args.event_file:
            event = json.loads(Path(args.event_file).read_text(encoding="utf-8"))
        else:
            event = json.loads(args.event_json)
        result = apply_plan_event(root, event)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except KernelError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    except (json.JSONDecodeError, OSError, subprocess.CalledProcessError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        return 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Antigravity kernel control helper")
    subparsers = parser.add_subparsers(dest="command", required=True)

    plan = subparsers.add_parser("plan", help="Plan lifecycle operations")
    plan_sub = plan.add_subparsers(dest="plan_command", required=True)
    ingest = plan_sub.add_parser("ingest", help="Ingest a canonical plan event")
    ingest.add_argument("--root", default=str(Path.home() / ".gemini"))
    source = ingest.add_mutually_exclusive_group(required=True)
    source.add_argument("--event-file")
    source.add_argument("--event-json")
    ingest.set_defaults(func=cmd_plan_ingest)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
