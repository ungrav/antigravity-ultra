#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-$HOME/.gemini}"
BLUEPRINTS="$ROOT/GEMINI_BLUEPRINTS.md"
WORKFLOWS_DIR="$ROOT/workflows"
SKILLS_DIR="$ROOT/skills"
AUTOFIX_TEMPLATE_DIR="$ROOT/templates/autofix"
MANIFEST_DIR="$ROOT/blueprints"
MANIFEST_PATH="$MANIFEST_DIR/manifest.json"

mkdir -p "$MANIFEST_DIR"

TMP_EXTRACT="$(mktemp "${TMPDIR:-/tmp}/gemini-blueprint-extract.XXXXXX")"
TMP_JSONL="$(mktemp "${TMPDIR:-/tmp}/gemini-blueprint-jsonl.XXXXXX")"

cleanup() {
  rm -f "$TMP_EXTRACT" "$TMP_JSONL"
}
trap cleanup EXIT

extract_marker() {
  local marker_name="$1"
  awk -v begin="<!-- BEGIN: ${marker_name} -->" -v end="<!-- END: ${marker_name} -->" '
    $0 == begin { capture = 1; next }
    $0 == end { capture = 0; exit }
    capture { print }
  ' "$BLUEPRINTS" > "$TMP_EXTRACT"

  if [[ ! -s "$TMP_EXTRACT" ]]; then
    echo "Failed to extract marker ${marker_name} from $BLUEPRINTS" >&2
    exit 1
  fi
}

append_entry() {
  local artifact_id="$1"
  local kind="$2"
  local marker_name="$3"
  local canonical_path="$4"
  local default_restore_path="$5"
  local restore_scope="$6"
  local source_group="$7"
  local sha256="$8"
  local bytes="$9"

  jq -n \
    --arg artifact_id "$artifact_id" \
    --arg kind "$kind" \
    --arg marker_name "$marker_name" \
    --arg canonical_path "$canonical_path" \
    --arg default_restore_path "$default_restore_path" \
    --arg restore_scope "$restore_scope" \
    --arg source_group "$source_group" \
    --arg sha256 "$sha256" \
    --argjson bytes "$bytes" \
    '{
      artifact_id: $artifact_id,
      kind: $kind,
      marker_name: $marker_name,
      canonical_path: $canonical_path,
      default_restore_path: $default_restore_path,
      restore_scope: $restore_scope,
      source_group: $source_group,
      sha256: $sha256,
      bytes: $bytes
    }' >> "$TMP_JSONL"
}

while IFS= read -r file; do
  [[ -z "$file" ]] && continue
  status="$(sed -nE 's/^status:[[:space:]]*//p' "$file" 2>/dev/null | head -1)"
  if [[ "$status" == "adapter" || "$status" == "archived" ]]; then
    continue
  fi

  name="$(basename "$file")"
  sha256="$(shasum -a 256 "$file" | awk '{print $1}')"
  bytes="$(wc -c < "$file" | tr -d ' ')"
  append_entry \
    "workflow:${name}" \
    "workflow" \
    "$name" \
    "workflows/${name}" \
    "workflows/${name}" \
    "gemini_root" \
    "workflows" \
    "$sha256" \
    "$bytes"
done < <(find "$WORKFLOWS_DIR" -maxdepth 1 -name '*-workflow.md' | sort)

for template in DESIGN_SYSTEM.md PROJECT_HISTORY.md ERROR_LOG.md AGENTS.md; do
  extract_marker "$template"
  sha256="$(shasum -a 256 "$TMP_EXTRACT" | awk '{print $1}')"
  bytes="$(wc -c < "$TMP_EXTRACT" | tr -d ' ')"
  append_entry \
    "template:${template}" \
    "template" \
    "$template" \
    "GEMINI_BLUEPRINTS.md" \
    "$template" \
    "project_root" \
    "core_templates" \
    "$sha256" \
    "$bytes"
done

for artifact in \
  "skill:autofix/SKILL.md|skill|skill:autofix/SKILL.md|skills/autofix/SKILL.md|skills/autofix/SKILL.md|gemini_root|portable_skills|$SKILLS_DIR/autofix/SKILL.md" \
  "skill:autofix/scripts/autofix-loop.sh|skill|skill:autofix/scripts/autofix-loop.sh|skills/autofix/scripts/autofix-loop.sh|skills/autofix/scripts/autofix-loop.sh|gemini_root|portable_skills|$SKILLS_DIR/autofix/scripts/autofix-loop.sh" \
  "template:autofix/spec.json|template|template:autofix/spec.json|templates/autofix/spec.json|.autofix/spec.json|project_root|autofix_templates|$AUTOFIX_TEMPLATE_DIR/spec.json" \
  "template:autofix/program.md|template|template:autofix/program.md|templates/autofix/program.md|.autofix/program.md|project_root|autofix_templates|$AUTOFIX_TEMPLATE_DIR/program.md" \
  "template:autofix/eval.sh|template|template:autofix/eval.sh|templates/autofix/eval.sh|.autofix/eval.sh|project_root|autofix_templates|$AUTOFIX_TEMPLATE_DIR/eval.sh" \
  "template:autofix/result.json|template|template:autofix/result.json|templates/autofix/result.json|.autofix/result.json|project_root|autofix_templates|$AUTOFIX_TEMPLATE_DIR/result.json" \
  "template:autofix/state.json|template|template:autofix/state.json|templates/autofix/state.json|.autofix/state.json|project_root|autofix_templates|$AUTOFIX_TEMPLATE_DIR/state.json"
do
  IFS='|' read -r artifact_id kind marker_name canonical_path default_restore_path restore_scope source_group source_file <<< "$artifact"
  [[ -f "$source_file" ]] || continue
  sha256="$(shasum -a 256 "$source_file" | awk '{print $1}')"
  bytes="$(wc -c < "$source_file" | tr -d ' ')"
  append_entry \
    "$artifact_id" \
    "$kind" \
    "$marker_name" \
    "$canonical_path" \
    "$default_restore_path" \
    "$restore_scope" \
    "$source_group" \
    "$sha256" \
    "$bytes"
done

jq -n \
  --arg generated_at "$(date -u +"%Y-%m-%dT%H:%M:%SZ")" \
  --arg blueprints_file "GEMINI_BLUEPRINTS.md" \
  --slurpfile entries "$TMP_JSONL" \
  '{
    version: 3,
    generated_at: $generated_at,
    blueprints_file: $blueprints_file,
    artifacts: ($entries | map({(.artifact_id): .}) | add)
  }' > "$MANIFEST_PATH"

echo "BLUEPRINT_MANIFEST_UPDATED"
