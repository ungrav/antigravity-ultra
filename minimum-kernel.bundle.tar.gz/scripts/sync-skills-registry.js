#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const ROOT = process.argv[2] || process.env.ROOT || path.join(os.homedir(), '.gemini');
const HOME = os.homedir();
const TODAY = new Date().toISOString().slice(0, 10);

const manifestPath = path.join(ROOT, 'skills-manifest.json');
const lockPath = path.join(ROOT, 'skills-lock.json');
const curationPath = path.join(ROOT, 'config', 'skills-curation.json');

const DEFAULT_SCOPE_CLASSES = {
  workspace: 'project',
  'workspace-gemini-native': 'project',
  'workspace-legacy': 'project',
  'portable-root': 'project',
  'antigravity-global': 'global-controlled',
  'gemini-global': 'global-controlled',
  codex: 'global-external',
  'agents-host': 'global-external'
};

const DEFAULT_LOGICAL_FAMILIES = {
  project_scopes: ['workspace', 'workspace-gemini-native', 'workspace-legacy', 'portable-root'],
  global_controlled: ['antigravity-global', 'gemini-global'],
  global_external: ['codex', 'agents-host'],
  live_discovery: ['mcp', 'community']
};

const scopeDefs = [
  {
    scope: 'workspace',
    dir: path.join(ROOT, '.agents', 'skills'),
    label: '.agents/skills/',
    priority: 0,
    sourceType: 'workspace',
    trust: 'workspace-local',
    exclude: new Set()
  },
  {
    scope: 'workspace-gemini-native',
    dir: path.join(ROOT, '.gemini', 'skills'),
    label: '.gemini/skills/',
    priority: 1,
    sourceType: 'workspace-gemini-native',
    trust: 'workspace-local',
    exclude: new Set()
  },
  {
    scope: 'workspace-legacy',
    dir: path.join(ROOT, '.agent', 'skills'),
    label: '.agent/skills/',
    priority: 2,
    sourceType: 'workspace-legacy',
    trust: 'workspace-legacy',
    exclude: new Set()
  },
  {
    scope: 'portable-root',
    dir: path.join(ROOT, 'skills'),
    label: 'skills/',
    priority: 3,
    sourceType: 'portable-root',
    trust: 'workspace-local',
    exclude: new Set()
  },
  {
    scope: 'antigravity-global',
    dir: path.join(HOME, '.gemini', 'antigravity', 'skills'),
    label: '~/.gemini/antigravity/skills/',
    priority: 4,
    sourceType: 'antigravity-global',
    trust: 'local-installed',
    exclude: new Set()
  },
  {
    scope: 'gemini-global',
    dir: path.join(HOME, '.gemini', 'skills'),
    label: '~/.gemini/skills/',
    priority: 5,
    sourceType: 'gemini-global',
    trust: 'local-installed',
    exclude: new Set()
  },
  {
    scope: 'codex',
    dir: path.join(HOME, '.codex', 'skills'),
    label: '~/.codex/skills/',
    priority: 6,
    sourceType: 'codex-bundled',
    trust: 'bundled',
    exclude: new Set(['.system'])
  },
  {
    scope: 'agents-host',
    dir: path.join(HOME, '.agents', 'skills'),
    label: '~/.agents/skills/',
    priority: 7,
    sourceType: 'system-managed',
    trust: 'external-managed',
    exclude: new Set()
  }
];

function readJsonSafe(filePath) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return {};
  }
}

function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

function normalizeScalar(raw) {
  if (raw == null) return null;
  const trimmed = String(raw).trim();
  if (!trimmed) return null;
  if (
    (trimmed.startsWith('"') && trimmed.endsWith('"')) ||
    (trimmed.startsWith("'") && trimmed.endsWith("'"))
  ) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

function parseFrontmatter(skillMdPath) {
  if (!fs.existsSync(skillMdPath)) return {};

  const content = fs.readFileSync(skillMdPath, 'utf8');
  const lines = content.split(/\r?\n/);
  if (lines[0] !== '---') return {};

  const data = {};
  let inMetadata = false;
  let multilineKey = null;
  let multilineMode = null;
  let multilineBuffer = [];

  function flushMultiline() {
    if (!multilineKey) return;
    const raw = multilineBuffer.join(multilineMode === 'literal' ? '\n' : ' ');
    data[multilineKey] = raw.replace(/\s+/g, ' ').trim();
    multilineKey = null;
    multilineMode = null;
    multilineBuffer = [];
  }

  for (let i = 1; i < lines.length; i += 1) {
    const line = lines[i];
    if (line === '---') {
      flushMultiline();
      break;
    }

    if (multilineKey) {
      const multiLine = line.match(/^\s{2,}(.*)$/);
      if (multiLine) {
        multilineBuffer.push(multiLine[1].trim());
        continue;
      }
      flushMultiline();
    }

    if (inMetadata) {
      const nested = line.match(/^\s{2,}([A-Za-z0-9_-]+):\s*(.*)$/);
      if (nested) {
        if (nested[1] === 'version') {
          data.version = normalizeScalar(nested[2]);
        }
        continue;
      }
      if (/^\S/.test(line)) {
        inMetadata = false;
      } else {
        continue;
      }
    }

    if (/^metadata:\s*$/.test(line)) {
      inMetadata = true;
      continue;
    }

    const top = line.match(/^([A-Za-z0-9_-]+):\s*(.*)$/);
    if (!top) continue;

    if (top[2] === '>' || top[2] === '|') {
      multilineKey = top[1];
      multilineMode = top[2] === '|' ? 'literal' : 'folded';
      multilineBuffer = [];
      continue;
    }

    data[top[1]] = normalizeScalar(top[2]);
  }

  flushMultiline();
  return data;
}

function sha256(filePath) {
  if (!fs.existsSync(filePath)) return null;
  return crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex');
}

function compileRegexRules(rawRules, shapeRule) {
  if (!Array.isArray(rawRules)) return [];
  return rawRules
    .map((rawRule) => {
      if (!rawRule || !rawRule.pattern) return null;
      try {
        return {
          regex: new RegExp(rawRule.pattern, 'i'),
          ...shapeRule(rawRule)
        };
      } catch {
        return null;
      }
    })
    .filter(Boolean);
}

function listSkillDirs(scopeDef) {
  if (!fs.existsSync(scopeDef.dir)) return [];
  return fs
    .readdirSync(scopeDef.dir, { withFileTypes: true })
    .filter((dirent) => dirent.isDirectory() && !scopeDef.exclude.has(dirent.name))
    .map((dirent) => dirent.name)
    .sort((a, b) => a.localeCompare(b));
}

function makeLocation(scopeDef, skillId) {
  return `${scopeDef.label}${skillId}`;
}

function fallbackDescription(skillId, scopeDef) {
  return `Skill '${skillId}' discovered in ${scopeDef.label}. Read SKILL.md for the full instructions.`;
}

function dedupeBy(list, keyFn) {
  return Array.from(new Map(list.map((item) => [keyFn(item), item])).values());
}

function ensureUniqueDestination(basePath) {
  if (!fs.existsSync(basePath)) return basePath;
  let counter = 1;
  while (true) {
    const candidate = `${basePath}--${counter}`;
    if (!fs.existsSync(candidate)) return candidate;
    counter += 1;
  }
}

function readTrashInventory() {
  const trashRoot = path.join(ROOT, cleanupPolicies.trashDir);
  if (!fs.existsSync(trashRoot)) return [];

  const archived = [];
  for (const dateDir of fs.readdirSync(trashRoot, { withFileTypes: true })) {
    if (!dateDir.isDirectory()) continue;
    const datedRoot = path.join(trashRoot, dateDir.name);
    for (const scopeDir of fs.readdirSync(datedRoot, { withFileTypes: true })) {
      if (!scopeDir.isDirectory()) continue;
      const scopeRoot = path.join(datedRoot, scopeDir.name);
      for (const skillDir of fs.readdirSync(scopeRoot, { withFileTypes: true })) {
        if (!skillDir.isDirectory()) continue;
        archived.push({
          skillId: skillDir.name,
          scope: scopeDir.name,
          scopeClass: 'global-controlled',
          family: null,
          category: null,
          location: null,
          archivedTo: path.join(scopeRoot, skillDir.name),
          reason: 'archived_to_trash',
          source: 'trash_inventory'
        });
      }
    }
  }

  return archived;
}

function rankScopePriority(scope) {
  return scopeDefs.find((scopeDef) => scopeDef.scope === scope)?.priority ?? 999;
}

function rankTrust(trust) {
  switch (trust) {
    case 'workspace-local':
      return 0;
    case 'workspace-legacy':
      return 1;
    case 'local-installed':
      return 2;
    case 'bundled':
      return 3;
    case 'external-managed':
      return 4;
    default:
      return 9;
  }
}

const existingManifest = readJsonSafe(manifestPath);
const existingLock = readJsonSafe(lockPath);
const curationConfig = readJsonSafe(curationPath);
const existingManifestSkills = existingManifest.skills || {};
const existingLockSkills = existingLock.skills || {};

const logicalFamilies = {
  ...DEFAULT_LOGICAL_FAMILIES,
  ...(curationConfig.logicalFamilies || {})
};
const scopeClasses = {
  ...DEFAULT_SCOPE_CLASSES,
  ...(curationConfig.scopeClasses || {})
};
const globalCaps = {
  essential: 25,
  useful: 80,
  ...(curationConfig.globalCaps || {})
};

const explicitCoreSkillIds = new Set(curationConfig.explicitCoreSkillIds || []);
const requiredSkillIds = new Set(curationConfig.requiredSkillIds || []);
const protectedSkillIds = new Set([
  ...(curationConfig.protectedSkillIds || []),
  ...Array.from(explicitCoreSkillIds),
  ...Array.from(requiredSkillIds)
]);
const explicitArchivedSkillIds = curationConfig.explicitArchivedSkillIds || {};
const categoryOverrides = curationConfig.categoryOverrides || {};
const categoryPatterns = compileRegexRules(curationConfig.categoryPatterns, (rule) => ({
  category: normalizeScalar(rule.category) || 'general'
}));
const familyMappings = compileRegexRules(curationConfig.familyMappings, (rule) => ({
  name: normalizeScalar(rule.name) || null
}));
const archivedPatterns = compileRegexRules(curationConfig.archivedPatterns, (rule) => ({
  reason: normalizeScalar(rule.reason) || 'pattern_archived'
}));
const globalDisallowedPatterns = compileRegexRules(curationConfig.globalDisallowedPatterns, (rule) => ({
  reason: normalizeScalar(rule.reason) || 'global_policy_archived',
  family: normalizeScalar(rule.family) || null
}));
const cleanupPolicies = {
  archiveShadowedDuplicates: true,
  archiveDivergentShadowedDuplicates: true,
  archiveMissingSkillMd: true,
  archivePersonaNoise: true,
  moveControlledArchived: true,
  trashDir: '_DEPRECATED_TRASH/skills-cleanup',
  ...(curationConfig.cleanupPolicies || {})
};
const reportConfig = {
  path: 'reports/skills-curation-report.json',
  consolidationThreshold: 6,
  ...(curationConfig.report || {})
};
const globalAllowedCategories = new Set(curationConfig.globalAllowedCategories || []);
const globalSelectionPriority = new Map(
  (curationConfig.globalSelectionPriority || []).map((category, index) => [category, index])
);
const globalArchivedFamilies = new Set(curationConfig.globalArchivedFamilies || []);
const projectOnlyFamilies = new Set(curationConfig.projectOnlyFamilies || []);
const essentialSeed = new Set([
  ...Array.from(explicitCoreSkillIds),
  ...Array.from(requiredSkillIds)
]);

function detectFamily(skillId) {
  for (const rule of familyMappings) {
    if (rule.regex.test(skillId)) return rule.name;
  }
  return null;
}

function inferCategory(skillId, preferredScope) {
  if (categoryOverrides[skillId]) {
    return categoryOverrides[skillId];
  }

  for (const rule of categoryPatterns) {
    if (rule.regex.test(skillId)) {
      return rule.category;
    }
  }

  const id = skillId.toLowerCase();
  if (id.includes('security') || id.startsWith('ghost-')) return 'security';
  if (id.includes('docker')) return 'devops';
  if (id.includes('postgres') || id.includes('database') || id.includes('migration')) return 'database';
  if (id.includes('playwright') || id.includes('browser') || id.includes('screenshot')) return 'tooling';
  if (id.includes('deploy') || id.includes('netlify') || id.includes('render')) return 'deployment';
  if (id.includes('openai') || id.includes('ai') || id.includes('chatgpt') || id.includes('sora') || id.includes('speech') || id.includes('transcribe') || id.includes('imagegen')) return 'ai';
  if (id.includes('design') || id.includes('ux') || id.includes('frontend') || id.includes('web-design')) return 'design';
  if (id.includes('test')) return 'testing';
  if (id.includes('antigravity')) return 'antigravity';
  if (id.includes('skill') || id.includes('plugin')) return 'meta';
  if (id.includes('workflow') || id.includes('agent')) return 'architecture';
  if (scopeClasses[preferredScope] === 'global-external') return 'host-managed';
  return 'general';
}

function inferSource(skillId, scope, frontmatter, existingManifestEntry, existingLockEntry) {
  return (
    frontmatter.source ||
    (existingManifestEntry && existingManifestEntry.source) ||
    (existingLockEntry && existingLockEntry.source) ||
    `${scope}:${skillId}`
  );
}

function findArchivedPatternReason(skillId) {
  if (explicitArchivedSkillIds[skillId]) {
    return explicitArchivedSkillIds[skillId];
  }

  for (const rule of archivedPatterns) {
    if (rule.regex.test(skillId)) return rule.reason;
  }
  return null;
}

function findGlobalDisallowedReason(skillId, family) {
  if (family && globalArchivedFamilies.has(family)) {
    if (projectOnlyFamilies.has(family)) {
      return `project_only_family_${family}`;
    }
    return `global_family_${family}_not_allowed`;
  }

  for (const rule of globalDisallowedPatterns) {
    if (rule.regex.test(skillId)) {
      return rule.reason;
    }
  }

  return null;
}

function buildInventory() {
  const aggregated = new Map();
  const seenDiscoveryDirs = new Set();

  for (const scopeDef of scopeDefs) {
    const scopeDirKey = fs.existsSync(scopeDef.dir) ? fs.realpathSync(scopeDef.dir) : path.resolve(scopeDef.dir);
    if (seenDiscoveryDirs.has(scopeDirKey)) {
      continue;
    }
    seenDiscoveryDirs.add(scopeDirKey);

    for (const skillId of listSkillDirs(scopeDef)) {
      const skillDir = path.join(scopeDef.dir, skillId);
      const skillMd = path.join(skillDir, 'SKILL.md');
      const frontmatter = parseFrontmatter(skillMd);
      const existingManifestEntry = existingManifestSkills[skillId];
      const existingLockEntry = existingLockSkills[skillId];
      const scopeClass = scopeClasses[scopeDef.scope] || 'project';

      const instance = {
        scope: scopeDef.scope,
        scopeClass,
        location: makeLocation(scopeDef, skillId),
        absoluteDir: skillDir,
        source: inferSource(skillId, scopeDef.scope, frontmatter, existingManifestEntry, existingLockEntry),
        sourceType:
          frontmatter.source ? 'frontmatter' : (existingManifestEntry && existingManifestEntry.sourceType) || scopeDef.sourceType,
        trust: scopeDef.trust,
        version:
          frontmatter.version ||
          (existingManifestEntry && existingManifestEntry.version) ||
          (existingLockEntry && existingLockEntry.version) ||
          null,
        license:
          frontmatter.license ||
          (existingManifestEntry && existingManifestEntry.license) ||
          (existingLockEntry && existingLockEntry.license) ||
          null,
        computedHash: sha256(skillMd),
        hasSkillMd: fs.existsSync(skillMd)
      };

      if (!aggregated.has(skillId)) {
        aggregated.set(skillId, {
          id: skillId,
          name: frontmatter.name || (existingManifestEntry && existingManifestEntry.name) || skillId,
          description:
            frontmatter.description ||
            (existingManifestEntry && existingManifestEntry.description) ||
            (existingLockEntry && existingLockEntry.description) ||
            fallbackDescription(skillId, scopeDef),
          instances: []
        });
      }

      aggregated.get(skillId).instances.push(instance);
    }
  }

  return aggregated;
}

function curateInventory(aggregated, archivedInventory = []) {
  const discoveryOrder = scopeDefs.map((scopeDef) => scopeDef.scope).concat(['mcp', 'community']);
  const prepared = [];
  const familyBuckets = new Map();
  let divergentDuplicateCount = 0;
  let shadowedDuplicateCount = 0;

  for (const [skillId, entry] of Array.from(aggregated.entries()).sort((a, b) => a[0].localeCompare(b[0]))) {
    entry.instances.sort((a, b) => {
      if (a.hasSkillMd !== b.hasSkillMd) return a.hasSkillMd ? -1 : 1;
      return rankScopePriority(a.scope) - rankScopePriority(b.scope) || a.location.localeCompare(b.location);
    });

    const preferred = entry.instances[0];
    const family = detectFamily(skillId);
    const category = inferCategory(skillId, preferred.scope);
    const uniqueHashes = Array.from(
      new Set(entry.instances.map((instance) => instance.computedHash || `missing:${instance.location}`))
    );
    const duplicateState =
      entry.instances.length <= 1
        ? 'unique'
        : uniqueHashes.length === 1
          ? 'shadowed_duplicate'
          : 'divergent_duplicate';

    if (duplicateState === 'shadowed_duplicate') shadowedDuplicateCount += 1;
    if (duplicateState === 'divergent_duplicate') divergentDuplicateCount += 1;

    entry.instances = entry.instances.map((instance, index) => {
      const isPreferred = index === 0;
      let instanceDuplicateState = 'unique';
      let shadowedBy = null;

      if (duplicateState === 'shadowed_duplicate') {
        instanceDuplicateState = isPreferred ? 'preferred' : 'shadowed';
        shadowedBy = isPreferred ? null : preferred.location;
      } else if (duplicateState === 'divergent_duplicate') {
        instanceDuplicateState = isPreferred ? 'preferred' : 'divergent_shadowed';
        shadowedBy = isPreferred ? null : preferred.location;
      }

      return {
        ...instance,
        duplicateState: instanceDuplicateState,
        shadowedBy
      };
    });

    if (family) {
      if (!familyBuckets.has(family)) familyBuckets.set(family, []);
      familyBuckets.get(family).push(skillId);
    }

    prepared.push({
      skillId,
      name: entry.name || skillId,
      description: entry.description || '',
      preferred,
      instances: entry.instances,
      category,
      family,
      duplicateState,
      isEssentialSeed: essentialSeed.has(skillId),
      isProtected: protectedSkillIds.has(skillId),
      scopeClass: preferred.scopeClass,
      archivedPatternReason: findArchivedPatternReason(skillId),
      globalDisallowedReason:
        preferred.scopeClass === 'project' ? null : findGlobalDisallowedReason(skillId, family)
    });
  }

  const essentialSelected = new Set();
  const usefulSelected = new Set();

  for (const entry of prepared) {
    if (entry.scopeClass !== 'global-controlled') continue;
    if (entry.archivedPatternReason) continue;
    if (!entry.preferred.hasSkillMd && !entry.isProtected) continue;
    if (entry.isEssentialSeed) essentialSelected.add(entry.skillId);
  }

  const usefulCandidates = prepared
    .filter((entry) => {
      if (entry.scopeClass !== 'global-controlled') return false;
      if (essentialSelected.has(entry.skillId)) return false;
      if (entry.archivedPatternReason) return false;
      if (entry.globalDisallowedReason) return false;
      if (!entry.preferred.hasSkillMd && !entry.isProtected) return false;
      return globalAllowedCategories.has(entry.category);
    })
    .sort((a, b) => {
      const aPriority = globalSelectionPriority.get(a.category) ?? 999;
      const bPriority = globalSelectionPriority.get(b.category) ?? 999;
      if (aPriority !== bPriority) return aPriority - bPriority;
      if (a.isProtected !== b.isProtected) return a.isProtected ? -1 : 1;
      const trustDiff = rankTrust(a.preferred.trust) - rankTrust(b.preferred.trust);
      if (trustDiff !== 0) return trustDiff;
      const scopeDiff = rankScopePriority(a.preferred.scope) - rankScopePriority(b.preferred.scope);
      if (scopeDiff !== 0) return scopeDiff;
      return a.skillId.localeCompare(b.skillId);
    })
    .slice(0, Number(globalCaps.useful || 80));

  for (const entry of usefulCandidates) {
    usefulSelected.add(entry.skillId);
  }

  const manifestSkills = {};
  const lockSkills = {};
  const categoryIndex = {};
  const tierIndex = {
    core: [],
    supplemental: [],
    archived: []
  };
  const globalTierIndex = {
    essential: [],
    useful: [],
    noise: [],
    'n/a': []
  };
  const cleanupCandidates = [];
  const policyArchivedSkills = [...archivedInventory];

  for (const entry of prepared) {
    const preferred = entry.preferred;
    const scopeClass = entry.scopeClass;
    let tier = 'supplemental';
    let defaultDiscovery = false;
    let globalTier = 'n/a';
    let countsTowardControlledGlobalCap = false;
    let curationReason = 'external_managed_hidden_from_default';
    let forcedArchivedReason = null;
    let selectionReason = null;

    if (entry.archivedPatternReason) {
      tier = 'archived';
      defaultDiscovery = false;
      globalTier = scopeClass === 'global-controlled' ? 'noise' : 'n/a';
      curationReason = entry.archivedPatternReason;
      forcedArchivedReason = entry.archivedPatternReason;
      selectionReason = 'archived_by_pattern';
    } else if (!preferred.hasSkillMd && !entry.isProtected) {
      tier = 'archived';
      defaultDiscovery = false;
      globalTier = scopeClass === 'global-controlled' ? 'noise' : 'n/a';
      curationReason = 'missing_skill_md';
      forcedArchivedReason = 'missing_skill_md';
      selectionReason = 'archived_missing_skill_md';
    } else if (scopeClass === 'project') {
      tier = 'core';
      defaultDiscovery = true;
      globalTier = 'n/a';
      curationReason = entry.isEssentialSeed ? 'project_required_skill' : 'project_scoped_active';
      selectionReason = entry.isEssentialSeed ? 'project_required_visible' : 'project_scope_default';
    } else if (scopeClass === 'global-external') {
      if (entry.isEssentialSeed) {
        tier = 'core';
        defaultDiscovery = true;
        globalTier = 'essential';
        curationReason = 'external_required_exception';
        selectionReason = 'external_required_exception';
      } else if (entry.globalDisallowedReason) {
        tier = 'archived';
        defaultDiscovery = false;
        globalTier = 'n/a';
        curationReason = entry.globalDisallowedReason;
        forcedArchivedReason = entry.globalDisallowedReason;
        selectionReason = 'external_disallowed_archived';
      } else {
        tier = 'supplemental';
        defaultDiscovery = false;
        globalTier = 'n/a';
        curationReason = 'external_managed_hidden_from_default';
        selectionReason = 'external_hidden';
      }
    } else if (scopeClass === 'global-controlled') {
      if (essentialSelected.has(entry.skillId)) {
        tier = 'core';
        defaultDiscovery = true;
        globalTier = 'essential';
        countsTowardControlledGlobalCap = true;
        curationReason = entry.isEssentialSeed ? (requiredSkillIds.has(entry.skillId) ? 'required_by_system' : 'explicit_core_skill') : 'global_controlled_essential';
        selectionReason = 'controlled_global_essential';
      } else if (entry.globalDisallowedReason) {
        tier = 'archived';
        defaultDiscovery = false;
        globalTier = 'noise';
        curationReason = entry.globalDisallowedReason;
        forcedArchivedReason = entry.globalDisallowedReason;
        selectionReason = 'forced_archived_policy_family';
      } else if (usefulSelected.has(entry.skillId)) {
        tier = 'supplemental';
        defaultDiscovery = false;
        globalTier = 'useful';
        countsTowardControlledGlobalCap = true;
        curationReason = 'controlled_global_useful_selected';
        selectionReason = 'controlled_global_useful';
      } else {
        tier = 'archived';
        defaultDiscovery = false;
        globalTier = 'noise';
        curationReason = 'controlled_global_noise_archived';
        forcedArchivedReason = 'controlled_global_noise_archived';
        selectionReason = 'controlled_global_noise';
      }
    }

    const resolvedInstances = entry.instances.map((instance, index) => {
      const isPreferred = index === 0;
      const instanceDefaultDiscovery = isPreferred ? defaultDiscovery : false;

      if (
        !isPreferred &&
        cleanupPolicies.archiveShadowedDuplicates &&
        instance.duplicateState === 'shadowed' &&
        instance.scopeClass === 'global-controlled'
      ) {
        cleanupCandidates.push({
          skillId: entry.skillId,
          scope: instance.scope,
          scopeClass: instance.scopeClass,
          location: instance.location,
          absoluteDir: instance.absoluteDir,
          category: entry.category,
          family: entry.family,
          tier,
          globalTier,
          reason: 'shadowed_duplicate',
          duplicateState: instance.duplicateState
        });
      }

      if (
        !isPreferred &&
        cleanupPolicies.archiveDivergentShadowedDuplicates &&
        instance.duplicateState === 'divergent_shadowed' &&
        instance.scopeClass === 'global-controlled'
      ) {
        cleanupCandidates.push({
          skillId: entry.skillId,
          scope: instance.scope,
          scopeClass: instance.scopeClass,
          location: instance.location,
          absoluteDir: instance.absoluteDir,
          category: entry.category,
          family: entry.family,
          tier,
          globalTier,
          reason: 'divergent_shadowed_duplicate',
          duplicateState: instance.duplicateState
        });
      }

      if (
        !isPreferred &&
        cleanupPolicies.archiveMissingSkillMd &&
        !instance.hasSkillMd &&
        instance.scopeClass === 'global-controlled'
      ) {
        cleanupCandidates.push({
          skillId: entry.skillId,
          scope: instance.scope,
          scopeClass: instance.scopeClass,
          location: instance.location,
          absoluteDir: instance.absoluteDir,
          category: entry.category,
          family: entry.family,
          tier,
          globalTier,
          reason: 'missing_skill_md',
          duplicateState: instance.duplicateState
        });
      }

      return {
        ...instance,
        defaultDiscovery: instanceDefaultDiscovery
      };
    });

    if (
      scopeClass === 'global-controlled' &&
      cleanupPolicies.moveControlledArchived &&
      tier === 'archived' &&
      !entry.isProtected
    ) {
      cleanupCandidates.push({
        skillId: entry.skillId,
        scope: preferred.scope,
        scopeClass,
        location: preferred.location,
        absoluteDir: preferred.absoluteDir,
        category: entry.category,
        family: entry.family,
        tier,
        globalTier,
        reason: forcedArchivedReason || curationReason,
        duplicateState: entry.duplicateState
      });
    }

    if (
      forcedArchivedReason &&
      (!entry.isProtected || scopeClass !== 'global-controlled')
    ) {
      policyArchivedSkills.push({
        skillId: entry.skillId,
        scope: preferred.scope,
        scopeClass,
        family: entry.family,
        category: entry.category,
        location: preferred.location,
        archivedTo: null,
        reason: forcedArchivedReason,
        source: preferred.source
      });
    }

    manifestSkills[entry.skillId] = {
      name: entry.name,
      location: preferred.location,
      preferredScope: preferred.scope,
      scopeClass,
      globalTier,
      family: entry.family,
      countsTowardControlledGlobalCap,
      forcedArchivedReason,
      selectionReason,
      source: preferred.source,
      sourceType: preferred.sourceType,
      category: entry.category,
      description: entry.description,
      version: preferred.version,
      license: preferred.license,
      trust: preferred.trust,
      tier,
      defaultDiscovery,
      duplicateState: entry.duplicateState,
      shadowedBy: null,
      curationReason,
      instances: resolvedInstances
    };

    lockSkills[entry.skillId] = {
      name: entry.name,
      description: entry.description,
      preferredScope: preferred.scope,
      preferredLocation: preferred.location,
      scopeClass,
      globalTier,
      family: entry.family,
      countsTowardControlledGlobalCap,
      forcedArchivedReason,
      selectionReason,
      source: preferred.source,
      sourceType: preferred.sourceType,
      version: preferred.version,
      license: preferred.license,
      trust: preferred.trust,
      tier,
      defaultDiscovery,
      duplicateState: entry.duplicateState,
      shadowedBy: null,
      curationReason,
      instances: resolvedInstances
    };

    if (!categoryIndex[entry.category]) categoryIndex[entry.category] = [];
    categoryIndex[entry.category].push(entry.skillId);
    tierIndex[tier].push(entry.skillId);
    globalTierIndex[globalTier].push(entry.skillId);
  }

  for (const index of [categoryIndex, tierIndex, globalTierIndex]) {
    for (const key of Object.keys(index)) {
      index[key].sort((a, b) => a.localeCompare(b));
    }
  }

  const familySummary = Array.from(
    Object.values(lockSkills).reduce((map, skill) => {
      if (!skill.family) return map;
      if (!map[skill.family]) {
        map[skill.family] = {
          family: skill.family,
          count: 0,
          active: 0,
          archived: 0,
          skills: []
        };
      }
      map[skill.family].count += 1;
      map[skill.family].skills.push(skill.name);
      if (skill.tier === 'archived') {
        map[skill.family].archived += 1;
      } else {
        map[skill.family].active += 1;
      }
      return map;
    }, {})
  )
    .map((entry) => ({
      ...entry,
      skills: entry.skills.sort((a, b) => a.localeCompare(b))
    }))
    .sort((a, b) => b.count - a.count || a.family.localeCompare(b.family));

  const consolidationCandidates = familySummary
    .filter((entry) => entry.count >= Number(reportConfig.consolidationThreshold || 6))
    .map(({ family, count, skills }) => ({ family, count, skills }));

  const uniqueCleanupCandidates = dedupeBy(cleanupCandidates, (candidate) =>
    [candidate.skillId, candidate.location, candidate.reason].join(':')
  ).sort((a, b) => a.skillId.localeCompare(b.skillId) || a.location.localeCompare(b.location));

  const uniquePolicyArchivedSkills = dedupeBy(policyArchivedSkills, (entry) =>
    [entry.skillId, entry.scope || '', entry.reason || '', entry.archivedTo || ''].join(':')
  ).sort((a, b) => a.skillId.localeCompare(b.skillId) || (a.archivedTo || '').localeCompare(b.archivedTo || ''));

  const controlledGlobalCounts = {
    essential: Object.values(lockSkills).filter(
      (skill) => skill.scopeClass === 'global-controlled' && skill.globalTier === 'essential'
    ).length,
    useful: Object.values(lockSkills).filter(
      (skill) => skill.scopeClass === 'global-controlled' && skill.globalTier === 'useful'
    ).length,
    noise: Object.values(lockSkills).filter(
      (skill) => skill.scopeClass === 'global-controlled' && skill.globalTier === 'noise'
    ).length
  };
  controlledGlobalCounts.activeTotal = controlledGlobalCounts.essential + controlledGlobalCounts.useful;

  const externalManagedCounts = {
    total: 0,
    core: 0,
    supplemental: 0,
    archived: 0,
    defaultVisible: 0
  };
  const projectScopedCounts = {
    total: 0,
    core: 0,
    supplemental: 0,
    archived: 0
  };

  for (const skill of Object.values(lockSkills)) {
    if (skill.scopeClass === 'global-external') {
      externalManagedCounts.total += 1;
      externalManagedCounts[skill.tier] += 1;
      if (skill.defaultDiscovery) externalManagedCounts.defaultVisible += 1;
    } else if (skill.scopeClass === 'project') {
      projectScopedCounts.total += 1;
      projectScopedCounts[skill.tier] += 1;
    }
  }

  const summary = {
    totalSkills: Object.keys(lockSkills).length,
    core: tierIndex.core.length,
    supplemental: tierIndex.supplemental.length,
    archived: tierIndex.archived.length,
    categories: Object.fromEntries(
      Object.entries(categoryIndex)
        .map(([category, skills]) => [category, skills.length])
        .sort((a, b) => a[0].localeCompare(b[0]))
    ),
    uncategorized: (categoryIndex.uncategorized || []).length,
    divergentDuplicates: divergentDuplicateCount,
    shadowedDuplicates: shadowedDuplicateCount
  };

  return {
    discoveryOrder,
    manifestSkills,
    lockSkills,
    categoryIndex,
    tierIndex,
    globalTierIndex,
    cleanupCandidates: uniqueCleanupCandidates,
    policyArchivedSkills: uniquePolicyArchivedSkills,
    familySummary,
    consolidationCandidates,
    controlledGlobalCounts,
    externalManagedCounts,
    projectScopedCounts,
    summary
  };
}

function moveControlledArchived(cleanupCandidates) {
  const trashBase = path.join(ROOT, cleanupPolicies.trashDir, TODAY);
  ensureDir(trashBase);

  const moveCandidates = cleanupCandidates.filter(
    (candidate) =>
      candidate.scopeClass === 'global-controlled' &&
      candidate.absoluteDir &&
      fs.existsSync(candidate.absoluteDir)
  );

  const moved = [];

  for (const candidate of moveCandidates) {
    const scopeBucket = candidate.scope.replace(/[^a-z0-9_-]/gi, '_');
    const targetDir = path.join(trashBase, scopeBucket);
    ensureDir(targetDir);
    const destination = ensureUniqueDestination(path.join(targetDir, candidate.skillId));
    fs.renameSync(candidate.absoluteDir, destination);
    moved.push({
      skillId: candidate.skillId,
      scope: candidate.scope,
      scopeClass: candidate.scopeClass,
      family: candidate.family,
      category: candidate.category,
      location: candidate.location,
      archivedTo: destination,
      reason: candidate.reason
    });
  }

  return moved;
}

const firstInventory = buildInventory();
const firstPass = curateInventory(firstInventory);
const movedSkills = cleanupPolicies.moveControlledArchived ? moveControlledArchived(firstPass.cleanupCandidates) : [];
const archivedInventory = readTrashInventory().map((entry) => {
  const family = detectFamily(entry.skillId);
  const scope = entry.scope || 'antigravity-global';
  return {
    ...entry,
    family,
    category: inferCategory(entry.skillId, scope),
    reason:
      findArchivedPatternReason(entry.skillId) ||
      findGlobalDisallowedReason(entry.skillId, family) ||
      'controlled_global_noise_archived'
  };
});
const finalInventory = movedSkills.length > 0 ? buildInventory() : firstInventory;
const finalPass = curateInventory(finalInventory, archivedInventory);

const manifest = {
  _meta: {
    description: 'Inventario generado de skills. Disco y MCP son la fuente de verdad; este archivo es cache derivado para discovery rapido.',
    lastUpdated: TODAY,
    version: 'v8.2.1',
    generatedBy: 'scripts/sync-skills-registry.sh',
    curationConfig: 'config/skills-curation.json'
  },
  discoveryOrder: finalPass.discoveryOrder,
  logicalFamilies,
  capTargets: {
    essential: Number(globalCaps.essential || 25),
    useful: Number(globalCaps.useful || 80),
    activeTotal: Number(globalCaps.essential || 25) + Number(globalCaps.useful || 80)
  },
  controlledGlobalCounts: finalPass.controlledGlobalCounts,
  index: {
    workspace: '.agents/skills/ — Project-scoped Antigravity skills.',
    workspace_gemini_native: '.gemini/skills/ — Project-scoped Gemini compatibility skills.',
    workspace_legacy: '.agent/skills/ — Legacy project fallback scope.',
    antigravity_global: '~/.gemini/antigravity/skills/ — Controlled global Antigravity skills.',
    gemini_global: '~/.gemini/skills/ — Controlled global Gemini-compatible scope.',
    codex: '~/.codex/skills/ — External-managed global scope; hidden from default discovery except required/core exceptions.',
    agents_host: '~/.agents/skills/ — External-managed global scope; hidden from default discovery except required/core exceptions.',
    mcp: 'Capacidades MCP disponibles en runtime.',
    community: 'Busqueda semantica remota para adquisicion controlada.'
  },
  skills: finalPass.manifestSkills,
  categoryIndex: finalPass.categoryIndex,
  tierIndex: finalPass.tierIndex,
  globalTierIndex: finalPass.globalTierIndex
};

const lock = {
  _meta: {
    schemaVersion: 3,
    lastSynced: TODAY,
    generatedBy: 'scripts/sync-skills-registry.sh',
    discoveryOrder: finalPass.discoveryOrder,
    curationConfig: 'config/skills-curation.json'
  },
  capTargets: manifest.capTargets,
  controlledGlobalCounts: finalPass.controlledGlobalCounts,
  skills: finalPass.lockSkills
};

const reportPath = path.isAbsolute(reportConfig.path)
  ? reportConfig.path
  : path.join(ROOT, reportConfig.path);
ensureDir(path.dirname(reportPath));

const report = {
  _meta: {
    generatedBy: 'scripts/sync-skills-registry.sh',
    lastUpdated: TODAY,
    curationConfig: 'config/skills-curation.json',
    trashDir: cleanupPolicies.trashDir
  },
  summary: finalPass.summary,
  capTargets: manifest.capTargets,
  controlledGlobalCounts: finalPass.controlledGlobalCounts,
  externalManagedCounts: finalPass.externalManagedCounts,
  projectScopedCounts: finalPass.projectScopedCounts,
  forcedArchivedFamilies: Array.from(globalArchivedFamilies).sort((a, b) => a.localeCompare(b)),
  policyArchivedSkills: finalPass.policyArchivedSkills,
  cleanupCandidates: finalPass.cleanupCandidates,
  movedSkills,
  familySummary: finalPass.familySummary,
  consolidationCandidates: finalPass.consolidationCandidates,
  uncategorizedSkills: finalPass.categoryIndex.uncategorized || [],
  protectedSkillIds: Array.from(protectedSkillIds).sort((a, b) => a.localeCompare(b)),
  globalOverflow: {
    essential: Math.max(0, finalPass.controlledGlobalCounts.essential - manifest.capTargets.essential),
    useful: Math.max(0, finalPass.controlledGlobalCounts.useful - manifest.capTargets.useful),
    activeTotal: Math.max(0, finalPass.controlledGlobalCounts.activeTotal - manifest.capTargets.activeTotal)
  }
};

fs.writeFileSync(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`);
fs.writeFileSync(lockPath, `${JSON.stringify(lock, null, 2)}\n`);
fs.writeFileSync(reportPath, `${JSON.stringify(report, null, 2)}\n`);
