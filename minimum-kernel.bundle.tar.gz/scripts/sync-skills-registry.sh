#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-$HOME/.gemini}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

node "$SCRIPT_DIR/sync-skills-registry.js" "$ROOT"
