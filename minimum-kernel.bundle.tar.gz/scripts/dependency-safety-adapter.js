#!/usr/bin/env node
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const HOME = os.homedir();

function usage(exitCode = 0) {
  const stream = exitCode === 0 ? process.stdout : process.stderr;
  stream.write(`Usage:
  dependency-safety-adapter.sh [--root PATH] doctor [--json] [--offline]
  dependency-safety-adapter.sh [--root PATH] install-guard
  dependency-safety-adapter.sh [--root PATH] resolve-command npx [--json]
  dependency-safety-adapter.sh [--root PATH] validate-npx-command --command PATH [--json]
  dependency-safety-adapter.sh [--root PATH] package-info --package NAME@VERSION
  dependency-safety-adapter.sh [--root PATH] approve-package --package NAME@VERSION --reason TEXT [--agent-tool] [--dry-run]
  dependency-safety-adapter.sh [--root PATH] run-npx [--dry-run] -- ARGS...
  dependency-safety-adapter.sh [--root PATH] run-tool npm|pnpm -- ARGS...
`);
  process.exit(exitCode);
}

function parseGlobalArgs(argv) {
  const out = {
    root: process.env.KERNEL_ROOT || process.cwd(),
    command: '',
    args: []
  };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (!out.command && arg === '--root') {
      out.root = argv[++i] || out.root;
      continue;
    }
    if (!out.command && (arg === '-h' || arg === '--help')) {
      usage(0);
    }
    if (!out.command) {
      out.command = arg;
      out.args = argv.slice(i + 1);
      break;
    }
  }
  out.root = path.resolve(out.root);
  return out;
}

function readJsonSafe(filePath, fallback = {}) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return fallback;
  }
}

function writeJsonAtomic(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const tmp = `${filePath}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, `${JSON.stringify(value, null, 2)}\n`);
  fs.renameSync(tmp, filePath);
}

function executable(filePath) {
  try {
    fs.accessSync(filePath, fs.constants.X_OK);
    return true;
  } catch {
    return false;
  }
}

function configPath(root) {
  return path.join(root, 'config', 'dependency-safety.json');
}

function projectAllowlistPath(root) {
  return path.join(root, 'state', 'dependency-package-allowlist.json');
}

function loadConfig(root) {
  const defaults = {
    schemaVersion: 1,
    minimumReleaseAgeHours: 24,
    agentToolReleaseAgeHours: 72,
    blockLatest: true,
    blockGlobalNpmInstalls: true,
    disableSkillsTelemetry: true,
    portableGuard: {
      relativeBinDir: '.kernel/dependency-safety/bin',
      statePath: '.kernel/dependency_safety.local.json'
    },
    skillsCli: {
      name: 'skills',
      version: '1.5.6'
    },
    approvedPackages: []
  };
  return {
    ...defaults,
    ...readJsonSafe(configPath(root), {})
  };
}

function portableBinDir(root, config = loadConfig(root)) {
  return path.join(root, config.portableGuard?.relativeBinDir || '.kernel/dependency-safety/bin');
}

function portableNpx(root, config = loadConfig(root)) {
  return path.join(portableBinDir(root, config), process.platform === 'win32' ? 'npx.cmd' : 'npx');
}

function externalNpmSafetyHome() {
  if (process.env.DEPENDENCY_SAFETY_IGNORE_EXTERNAL === '1') return null;
  const candidate = process.env.NPM_SAFETY_HOME || path.join(HOME, '.npm-safety');
  const npxPath = path.join(candidate, 'bin', 'npx');
  const allowlistPath = path.join(candidate, 'allowlist.json');
  if (executable(npxPath) && fs.existsSync(allowlistPath)) {
    return candidate;
  }
  return null;
}

function externalAllowlistPackages() {
  const home = externalNpmSafetyHome();
  if (!home) return [];
  return readJsonSafe(path.join(home, 'allowlist.json'), { packages: [] }).packages || [];
}

function approvedPackages(root) {
  const config = loadConfig(root);
  const local = readJsonSafe(projectAllowlistPath(root), { packages: [] }).packages || [];
  return [
    ...(config.approvedPackages || []),
    ...local,
    ...externalAllowlistPackages()
  ];
}

function normalizePackageSpec(spec) {
  if (!spec || spec.startsWith('-')) return null;
  if (spec.startsWith('@')) {
    const parts = spec.split('@');
    if (parts.length >= 3 && parts[2]) {
      return { name: `@${parts[1]}`, version: parts.slice(2).join('@') };
    }
    return { name: spec, version: '' };
  }
  const parts = spec.split('@');
  if (parts.length >= 2 && parts[1]) {
    return { name: parts[0], version: parts.slice(1).join('@') };
  }
  return { name: spec, version: '' };
}

function packageSpec(pkg) {
  return `${pkg.name}@${pkg.version}`;
}

function collectNpxPackages(argv) {
  const specs = [];
  let packageFlagSeen = false;
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--') continue;
    if (arg === '-p' || arg === '--package') {
      packageFlagSeen = true;
      if (argv[i + 1]) specs.push(argv[i + 1]);
      i += 1;
      continue;
    }
    if (arg.startsWith('--package=')) {
      packageFlagSeen = true;
      specs.push(arg.slice('--package='.length));
      continue;
    }
    if (arg === '-y' || arg === '--yes') continue;
    if (!arg.startsWith('-')) {
      if (!packageFlagSeen) specs.push(arg);
      break;
    }
  }
  return specs.map(normalizePackageSpec).filter(Boolean);
}

function validatePackageSpec(spec, root) {
  const config = loadConfig(root);
  const pkg = typeof spec === 'string' ? normalizePackageSpec(spec) : spec;
  if (!pkg) return { ok: false, reason: 'missing package spec' };
  if (!pkg.version) return { ok: false, reason: `${pkg.name} must use an exact version` };
  if (pkg.version === 'latest' || /@latest(?:$|[^A-Za-z0-9._-])/.test(`${pkg.name}@${pkg.version}`)) {
    return { ok: false, reason: `${pkg.name}@latest is blocked` };
  }
  if (config.blockLatest && pkg.version.toLowerCase() === 'latest') {
    return { ok: false, reason: `${pkg.name}@latest is blocked` };
  }
  return { ok: true, package: pkg };
}

function packageApproved(pkg, root) {
  return approvedPackages(root).some((entry) =>
    entry && entry.name === pkg.name && entry.version === pkg.version && entry.version && entry.version !== 'latest'
  );
}

function cleanPath(root) {
  const external = externalNpmSafetyHome();
  const blocked = new Set([
    portableBinDir(root),
    external ? path.join(external, 'bin') : ''
  ].filter(Boolean).map((entry) => path.resolve(entry)));
  return (process.env.PATH || '')
    .split(path.delimiter)
    .filter(Boolean)
    .filter((entry) => !blocked.has(path.resolve(entry)))
    .join(path.delimiter);
}

function findRealBinary(name, root) {
  for (const dir of cleanPath(root).split(path.delimiter).filter(Boolean)) {
    const candidate = path.join(dir, name);
    if (executable(candidate)) return candidate;
  }
  return null;
}

function run(binary, args, root, extraEnv = {}) {
  const result = spawnSync(binary, args, {
    env: {
      ...process.env,
      ...extraEnv,
      PATH: cleanPath(root)
    },
    cwd: root,
    stdio: 'inherit',
    shell: false
  });
  if (result.error) {
    console.error(`dependency-safety: failed to execute ${binary}: ${result.error.message}`);
    process.exit(1);
  }
  process.exit(result.status ?? 1);
}

function npmView(root, args) {
  const npm = findRealBinary('npm', root);
  if (!npm) throw new Error('real npm binary not found');
  const result = spawnSync(npm, ['view', ...args], {
    env: { ...process.env, PATH: cleanPath(root) },
    encoding: 'utf8',
    shell: false
  });
  if (result.status !== 0) {
    throw new Error((result.stderr || result.stdout || 'npm view failed').trim());
  }
  return result.stdout.trim();
}

function packageInfo(root, spec) {
  const pkg = normalizePackageSpec(spec);
  if (!pkg || !pkg.name || !pkg.version) throw new Error(`invalid package spec: ${spec}`);
  const raw = npmView(root, [`${pkg.name}@${pkg.version}`, 'name', 'version', 'time', 'dist.integrity', 'repository', '--json']);
  const parsed = JSON.parse(raw);
  return {
    name: parsed.name || pkg.name,
    version: parsed.version || pkg.version,
    publishedAt: parsed.time?.[pkg.version] || null,
    integrity: parsed.dist?.integrity || parsed['dist.integrity'] || null,
    repository: typeof parsed.repository === 'string' ? parsed.repository : parsed.repository?.url || null
  };
}

function ageHours(isoTime) {
  if (!isoTime) return 0;
  const ms = Date.now() - Date.parse(isoTime);
  return Number.isFinite(ms) ? ms / 36e5 : 0;
}

function commandName(argv) {
  for (const arg of argv) {
    if (!arg.startsWith('-')) return arg;
  }
  return argv[0] || '';
}

function hasFlag(argv, shortName, longName) {
  return argv.some((arg) => arg === shortName || arg === longName || arg.startsWith(`${longName}=`));
}

function resolveGuardCommand(root, tool) {
  const config = loadConfig(root);
  const external = externalNpmSafetyHome();
  if (external) {
    const candidate = path.join(external, 'bin', tool);
    if (executable(candidate)) return { command: candidate, source: 'external-npm-safety' };
  }
  const portable = path.join(portableBinDir(root, config), process.platform === 'win32' ? `${tool}.cmd` : tool);
  return { command: portable, source: executable(portable) ? 'portable-guard' : 'portable-guard-missing' };
}

function isKnownGuardCommand(root, commandPath) {
  const resolved = commandPath === 'npx'
    ? resolveOnCurrentPath('npx')
    : commandPath;
  if (!resolved) return false;
  const absolute = path.resolve(resolved);
  const known = [portableNpx(root)];
  const external = externalNpmSafetyHome();
  if (external) known.push(path.join(external, 'bin', 'npx'));
  return known.some((candidate) => path.resolve(candidate) === absolute);
}

function resolveOnCurrentPath(name) {
  for (const dir of (process.env.PATH || '').split(path.delimiter).filter(Boolean)) {
    const candidate = path.join(dir, name);
    if (executable(candidate)) return candidate;
  }
  return null;
}

function commandDoctor(root, args) {
  const json = args.includes('--json');
  const config = loadConfig(root);
  const issues = [];
  const warnings = [];
  const external = externalNpmSafetyHome();
  const guard = resolveGuardCommand(root, 'npx');
  const packages = approvedPackages(root);

  if (!fs.existsSync(configPath(root))) issues.push(`missing config: ${configPath(root)}`);
  if (!fs.existsSync(projectAllowlistPath(root))) issues.push(`missing package allowlist: ${projectAllowlistPath(root)}`);
  if (!findRealBinary('npm', root)) issues.push('real npm is unavailable after removing guard paths from PATH');
  if (!findRealBinary('npx', root) && !findRealBinary('pnpm', root)) issues.push('real npx or pnpm is unavailable after removing guard paths from PATH');
  if (!external && !executable(portableNpx(root))) {
    issues.push('no active dependency safety guard found; run scripts/dependency-safety-adapter.sh install-guard');
  }

  for (const entry of packages) {
    const check = validatePackageSpec(entry, root);
    if (!check.ok) issues.push(`invalid approved package ${entry.name || '(unknown)'}: ${check.reason}`);
  }

  const skills = config.skillsCli || {};
  const skillsCheck = validatePackageSpec(`${skills.name || 'skills'}@${skills.version || ''}`, root);
  if (!skillsCheck.ok) issues.push(`invalid pinned skills CLI: ${skillsCheck.reason}`);
  if (!packageApproved({ name: skills.name || 'skills', version: skills.version || '' }, root)) {
    issues.push(`pinned skills CLI is not approved: ${skills.name || 'skills'}@${skills.version || ''}`);
  }

  const output = {
    ok: issues.length === 0,
    root,
    guard,
    externalGuardHome: external,
    packageAllowlist: projectAllowlistPath(root),
    pinnedSkillsCli: `${skills.name || 'skills'}@${skills.version || ''}`,
    issues,
    warnings
  };

  if (json) {
    process.stdout.write(`${JSON.stringify(output, null, 2)}\n`);
  } else {
    for (const issue of issues) console.error(`ERROR: ${issue}`);
    for (const warning of warnings) console.log(`WARN: ${warning}`);
    console.log(`dependency-safety: guard=${guard.command} source=${guard.source}`);
    console.log(`SUMMARY: ${issues.length} error(s), ${warnings.length} warning(s)`);
  }
  process.exit(issues.length === 0 ? 0 : 1);
}

function commandInstallGuard(root) {
  const binDir = portableBinDir(root);
  fs.mkdirSync(binDir, { recursive: true });
  const adapter = path.join(root, 'scripts', 'dependency-safety-adapter.sh');
  const wrappers = {
    npx: `#!/usr/bin/env bash\nset -euo pipefail\nexec ${JSON.stringify(adapter)} --root ${JSON.stringify(root)} run-npx -- "$@"\n`,
    pnpx: `#!/usr/bin/env bash\nset -euo pipefail\nexec ${JSON.stringify(adapter)} --root ${JSON.stringify(root)} run-npx -- "$@"\n`,
    npm: `#!/usr/bin/env bash\nset -euo pipefail\nexec ${JSON.stringify(adapter)} --root ${JSON.stringify(root)} run-tool npm -- "$@"\n`,
    pnpm: `#!/usr/bin/env bash\nset -euo pipefail\nexec ${JSON.stringify(adapter)} --root ${JSON.stringify(root)} run-tool pnpm -- "$@"\n`
  };
  for (const [name, content] of Object.entries(wrappers)) {
    const target = path.join(binDir, name);
    fs.writeFileSync(target, content, { mode: 0o755 });
    fs.chmodSync(target, 0o755);
  }
  const adapterJs = path.join(root, 'scripts', 'dependency-safety-adapter.js');
  const cmdWrappers = {
    'npx.cmd': `@echo off\r\nnode "${adapterJs}" --root "${root}" run-npx -- %*\r\n`,
    'pnpx.cmd': `@echo off\r\nnode "${adapterJs}" --root "${root}" run-npx -- %*\r\n`,
    'npm.cmd': `@echo off\r\nnode "${adapterJs}" --root "${root}" run-tool npm -- %*\r\n`,
    'pnpm.cmd': `@echo off\r\nnode "${adapterJs}" --root "${root}" run-tool pnpm -- %*\r\n`
  };
  for (const [name, content] of Object.entries(cmdWrappers)) {
    fs.writeFileSync(path.join(binDir, name), content);
  }
  writeJsonAtomic(path.join(root, loadConfig(root).portableGuard?.statePath || '.kernel/dependency_safety.local.json'), {
    schemaVersion: 1,
    installedAt: new Date().toISOString(),
    guardBinDir: binDir,
    npx: portableNpx(root)
  });
  console.log(`dependency-safety: portable guard installed at ${binDir}`);
}

function commandRunNpx(root, args) {
  const dryRun = args.includes('--dry-run');
  const filteredArgs = args.filter((arg) => arg !== '--dry-run');
  const sep = filteredArgs.indexOf('--');
  const remoteArgs = filteredArgs.slice(sep >= 0 ? sep + 1 : 0);
  if (remoteArgs.length === 0) {
    console.error('dependency-safety: run-npx requires arguments after --');
    process.exit(1);
  }
  const packages = collectNpxPackages(remoteArgs);
  if (packages.length === 0) {
    console.error('dependency-safety: remote execution requires a package spec');
    process.exit(1);
  }
  const errors = [];
  for (const pkg of packages) {
    const check = validatePackageSpec(pkg, root);
    if (!check.ok) {
      errors.push(check.reason);
      continue;
    }
    if (!packageApproved(pkg, root)) errors.push(`${packageSpec(pkg)} is not approved for remote execution`);
  }
  if (remoteArgs.some((arg) => /@latest(?:$|[^A-Za-z0-9._-])/.test(arg))) {
    errors.push('@latest is blocked for remote execution');
  }
  if (errors.length > 0) {
    for (const error of errors) console.error(`dependency-safety: ${error}`);
    process.exit(77);
  }

  if (dryRun) {
    process.stdout.write(`${JSON.stringify({ ok: true, dryRun: true, packages, command: ['npx', ...remoteArgs] }, null, 2)}\n`);
    return;
  }

  const extraEnv = loadConfig(root).disableSkillsTelemetry ? { DISABLE_TELEMETRY: '1' } : {};
  const pnpm = findRealBinary('pnpm', root);
  if (pnpm) {
    const translated = [];
    for (let i = 0; i < remoteArgs.length; i += 1) {
      const arg = remoteArgs[i];
      if (arg === '-y' || arg === '--yes') continue;
      if (arg === '-p') {
        translated.push('--package');
        if (remoteArgs[i + 1]) translated.push(remoteArgs[++i]);
        continue;
      }
      translated.push(arg);
    }
    return run(pnpm, ['dlx', ...translated], root, extraEnv);
  }
  const npx = findRealBinary('npx', root);
  if (!npx) {
    console.error('dependency-safety: real npx not found');
    process.exit(1);
  }
  return run(npx, remoteArgs, root, extraEnv);
}

function commandRunTool(root, args) {
  const tool = args.shift();
  const sep = args.indexOf('--');
  const toolArgs = sep >= 0 ? args.slice(sep + 1) : args;
  if (!tool || !['npm', 'pnpm'].includes(tool)) {
    console.error('dependency-safety: run-tool supports npm or pnpm');
    process.exit(1);
  }
  const cmd = commandName(toolArgs);
  if (tool === 'npm') {
    if (['exec', 'x', 'create'].includes(cmd)) {
      console.error(`dependency-safety: npm ${cmd} may download and execute remote packages; use run-npx with exact approved versions`);
      process.exit(77);
    }
    if ((cmd === 'install' || cmd === 'i' || cmd === 'add') && hasFlag(toolArgs, '-g', '--global')) {
      console.error('dependency-safety: global npm installs are blocked');
      process.exit(77);
    }
    if (cmd === 'audit' && toolArgs.includes('fix')) {
      console.error('dependency-safety: npm audit fix mutates dependencies automatically');
      process.exit(77);
    }
  }
  if (tool === 'pnpm') {
    if (cmd === 'dlx') return commandRunNpx(root, ['--', ...toolArgs.slice(toolArgs.indexOf(cmd) + 1)]);
    if (cmd === 'create') {
      console.error('dependency-safety: pnpm create may download and execute remote packages');
      process.exit(77);
    }
  }
  const real = findRealBinary(tool, root);
  if (!real) {
    console.error(`dependency-safety: real ${tool} not found`);
    process.exit(1);
  }
  return run(real, toolArgs, root);
}

function commandApprovePackage(root, args) {
  let spec = '';
  let reason = '';
  let agentTool = false;
  let dryRun = false;
  for (let i = 0; i < args.length; i += 1) {
    if (args[i] === '--package') spec = args[++i] || '';
    else if (args[i] === '--reason') reason = args[++i] || '';
    else if (args[i] === '--agent-tool') agentTool = true;
    else if (args[i] === '--dry-run') dryRun = true;
  }
  const pkg = normalizePackageSpec(spec);
  const check = validatePackageSpec(pkg, root);
  if (!check.ok) {
    console.error(`dependency-safety: ${check.reason}`);
    process.exit(1);
  }
  if (!reason) {
    console.error('dependency-safety: approve-package requires --reason');
    process.exit(1);
  }

  let info;
  try {
    info = packageInfo(root, spec);
  } catch (error) {
    console.error(`dependency-safety: ${error.message}`);
    process.exit(1);
  }
  const config = loadConfig(root);
  const requiredAge = agentTool ? Number(config.agentToolReleaseAgeHours || 72) : Number(config.minimumReleaseAgeHours || 24);
  const actualAge = ageHours(info.publishedAt);
  if (actualAge < requiredAge) {
    console.error(`dependency-safety: ${spec} is too new (${actualAge.toFixed(1)}h < ${requiredAge}h)`);
    process.exit(77);
  }
  const entry = {
    name: pkg.name,
    version: pkg.version,
    integrity: info.integrity,
    repository: info.repository,
    publishedAt: info.publishedAt,
    approvedAt: new Date().toISOString(),
    reason,
    agentTool
  };
  if (dryRun) {
    process.stdout.write(`${JSON.stringify({ ok: true, dryRun: true, entry }, null, 2)}\n`);
    return;
  }
  const filePath = projectAllowlistPath(root);
  const allowlist = readJsonSafe(filePath, { schemaVersion: 1, packages: [] });
  allowlist.schemaVersion = allowlist.schemaVersion || 1;
  allowlist.packages = (allowlist.packages || []).filter((item) => !(item.name === entry.name && item.version === entry.version));
  allowlist.packages.push(entry);
  writeJsonAtomic(filePath, allowlist);
  process.stdout.write(`${JSON.stringify({ ok: true, entry, path: filePath }, null, 2)}\n`);
}

function main() {
  const parsed = parseGlobalArgs(process.argv.slice(2));
  const { root, command, args } = parsed;
  switch (command) {
    case 'doctor':
      return commandDoctor(root, args);
    case 'install-guard':
      return commandInstallGuard(root);
    case 'resolve-command': {
      const tool = args[0] || 'npx';
      const json = args.includes('--json');
      const result = resolveGuardCommand(root, tool);
      if (json) process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
      else process.stdout.write(`${result.command}\n`);
      return;
    }
    case 'validate-npx-command': {
      let commandPath = '';
      const json = args.includes('--json');
      for (let i = 0; i < args.length; i += 1) {
        if (args[i] === '--command') commandPath = args[++i] || '';
      }
      const ok = isKnownGuardCommand(root, commandPath);
      const result = { ok, command: commandPath, reason: ok ? 'known guarded npx command' : 'npx command is not a known dependency safety guard' };
      if (json) process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
      else process.stdout.write(`${ok ? 'OK' : 'ERROR'}: ${result.reason}\n`);
      process.exit(ok ? 0 : 1);
      return;
    }
    case 'package-info': {
      const idx = args.indexOf('--package');
      const spec = idx >= 0 ? args[idx + 1] : '';
      process.stdout.write(`${JSON.stringify(packageInfo(root, spec), null, 2)}\n`);
      return;
    }
    case 'approve-package':
      return commandApprovePackage(root, args);
    case 'run-npx':
      return commandRunNpx(root, args);
    case 'run-tool':
      return commandRunTool(root, args);
    default:
      usage(command ? 1 : 0);
  }
}

main();
