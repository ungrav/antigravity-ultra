#!/usr/bin/env node
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');

function parseArgs(argv) {
  const args = {
    root: process.env.ROOT || path.join(os.homedir(), '.gemini'),
    task: '',
    paths: [],
    lane: 'standard',
    json: false
  };

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    switch (arg) {
      case '--root':
        args.root = argv[++i];
        break;
      case '--task':
        args.task = argv[++i] || '';
        break;
      case '--paths':
      case '--path':
        args.paths.push(...splitPathInput(argv[++i] || ''));
        break;
      case '--lane':
        args.lane = argv[++i] || 'standard';
        break;
      case '--json':
        args.json = true;
        break;
      case '-h':
      case '--help':
        usage(0);
        break;
      default:
        if (!arg.startsWith('--')) {
          args.paths.push(...splitPathInput(arg));
        } else {
          console.error(`Unexpected argument: ${arg}`);
          usage(1);
        }
    }
  }

  if (!['fast_local', 'standard', 'deep_audit'].includes(args.lane)) {
    console.error(`Unsupported --lane: ${args.lane}`);
    usage(1);
  }

  args.root = path.resolve(args.root);
  args.paths = Array.from(new Set(args.paths.filter(Boolean)));
  return args;
}

function usage(code) {
  const stream = code === 0 ? process.stdout : process.stderr;
  stream.write(`Usage:
  resolve-capability-context.js --task TEXT [--paths PATHS] [--lane fast_local|standard|deep_audit] [--json]

Description:
  Resolves project-local skills, global curated skills, and MCP capability
  candidates for a task. It never installs skills or enables MCP servers.
`);
  process.exit(code);
}

function splitPathInput(raw) {
  return String(raw)
    .split(/[,;\n]/)
    .map((part) => part.trim())
    .filter(Boolean);
}

function readJsonSafe(filePath, fallback = {}) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return fallback;
  }
}

function normalize(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();
}

const synonymMap = {
  agente: ['agent', 'workflow', 'orchestrator'],
  agentes: ['agent', 'workflow', 'orchestrator'],
  arquitectura: ['architecture', 'design', 'kernel'],
  auth: ['auth', 'security'],
  autenticacion: ['auth', 'security'],
  base: ['database', 'postgres'],
  browser: ['browser', 'playwright', 'e2e'],
  datos: ['database', 'postgres'],
  db: ['database', 'postgres'],
  deploy: ['deploy', 'deployment', 'netlify', 'vercel', 'render'],
  despliegue: ['deploy', 'deployment'],
  diseno: ['design', 'ui', 'frontend'],
  docs: ['docs', 'documentation'],
  docker: ['docker', 'container', 'devops'],
  e2e: ['playwright', 'browser', 'testing'],
  frontend: ['frontend', 'react', 'ui', 'design'],
  global: ['global', 'install'],
  habilidad: ['skill', 'skills'],
  habilidades: ['skill', 'skills'],
  instalar: ['install', 'dependency', 'skill'],
  kernel: ['kernel', 'architecture', 'routing'],
  mcp: ['mcp', 'tool', 'capability'],
  memoria: ['memory', 'rag', 'knowledge'],
  migracion: ['migration', 'database'],
  playwright: ['playwright', 'browser', 'e2e'],
  prueba: ['test', 'testing', 'qa'],
  pruebas: ['test', 'testing', 'qa'],
  rollback: ['rollback', 'backup', 'safe-delete'],
  seguridad: ['security', 'auth', 'scan'],
  skill: ['skill', 'skills', 'meta'],
  skills: ['skill', 'skills', 'meta'],
  testing: ['test', 'testing', 'qa'],
  ui: ['ui', 'frontend', 'design'],
  web: ['web', 'frontend', 'browser']
};

function tokenize(task, paths) {
  const base = `${task} ${paths.join(' ')}`;
  const raw = normalize(base)
    .split(/[^a-z0-9:+._-]+/)
    .filter((token) => token.length >= 2);
  const tokens = new Set(raw);

  for (const token of raw) {
    for (const synonym of synonymMap[token] || []) {
      tokens.add(synonym);
    }
  }

  for (const hint of inferPathHints(paths)) {
    tokens.add(hint);
  }

  return Array.from(tokens);
}

function inferPathHints(paths) {
  const hints = new Set();
  for (const rawPath of paths) {
    const value = normalize(rawPath);
    const ext = path.extname(value);
    if (['.tsx', '.jsx', '.css', '.scss'].includes(ext)) {
      ['frontend', 'ui', 'design', 'react'].forEach((hint) => hints.add(hint));
    }
    if (['.ts', '.js', '.tsx', '.jsx'].includes(ext)) {
      ['typescript', 'javascript'].forEach((hint) => hints.add(hint));
    }
    if (['.md', '.mdx'].includes(ext)) {
      ['docs', 'documentation'].forEach((hint) => hints.add(hint));
    }
    if (['.sql'].includes(ext) || value.includes('migration')) {
      ['database', 'postgres', 'migration'].forEach((hint) => hints.add(hint));
    }
    if (value.includes('docker') || value.endsWith('dockerfile')) {
      ['docker', 'devops', 'container'].forEach((hint) => hints.add(hint));
    }
    if (value.includes('evals/') || value.includes('test') || value.includes('spec')) {
      ['test', 'testing', 'qa'].forEach((hint) => hints.add(hint));
    }
    if (value.includes('mcp')) {
      ['mcp', 'tool', 'external'].forEach((hint) => hints.add(hint));
    }
    if (value.includes('skills')) {
      ['skill', 'skills', 'meta'].forEach((hint) => hints.add(hint));
    }
    if (value.includes('state/') || value.includes('.agent/')) {
      ['state', 'kernel', 'memory'].forEach((hint) => hints.add(hint));
    }
  }
  return Array.from(hints);
}

function fieldText(skillId, skill) {
  return normalize([
    skillId,
    skill.name,
    skill.description,
    skill.category,
    skill.family,
    skill.source,
    skill.preferredLocation
  ].filter(Boolean).join(' '));
}

function scoreSkill(skillId, skill, tokens) {
  const text = fieldText(skillId, skill);
  let score = 0;
  const reasons = [];

  for (const token of tokens) {
    if (!token) continue;
    if (normalize(skillId) === token || normalize(skill.name) === token) {
      score += 5;
      reasons.push(`name:${token}`);
    } else if (text.includes(token)) {
      score += 1;
      reasons.push(`text:${token}`);
    }
    if (normalize(skill.category) === token || normalize(skill.family) === token) {
      score += 3;
      reasons.push(`class:${token}`);
    }
  }

  if (skill.defaultDiscovery) score += 2;
  if (skill.scopeClass === 'project') score += 3;
  if (skill.tier === 'supplemental') score -= 1;
  if (skill.tier === 'archived') score -= 100;

  return { score, reasons: Array.from(new Set(reasons)).slice(0, 6) };
}

function eligibleSkill(skill, score, lane) {
  if (!skill || skill.tier === 'archived') return false;
  if (score <= 0) return false;
  if (lane === 'fast_local') {
    return skill.scopeClass === 'project' || (skill.defaultDiscovery && score >= 7);
  }
  if (lane === 'standard') {
    return skill.defaultDiscovery || skill.scopeClass === 'project' || score >= 4;
  }
  return true;
}

function compactRule(skillId, skill, config) {
  const rule = config?.skillRules?.[skillId]?.compactRule;
  if (rule) return rule;

  const description = String(skill.description || '').replace(/\s+/g, ' ').trim();
  const shortDescription = description.length > 180 ? `${description.slice(0, 177)}...` : description;
  const sourceScope = skill.scopeClass === 'project' ? 'project-local' : skill.scopeClass;
  return `Use ${skill.name || skillId} only when it directly matches the task. ${shortDescription} Scope: ${sourceScope}. Read full SKILL.md only if compact guidance is insufficient.`;
}

function selectSkills(lock, config, tokens, lane) {
  const maxSkills = Number(config?.maxSkillsByLane?.[lane] || (lane === 'fast_local' ? 2 : 5));
  const considered = [];

  for (const [skillId, skill] of Object.entries(lock.skills || {})) {
    const scored = scoreSkill(skillId, skill, tokens);
    if (scored.score <= 0 && lane !== 'deep_audit') continue;
    considered.push({
      id: skillId,
      name: skill.name || skillId,
      category: skill.category || 'general',
      scopeClass: skill.scopeClass || 'unknown',
      tier: skill.tier || 'unknown',
      defaultDiscovery: Boolean(skill.defaultDiscovery),
      preferredLocation: skill.preferredLocation || null,
      score: scored.score,
      reasons: scored.reasons
    });
  }

  considered.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    const aProject = a.scopeClass === 'project' ? 1 : 0;
    const bProject = b.scopeClass === 'project' ? 1 : 0;
    if (bProject !== aProject) return bProject - aProject;
    return a.id.localeCompare(b.id);
  });

  const selected = [];
  for (const item of considered) {
    const skill = lock.skills[item.id];
    if (!eligibleSkill(skill, item.score, lane)) continue;
    selected.push({
      ...item,
      source: skill.source || null,
      trust: skill.trust || null,
      compact_rule: compactRule(item.id, skill, config)
    });
    if (selected.length >= maxSkills) break;
  }

  return {
    selected,
    considered: considered.slice(0, 15)
  };
}

const mcpHints = {
  playwright: ['playwright', 'browser', 'e2e', 'screenshot', 'ui', 'localhost', 'web'],
  netlify: ['netlify', 'deploy', 'deployment', 'site', 'hosting'],
  'firebase-mcp-server': ['firebase', 'firestore', 'auth', 'hosting', 'database'],
  insforge: ['insforge', 'backend', 'database', 'auth', 'api'],
  notebooklm: ['notebooklm', 'notebook', 'docs', 'research', 'document'],
  StitchMCP: ['stitch', 'google', 'data']
};

function scoreMcp(name, cfg, tokens) {
  const known = new Set(mcpHints[name] || []);
  const text = normalize([name, cfg.command, ...(Array.isArray(cfg.args) ? cfg.args : [])].join(' '));
  let score = 0;
  const reasons = [];
  for (const token of tokens) {
    if (known.has(token)) {
      score += 4;
      reasons.push(`hint:${token}`);
    } else if (text.includes(token)) {
      score += 1;
      reasons.push(`text:${token}`);
    }
  }
  if (tokens.includes('mcp')) score += 1;
  return { score, reasons: Array.from(new Set(reasons)).slice(0, 5) };
}

function hasSecretSurface(cfg) {
  const packed = JSON.stringify({
    args: cfg.args || [],
    env: cfg.env || {},
    headers: cfg.headers || {}
  });
  return /(api[_-]?key|token|secret|authorization|bearer|password)/i.test(packed);
}

function selectMcps(root, tokens, lane, task) {
  const config = readJsonSafe(path.join(root, 'antigravity', 'mcp_config.json'), {});
  const servers = config.mcpServers || {};
  const considered = [];
  const normalizedTask = normalize(task);
  const mcpRequested = tokens.includes('mcp') || /\b(mcp|localhost|screenshot|captura|browser)\b/.test(normalizedTask);

  for (const [name, cfg] of Object.entries(servers)) {
    if (!cfg || typeof cfg !== 'object') continue;
    const scored = scoreMcp(name, cfg, tokens);
    considered.push({
      id: name,
      score: scored.score,
      disabled: cfg.disabled === true,
      has_disabled_tools: Array.isArray(cfg.disabledTools) && cfg.disabledTools.length > 0,
      secret_surface: hasSecretSurface(cfg),
      reasons: scored.reasons
    });
  }

  considered.sort((a, b) => b.score - a.score || a.id.localeCompare(b.id));
  const maxMcps = lane === 'fast_local' ? 1 : 3;
  const threshold = mcpRequested ? 4 : 8;
  const selected = considered
    .filter((item) => item.score >= threshold)
    .slice(0, maxMcps)
    .map((item) => ({
      ...item,
      activation: item.disabled ? 'disabled_candidate' : 'available_candidate',
      requires_confirmation: item.disabled || item.secret_surface || item.has_disabled_tools
    }));

  return { selected, considered: considered.slice(0, 10) };
}

function resolvePolicy(task, skills, mcps) {
  const normalizedTask = normalize(task);
  const requestsGlobalInstall = /\b(global|globally)\b/.test(normalizedTask) && /\b(instal|install|add|agrega)\w*\b/.test(normalizedTask);
  const requestsInstall = /\b(instal|install|add|agrega)\w*\b/.test(normalizedTask);
  const requestsMcpMutation = /\b(enable|disable|activar|desactivar|configurar|editar)\b/.test(normalizedTask) && normalizedTask.includes('mcp');
  const externalWrite = /\b(production|produccion|deploy|publish|publicar|webhook|external|externo)\b/.test(normalizedTask);
  const mcpNeedsConfirmation = mcps.some((item) => item.requires_confirmation);

  if (requestsGlobalInstall) {
    return {
      decision: 'CONFIRM',
      policy_id: 'global_skill_install_review',
      trace_level: 'high',
      reason: 'Global skill installation is outside the project scope and requires explicit confirmation.'
    };
  }
  if (requestsInstall) {
    return {
      decision: 'CONFIRM',
      policy_id: 'project_skill_install_review',
      trace_level: 'standard',
      reason: 'Skill acquisition may change project files and must pass the trust gate.'
    };
  }
  if (requestsMcpMutation || externalWrite || mcpNeedsConfirmation) {
    return {
      decision: 'CONFIRM',
      policy_id: requestsMcpMutation ? 'mcp_runtime_change_review' : 'external_capability_review',
      trace_level: 'high',
      reason: 'MCP activation, secrets, disabled tools, or external surfaces require confirmation before mutation.'
    };
  }

  return {
    decision: 'AUTO',
    policy_id: 'local_capability_resolution',
    trace_level: 'minimal',
    reason: 'Resolution is read-only and project-local; no install or external mutation is requested.'
  };
}

function buildWarnings(args, skills, mcps, policy) {
  const warnings = [];
  const normalizedTask = normalize(args.task);
  if (skills.selected.length === 0 && args.lane !== 'fast_local') {
    warnings.push('no_local_skill_match; live discovery may be useful, but it was not run by this resolver');
  }
  if (/\b(global|globally)\b/.test(normalizedTask) && /\b(instal|install|add|agrega)\w*\b/.test(normalizedTask)) {
    warnings.push('global_install_requires_explicit_user_request_and_confirmation');
  }
  if (/\b(instal|install|add|agrega)\w*\b/.test(normalizedTask) && !/\b(global|globally)\b/.test(normalizedTask)) {
    warnings.push('project_local_install_is_default; use scripts/skill-trust-gate.sh install after discovery, audit, and trust approval');
  }
  if (mcps.selected.some((item) => item.disabled)) {
    warnings.push('selected_mcp_is_disabled_candidate; do not enable without confirmation');
  }
  if (policy.decision === 'CONFIRM') {
    warnings.push(`policy_gate:${policy.policy_id}`);
  }
  return warnings;
}

function projectStandardsBlock(result) {
  const lines = [
    '## Project Standards (auto-resolved)',
    `- Capability resolution: ${result.capability_resolution_status}. Lane: ${result.lane}.`,
    '- Use compact rules first. Read full SKILL.md only when compact guidance is insufficient.',
    '- Project-local skill install is the default; use scripts/skill-trust-gate.sh for skills.sh discovery, audit, approval, and install. Global install requires explicit user request and confirmation.',
    '- Delegated agents receive ownership, limits, expected output, and these compact rules; they should not rediscover the whole skill tree.'
  ];

  if (result.skills_selected.length > 0) {
    lines.push('', '### Skills');
    for (const skill of result.skills_selected) {
      lines.push(`- ${skill.id}: ${skill.compact_rule}`);
    }
  }

  if (result.mcp_selected.length > 0) {
    lines.push('', '### MCP Candidates');
    for (const mcp of result.mcp_selected) {
      lines.push(`- ${mcp.id}: ${mcp.activation}; confirmation=${mcp.requires_confirmation ? 'yes' : 'no'}; use only for the matching task surface.`);
    }
  }

  lines.push('', `Policy: ${result.policy_decision.decision} (${result.policy_decision.policy_id}) - ${result.policy_decision.reason}`);
  return lines.join('\n');
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const lock = readJsonSafe(path.join(args.root, 'skills-lock.json'), { skills: {} });
  const curation = readJsonSafe(path.join(args.root, 'config', 'skills-curation.json'), {});
  const routerConfig = curation.capabilityRouter || {};
  const tokens = tokenize(args.task, args.paths);
  const skills = selectSkills(lock, routerConfig, tokens, args.lane);
  const mcps = selectMcps(args.root, tokens, args.lane, args.task);
  const policy = resolvePolicy(args.task, skills.selected, mcps.selected);

  const result = {
    root: args.root,
    lane: args.lane,
    task: args.task,
    paths: args.paths,
    skills_queries: tokens.slice(0, 40),
    skills_selected: skills.selected,
    skills_considered: skills.considered,
    mcp_selected: mcps.selected,
    mcp_considered: mcps.considered,
    policy_decision: policy,
    capability_resolution_status: skills.selected.length > 0 || mcps.selected.length > 0 ? 'injected' : 'none',
    warnings: []
  };

  result.warnings = buildWarnings(args, skills, mcps, policy);
  result.project_standards_block = projectStandardsBlock(result);

  if (args.json) {
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
    return;
  }

  process.stdout.write(`${result.project_standards_block}\n`);
  if (result.warnings.length > 0) {
    process.stdout.write(`\nWarnings:\n${result.warnings.map((warning) => `- ${warning}`).join('\n')}\n`);
  }
}

main();
