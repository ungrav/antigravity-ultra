#!/usr/bin/env python3
import argparse
import json
import pathlib
import re
import sys
from typing import Any, Optional


TASK_CLASSES = ("code_local", "incident", "architecture", "kernel_audit", "memory_kernel", "recovery")
ESCALATION_CHOICES = TASK_CLASSES + ("auto",)

RECOVERY_RE = re.compile(
    r"\b(recover|recovery|restore|bootstrap|portable|portability|bundle|blueprints?|snapshot|degraded|corrupt|missing state|"
    r"recuperar|restaurar|arranque|portatil|portabilidad|respaldo|degradado|corrupto)\b",
    re.I,
)
MEMORY_KERNEL_RE = re.compile(
    r"\b(memory[_ -]?kernel|read[_ -]?contract|resolve[_ -]?read[_ -]?context|resolver|rag|retrieval|telemetry|inbox|"
    r"project dna|knowledge|ki|kis|vault|MEMORY\.md|GEMINI\.md|AGENTS\.md|current_state|memoria|conocimiento|contrato de lectura)\b",
    re.I,
)
KERNEL_AUDIT_RE = re.compile(
    r"\b(kernel audit|critical audit|audit (?:this |the |of (?:this |the )?)?(?:current )?(?:antigravity )?(?:ops[- ]?)?kernel|"
    r"critically evaluate (?:this |the )?(?:system|architecture|kernel)|"
    r"review (?:this |the )?(?:ops[- ]?)?kernel architecture|improve antigravity|kernel complexity|"
    r"(?:system|kernel) improvement plan|evaluate (?:the )?(?:health|complexity|architecture) of (?:the )?(?:antigravity )?(?:ops[- ]?)?kernel|"
    r"audita(?:r)?(?: profundamente)? (?:este |el )?kernel|auditor[ií]a (?:del |de este )?kernel|"
    r"eval[uú]a(?:r)? cr[ií]ticamente (?:este |el )?(?:sistema|kernel)|qu[eé] opinas (?:de |del )?(?:este )?kernel|"
    r"qu[eé] opinas de esta arquitectura|c[oó]mo mejorar antigravity|"
    r"revisa(?:r)? la complejidad (?:del |de este )?(?:ops[- ]?)?kernel)\b",
    re.I,
)
KERNEL_DOMAIN_RE = re.compile(r"\b(antigravity|ops[- ]?kernel|agent kernel|kernel del sistema)\b", re.I)
KERNEL_REVIEW_INTENT_RE = re.compile(
    r"\b(audit|critique|critical review|evaluate|assessment|health|complexity|improve|improvement|recommendations?|"
    r"audita(?:r)?|auditor[ií]a|cr[ií]tica|eval[uú]a(?:r)?|opini[oó]n|salud|complejidad|mejorar|mejora(?:s)?|recomendaciones?)\b",
    re.I,
)
INCIDENT_RE = re.compile(
    r"\b(incident|regression|repeated failure|postmortem|outage|root cause|rollback|sev[0-9]?|"
    r"incidente|regresion|regresión|fallo repetido|causa raiz|causa raíz)\b",
    re.I,
)
BUG_LIKE_RE = re.compile(
    r"\b(bug|bugfix|broken|failing|failure|error|exception|crash|doesn'?t work|not working|fix|"
    r"fall[ao]|falla|fallando|error|excepcion|excepción|crashea|no funciona|arregla|arreglar|bot[oó]n)\b",
    re.I,
)
ARCHITECTURE_RE = re.compile(
    r"\b(architecture|architectural|refactor|migration|api|api contract|boundary|schema|feature|design system|"
    r"kernel audit|implementation audit|runtime health|architecture review|"
    r"arquitectura|refactor|migraci[oó]n|contrato|esquema|feature|funcionalidad|"
    r"auditor[ií]a|salud del runtime|revisa(?:r)? (?:bien )?(?:si )?el plan)\b",
    re.I,
)
CODE_LOCAL_RE = re.compile(
    r"\b(update|edit|rename|copy|docs?|label|button|ui|style|test|local|small|minor|typo|"
    r"actualiza|editar|renombrar|texto|etiqueta|bot[oó]n|local|pequeñ[oa]|menor)\b",
    re.I,
)


def fail(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


def load_contract(root: pathlib.Path) -> dict[str, Any]:
    path = root / "state" / "read_contract.json"
    if not path.exists():
        fail(f"Missing read contract: {path}")
    try:
        contract = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        fail(f"Invalid read contract JSON: {exc}")
    if "sunset_aliases" in contract:
        fail("read_contract.json contains sunset_aliases; use state/compat_contract.json")
    return contract


def classify_detail(task: str) -> dict[str, Any]:
    normalized = task.strip()
    if KERNEL_AUDIT_RE.search(normalized) or (
        KERNEL_DOMAIN_RE.search(normalized) and KERNEL_REVIEW_INTENT_RE.search(normalized)
    ):
        return {
            "task_class": "kernel_audit",
            "preflight_probes": [],
            "confidence": 0.96,
            "ambiguous": False,
            "classification_signals": ["kernel_audit"],
        }
    if RECOVERY_RE.search(normalized):
        return {
            "task_class": "recovery",
            "preflight_probes": [],
            "confidence": 0.95,
            "ambiguous": False,
            "classification_signals": ["recovery"],
        }
    if MEMORY_KERNEL_RE.search(normalized):
        return {
            "task_class": "memory_kernel",
            "preflight_probes": [],
            "confidence": 0.95,
            "ambiguous": False,
            "classification_signals": ["memory_kernel"],
        }
    if INCIDENT_RE.search(normalized):
        return {
            "task_class": "incident",
            "preflight_probes": [],
            "confidence": 0.9,
            "ambiguous": False,
            "classification_signals": ["incident"],
        }
    if ARCHITECTURE_RE.search(normalized):
        return {
            "task_class": "architecture",
            "preflight_probes": [],
            "confidence": 0.88,
            "ambiguous": False,
            "classification_signals": ["architecture"],
        }
    if BUG_LIKE_RE.search(normalized):
        return {
            "task_class": "code_local",
            "preflight_probes": ["incident_sniff"],
            "confidence": 0.62,
            "ambiguous": True,
            "classification_signals": ["bug_like"],
        }
    if CODE_LOCAL_RE.search(normalized):
        return {
            "task_class": "code_local",
            "preflight_probes": [],
            "confidence": 0.86,
            "ambiguous": False,
            "classification_signals": ["code_local"],
        }
    return {
        "task_class": "code_local",
        "preflight_probes": ["incident_sniff"],
        "confidence": 0.45,
        "ambiguous": True,
        "classification_signals": ["low_signal_default"],
    }


def classify(task: str) -> tuple[str, list[str]]:
    detail = classify_detail(task)
    return detail["task_class"], list(detail["preflight_probes"])


def surfaces(entries: list[dict[str, Any]]) -> list[str]:
    return [str(entry["surface"]) for entry in entries]


def resolve(
    root: pathlib.Path,
    profile: str,
    task: str,
    escalate_to: Optional[str] = None,
    reason: str = "",
) -> dict[str, Any]:
    contract = load_contract(root)
    profiles = contract.get("profiles", {})
    if profile not in profiles:
        fail(f"Unknown profile: {profile}")

    classifier_detail = classify_detail(task)
    classifier_task_class = classifier_detail["task_class"]
    classifier_probes = list(classifier_detail["preflight_probes"])
    if escalate_to:
        if escalate_to not in ESCALATION_CHOICES:
            fail(f"Unknown escalation task class: {escalate_to}")
        if not reason.strip():
            fail("--reason is required when --escalate-to is used")
        if escalate_to == "auto":
            auto_detail = classify_detail(f"{task}\n{reason}")
            task_class = auto_detail["task_class"]
            classifier_detail = auto_detail
            classifier_probes = list(auto_detail["preflight_probes"])
            escalation_source = "auto"
        else:
            task_class = escalate_to
            escalation_source = "explicit"
    else:
        task_class = classifier_task_class
        escalation_source = "classifier"

    if task_class not in contract.get("jit_expansions", {}):
        fail(f"Read contract missing task class: {task_class}")

    profile_contract = profiles[profile]
    jit = contract["jit_expansions"][task_class]
    if escalate_to and escalate_to != "auto" and task_class != classifier_task_class:
        preflight_probes = []
    else:
        configured_probes = [probe for probe in jit.get("preflight_probes", []) if probe in classifier_probes]
        preflight_probes = configured_probes or classifier_probes
    ambiguous = bool(classifier_detail["ambiguous"])
    confidence = float(classifier_detail["confidence"])
    allowed_surfaces = list(jit.get("allowed_surfaces", []))
    if ambiguous and task_class == "code_local":
        orientation_surface = "PROJECT_HISTORY.md (latest 1-3 entries)"
        if orientation_surface not in allowed_surfaces:
            allowed_surfaces.append(orientation_surface)
    if escalation_source == "auto":
        recommended_action = f"Auto-escalated to {task_class}; use allowed_surfaces and re-run with an explicit class if evidence disagrees."
    elif ambiguous:
        recommended_action = "Use incident_sniff and latest PROJECT_HISTORY.md entries as orientation before choosing a stronger escalation."
    elif escalation_source == "explicit":
        recommended_action = f"Use explicit {task_class} allowed_surfaces for the stated reason."
    else:
        recommended_action = "Proceed with the resolver allowlist."

    return {
        "schema_version": 1,
        "contract_version": contract.get("contract_version"),
        "profile": profile,
        "task_class": task_class,
        "classifier_task_class": classifier_task_class,
        "escalation_source": escalation_source,
        "escalation_reason": reason.strip(),
        "confidence": confidence,
        "ambiguous": ambiguous,
        "classification_signals": list(classifier_detail["classification_signals"]),
        "recommended_action": recommended_action,
        "baseline_surfaces": surfaces(profile_contract.get("read_order", [])),
        "allowed_surfaces": allowed_surfaces,
        "forbidden_surfaces": list(jit.get("keep_out", [])),
        "preflight_probes": preflight_probes,
        "probe_contracts": {
            name: contract.get("preflight_probes", {}).get(name, {})
            for name in preflight_probes
        },
    }


def render_human(result: dict[str, Any]) -> str:
    lines = [
        f"profile: {result['profile']}",
        f"task_class: {result['task_class']}",
        f"classifier_task_class: {result['classifier_task_class']}",
        f"escalation_source: {result['escalation_source']}",
        f"escalation_reason: {result['escalation_reason']}",
        f"confidence: {result['confidence']}",
        f"ambiguous: {str(result['ambiguous']).lower()}",
        f"recommended_action: {result['recommended_action']}",
        "classification_signals:",
        *[f"- {item}" for item in result["classification_signals"]],
        "baseline_surfaces:",
        *[f"- {item}" for item in result["baseline_surfaces"]],
        "allowed_surfaces:",
        *[f"- {item}" for item in result["allowed_surfaces"]],
        "forbidden_surfaces:",
        *[f"- {item}" for item in result["forbidden_surfaces"]],
        "preflight_probes:",
        *[f"- {item}" for item in result["preflight_probes"]],
    ]
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=str(pathlib.Path(__file__).resolve().parents[1]))
    parser.add_argument("--profile", choices=("native", "external"), default="external")
    parser.add_argument("--task", required=True)
    parser.add_argument("--escalate-to", choices=ESCALATION_CHOICES, default=None)
    parser.add_argument("--reason", default="")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    result = resolve(
        pathlib.Path(args.root).expanduser().resolve(),
        args.profile,
        args.task,
        args.escalate_to,
        args.reason,
    )
    if args.json:
        json.dump(result, sys.stdout, ensure_ascii=False, indent=2)
        sys.stdout.write("\n")
    else:
        sys.stdout.write(render_human(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
