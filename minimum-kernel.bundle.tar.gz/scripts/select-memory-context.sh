#!/usr/bin/env bash
set -euo pipefail

exec python3 - "$@" <<'PY'
import argparse
import ast
import json
import time
from pathlib import Path


def parse_args():
    parser = argparse.ArgumentParser(description="Select active Antigravity memory context without mutating the vault.")
    parser.add_argument("--vault", default=".agent/knowledge")
    parser.add_argument("--limit", type=int, default=5)
    parser.add_argument("--token-budget", type=int, default=1200)
    parser.add_argument("--tenant-domain", default="")
    parser.add_argument("--category", action="append", default=[])
    return parser.parse_args()


def parse_scalar(raw):
    raw = raw.strip()
    if raw == "":
        return ""
    if raw in {"true", "false"}:
        return raw == "true"
    if raw in {"null", "None"}:
        return None
    if raw.startswith("[") and raw.endswith("]"):
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            try:
                return ast.literal_eval(raw)
            except (ValueError, SyntaxError):
                return raw
    if raw.startswith('"') and raw.endswith('"'):
        return json.loads(raw)
    if raw.startswith("'") and raw.endswith("'"):
        return raw[1:-1]
    try:
        if "." in raw:
            return float(raw)
        return int(raw)
    except ValueError:
        return raw


def parse_markdown(path):
    text = path.read_text(encoding="utf-8", errors="ignore")
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}, text
    meta = {}
    end = None
    for idx, line in enumerate(lines[1:], start=1):
        if line.strip() == "---":
            end = idx
            break
        if not line.strip() or line.lstrip().startswith("#") or ":" not in line:
            continue
        key, value = line.split(":", 1)
        meta[key.strip()] = parse_scalar(value)
    body = "\n".join(lines[end + 1 :]) if end is not None else text
    return meta, body


def first_section(body):
    kept = []
    for line in body.splitlines():
        if line.startswith("## ") and kept:
            break
        if line.strip():
            kept.append(line.strip())
        if len(kept) >= 8:
            break
    return "\n".join(kept)[:900]


def estimate_tokens(text):
    return max(1, int(len(text) / 4))


def is_inbox(vault, path):
    try:
        rel = path.relative_to(vault)
    except ValueError:
        return False
    return len(rel.parts) > 1 and rel.parts[0] == "inbox"


def family_for_category(category, kind=""):
    families = {"architecture", "incidents", "ecosystem", "research", "context"}
    if category in families:
        return category
    mapping = {
        "decision": "architecture",
        "pattern": "architecture",
        "api_contract": "architecture",
        "schema_migration": "architecture",
        "bug": "incidents",
        "bug_resolution": "incidents",
        "debug_dead_end": "incidents",
        "test_insight": "incidents",
        "dependency": "ecosystem",
        "config": "ecosystem",
        "research": "research",
        "conclusion": "research",
        "skill_insight": "research",
        "context_state": "context",
    }
    return mapping.get(category, mapping.get(kind, category or "context"))


def selection_reason(meta, category, tenant_domain, requested_domain):
    parts = [f"family:{family_for_category(category, str(meta.get('kind', '')))}"]
    if requested_domain and tenant_domain == requested_domain:
        parts.append("tenant_domain_match")
    if meta.get("entities"):
        parts.append("entities_present")
    return ", ".join(parts)


def main():
    args = parse_args()
    vault = Path(args.vault).expanduser().resolve()
    categories = set(args.category)
    candidates = []
    excluded = {"inbox_or_draft": 0, "status": 0, "filter": 0}

    if vault.exists():
        for path in sorted(vault.rglob("*.md")):
            if path.name.startswith("."):
                continue
            meta, body = parse_markdown(path)
            status = str(meta.get("status", ""))
            if is_inbox(vault, path) or status == "draft":
                excluded["inbox_or_draft"] += 1
                continue
            if status != "active":
                excluded["status"] += 1
                continue
            category = str(meta.get("category", ""))
            kind = str(meta.get("kind", category))
            tenant_domain = str(meta.get("tenant_domain", ""))
            family = family_for_category(category, kind)
            if categories and category not in categories and kind not in categories and family not in categories:
                excluded["filter"] += 1
                continue
            if args.tenant_domain and tenant_domain != args.tenant_domain:
                excluded["filter"] += 1
                continue
            summary = first_section(body)
            candidates.append(
                {
                    "path": str(path.relative_to(vault)),
                    "category": category,
                    "kind": kind,
                    "family": family,
                    "tenant_domain": tenant_domain,
                    "timestamp": int(meta.get("timestamp", 0) or 0),
                    "reason": selection_reason(meta, category, tenant_domain, args.tenant_domain),
                    "_tokens": estimate_tokens(summary),
                }
            )

    candidates.sort(key=lambda item: (item["timestamp"], item["path"]), reverse=True)
    selected = []
    used_tokens = 0
    for item in candidates:
        if len(selected) >= max(0, args.limit):
            break
        if used_tokens + item["_tokens"] > args.token_budget and selected:
            continue
        used_tokens += item["_tokens"]
        selected.append(
            {
                "path": item["path"],
                "category": item["category"],
                "kind": item["kind"],
                "family": item["family"],
                "reason": item["reason"],
            }
        )

    payload = {
        "version": 1,
        "generated_at": int(time.time()),
        "vault": str(vault),
        "selection_policy": "active_only_excluding_inbox_simple",
        "limit": args.limit,
        "token_budget": args.token_budget,
        "estimated_tokens": used_tokens,
        "selected_kis": selected,
        "excluded_counts": excluded,
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
PY
