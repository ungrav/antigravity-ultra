#!/usr/bin/env bash
set -euo pipefail

exec python3 - "$@" <<'PY'
import argparse
import ast
import json
import re
import time
import unicodedata
from pathlib import Path


def parse_args():
    parser = argparse.ArgumentParser(description="Select active Antigravity memory context without mutating the vault.")
    parser.add_argument("--root", default="", help="Project root; defaults to the current directory.")
    parser.add_argument("--vault", default="", help="Memory vault path; defaults to <root>/.agent/knowledge.")
    parser.add_argument("--query", default="", help="Natural-language task or question to rank relevant KIs.")
    parser.add_argument("--limit", type=int, default=5)
    parser.add_argument("--token-budget", type=int, default=1200)
    parser.add_argument("--tenant-domain", default="")
    parser.add_argument("--category", action="append", default=[])
    return parser.parse_args()


def normalize(text):
    decomposed = unicodedata.normalize("NFKD", str(text))
    asciiish = "".join(ch for ch in decomposed if not unicodedata.combining(ch))
    return asciiish.lower()


def query_terms(query):
    return [term for term in re.findall(r"[a-z0-9_./-]{3,}", normalize(query)) if term not in {"the", "and", "for", "con", "para", "que", "por", "los", "las"}]


def parse_scalar(raw):
    raw = raw.strip()
    if raw == "":
        return ""
    if raw in {"true", "false"}:
        return raw == "true"
    if raw in {"null", "None"}:
        return None
    if raw.startswith("[") and raw.endswith("]"):
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            try:
                return ast.literal_eval(raw)
            except (ValueError, SyntaxError):
                return raw
    if raw.startswith('"') and raw.endswith('"'):
        return json.loads(raw)
    if raw.startswith("'") and raw.endswith("'"):
        return raw[1:-1]
    try:
        if "." in raw:
            return float(raw)
        return int(raw)
    except ValueError:
        return raw


def parse_markdown(path):
    text = path.read_text(encoding="utf-8", errors="ignore")
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}, text
    meta = {}
    end = None
    for idx, line in enumerate(lines[1:], start=1):
        if line.strip() == "---":
            end = idx
            break
        if not line.strip() or line.lstrip().startswith("#") or ":" not in line:
            continue
        key, value = line.split(":", 1)
        meta[key.strip()] = parse_scalar(value)
    body = "\n".join(lines[end + 1 :]) if end is not None else text
    return meta, body


def title_from_body(body, fallback):
    for line in body.splitlines():
        if line.startswith("# "):
            return line[2:].strip() or fallback
    return fallback


def first_section(body):
    kept = []
    in_summary = False
    for line in body.splitlines():
        stripped = line.strip()
        if stripped == "## Summary":
            in_summary = True
            continue
        if in_summary and stripped.startswith("## "):
            break
        if stripped:
            kept.append(stripped)
        if len(kept) >= 8:
            break
    return "\n".join(kept)[:900]


def estimate_tokens(text):
    return max(1, int(len(text) / 4))


def is_inbox(vault, path):
    try:
        rel = path.relative_to(vault)
    except ValueError:
        return False
    return len(rel.parts) > 1 and rel.parts[0] == "inbox"


def is_archived_path(vault, path):
    try:
        rel = path.relative_to(vault)
    except ValueError:
        rel = path
    return any(part.startswith("_DEPRECATED_TRASH") or part in {"archive", "archived"} for part in rel.parts)


def family_for_category(category, kind=""):
    families = {"architecture", "incidents", "ecosystem", "research", "context"}
    if category in families:
        return category
    mapping = {
        "decision": "architecture",
        "pattern": "architecture",
        "api_contract": "architecture",
        "schema_migration": "architecture",
        "bug": "incidents",
        "bug_resolution": "incidents",
        "debug_dead_end": "incidents",
        "test_insight": "incidents",
        "dependency": "ecosystem",
        "config": "ecosystem",
        "research": "research",
        "conclusion": "research",
        "audit": "research",
        "skill_insight": "research",
        "context_state": "context",
        "handoff": "context",
    }
    return mapping.get(category, mapping.get(kind, category or "context"))


def as_list(value):
    if isinstance(value, list):
        return [str(item) for item in value]
    if value in (None, ""):
        return []
    return [str(value)]


def exact_match_types(item, query_norm):
    if not query_norm:
        return []
    matches = []
    exact_values = {
        "ki_id_exact": normalize(item["ki_id"]),
        "path_exact": normalize(item["path"]),
        "title_exact": normalize(item["title"]),
    }
    for match_type, value in exact_values.items():
        if value and query_norm == value:
            matches.append(match_type)
    if any(query_norm == normalize(alias) for alias in item["aliases"]):
        matches.append("alias_exact")
    return matches


def score_candidate(item, terms, query):
    score = 0
    reasons = [f"family:{item['family']}"]
    match_types = []
    query_norm = normalize(query).strip()
    searchable_parts = [
        item["ki_id"],
        item["path"],
        item["category"],
        item["kind"],
        item["family"],
        item["tenant_domain"],
        item["title"],
        item["summary"],
        " ".join(item["entities"]),
        " ".join(item["aliases"]),
    ]
    searchable = normalize(" ".join(searchable_parts))
    title_norm = normalize(item["title"])
    summary_norm = normalize(item["summary"])

    exact_matches = exact_match_types(item, query_norm)
    if exact_matches:
        score += 100
        match_types.extend(exact_matches)
        reasons.extend(exact_matches)

    if query_norm and query_norm in searchable:
        score += 10
        reasons.append("query_phrase")
        match_types.append("phrase")

    matched_terms = []
    for term in terms:
        if term in searchable:
            score += 2
            matched_terms.append(term)
        if term in title_norm:
            score += 3
            match_types.append("title_term")
        if term in summary_norm:
            score += 1
        if term in normalize(item["tenant_domain"]):
            score += 5
            reasons.append("tenant_domain_match")
            match_types.append("tenant_domain")
        if term in normalize(item["kind"]) or term in normalize(item["category"]) or term in normalize(item["family"]):
            score += 4
            match_types.append("category_or_kind")
        if any(term in normalize(entity) for entity in item["entities"]):
            score += 6
            reasons.append("entity_match")
            match_types.append("entity")
        if any(term in normalize(alias) for alias in item["aliases"]):
            score += 8
            reasons.append("alias_match")
            match_types.append("alias")

    if matched_terms:
        shown = ", ".join(matched_terms[:3])
        reasons.append(f"query_match:{shown}")
    if not matched_terms and not query_norm:
        reasons.append("recency")

    return score, ", ".join(dict.fromkeys(reasons)), list(dict.fromkeys(match_types))


def main():
    args = parse_args()
    root = Path(args.root or ".").expanduser().resolve()
    vault = Path(args.vault).expanduser().resolve() if args.vault else (root / ".agent" / "knowledge").resolve()
    categories = set(args.category)
    terms = query_terms(args.query)
    candidates = []
    excluded = {"archived_or_trash": 0, "inbox_or_draft": 0, "status": 0, "filter": 0}

    if vault.exists():
        for path in sorted(vault.rglob("*.md")):
            if path.name.startswith("."):
                continue
            if is_archived_path(vault, path):
                excluded["archived_or_trash"] += 1
                continue
            meta, body = parse_markdown(path)
            status = str(meta.get("status", ""))
            if is_inbox(vault, path) or status == "draft":
                excluded["inbox_or_draft"] += 1
                continue
            if status != "active":
                excluded["status"] += 1
                continue
            category = str(meta.get("category", ""))
            kind = str(meta.get("kind", category))
            tenant_domain = str(meta.get("tenant_domain", ""))
            family = family_for_category(category, kind)
            if categories and category not in categories and kind not in categories and family not in categories:
                excluded["filter"] += 1
                continue
            if args.tenant_domain and tenant_domain != args.tenant_domain:
                excluded["filter"] += 1
                continue
            summary = first_section(body)
            title = title_from_body(body, path.stem)
            rel_path = str(path.relative_to(vault))
            item = {
                "ki_id": str(meta.get("ki_id", "")),
                "path": rel_path,
                "category": category,
                "kind": kind,
                "family": family,
                "tenant_domain": tenant_domain,
                "entities": as_list(meta.get("entities")),
                "aliases": as_list(meta.get("aliases")),
                "related_kis": as_list(meta.get("related_kis")),
                "timestamp": int(meta.get("timestamp", 0) or 0),
                "title": title,
                "summary": summary,
                "_tokens": estimate_tokens(title + "\n" + summary),
            }
            item["_score"], item["reason"], item["match_types"] = score_candidate(item, terms, args.query)
            candidates.append(item)

    by_id = {item["ki_id"]: item for item in candidates if item["ki_id"]}
    for source in [item for item in candidates if item["_score"] > 0]:
        for related_id in source["related_kis"]:
            related = by_id.get(related_id)
            if related is None or related is source:
                continue
            related_score = max(1, source["_score"] // 4)
            if related_score > related["_score"]:
                related["_score"] = related_score
                related["related_from"] = source["ki_id"]
                related["match_types"] = list(dict.fromkeys(related["match_types"] + ["related_ki"]))
                related["reason"] = f"{related['reason']}, related_from:{source['ki_id']}"

    candidates.sort(key=lambda item: (item["_score"], item["timestamp"], item["path"]), reverse=True)
    selected = []
    used_tokens = 0
    for item in candidates:
        if len(selected) >= max(0, args.limit):
            break
        if used_tokens + item["_tokens"] > args.token_budget and selected:
            continue
        if args.query.strip() and item["_score"] <= 0:
            continue
        used_tokens += item["_tokens"]
        selected.append(
            {
                "ki_id": item["ki_id"],
                "path": item["path"],
                "category": item["category"],
                "kind": item["kind"],
                "family": item["family"],
                "tenant_domain": item["tenant_domain"],
                "match_types": item["match_types"],
                "related_from": item.get("related_from"),
                "reason": item["reason"],
                "query_score": item["_score"],
                "token_estimate": item["_tokens"],
            }
        )

    payload = {
        "version": 3,
        "generated_at": int(time.time()),
        "root": str(root),
        "vault": str(vault),
        "query": args.query,
        "selection_policy": "active_only_exact_alias_entity_related_query_ranked",
        "limit": args.limit,
        "token_budget": args.token_budget,
        "estimated_tokens": used_tokens,
        "selected_kis": selected,
        "excluded_counts": excluded,
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
PY
