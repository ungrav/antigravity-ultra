#!/usr/bin/env node
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawnSync } = require('child_process');

function usage(exitCode = 0) {
  const stream = exitCode === 0 ? process.stdout : process.stderr;
  stream.write(`Usage:
  skill-trust-gate.sh [--root PATH] discover --task TEXT [--paths LIST] [--lane fast_local|standard|deep_audit] [--execute] [--force-external]
  skill-trust-gate.sh [--root PATH] ensure-find-skills [--execute]
  skill-trust-gate.sh [--root PATH] audit --source-url URL --skill-id ID [--staged-dir PATH] [--deep] [--execute]
  skill-trust-gate.sh [--root PATH] approve --source-url URL --repo REPO --skill-id ID --sha256 HASH --risk low|moderate|high --audit-status pass|warn|fail [--dry-run]
  skill-trust-gate.sh [--root PATH] install --source-url URL --skill-id ID [--global] [--explicit-user-approval] [--dry-run]
`);
  process.exit(exitCode);
}

function parseGlobalArgs(argv) {
  const out = {
    root: process.env.KERNEL_ROOT || process.cwd(),
    command: '',
    args: []
  };
  const rest = [];
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--root') {
      out.root = argv[++i] || out.root;
    } else if (arg === '-h' || arg === '--help') {
      usage(0);
    } else {
      rest.push(arg);
    }
  }
  out.root = path.resolve(out.root);
  out.command = rest.shift() || '';
  out.args = rest;
  return out;
}

function readJsonSafe(filePath, fallback = {}) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return fallback;
  }
}

function writeJsonAtomic(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const tmp = `${filePath}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, `${JSON.stringify(value, null, 2)}\n`);
  fs.renameSync(tmp, filePath);
}

function splitList(raw) {
  return String(raw || '')
    .split(/[,;\n]/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function dependencyAdapter(root) {
  return path.join(root, 'scripts', 'dependency-safety-adapter.sh');
}

function dependencyConfig(root) {
  return readJsonSafe(path.join(root, 'config', 'dependency-safety.json'), {});
}

function skillsCliSpec(root) {
  const cli = dependencyConfig(root).skillsCli || { name: 'skills', version: '1.5.6' };
  return `${cli.name || 'skills'}@${cli.version || '1.5.6'}`;
}

function skillTrustPath(root) {
  return path.join(root, 'state', 'skill-trust-allowlist.json');
}

function resolveContext(root, task, paths, lane) {
  const resolver = path.join(root, 'scripts', 'resolve-capability-context.sh');
  if (!fs.existsSync(resolver)) {
    return { available: false, skills_selected: [], skills_considered: [], warnings: ['resolver unavailable'] };
  }
  const args = ['--root', root, '--task', task, '--lane', lane, '--json'];
  if (paths.length > 0) args.push('--paths', paths.join(','));
  const result = spawnSync(resolver, args, { encoding: 'utf8', shell: false });
  if (result.status !== 0) {
    return { available: false, skills_selected: [], skills_considered: [], warnings: ['resolver failed'] };
  }
  try {
    return { available: true, ...JSON.parse(result.stdout) };
  } catch {
    return { available: false, skills_selected: [], skills_considered: [], warnings: ['resolver returned invalid json'] };
  }
}

function findSkillDirs(root, skillId) {
  const candidates = [
    path.join(root, '.agents', 'skills', skillId),
    path.join(root, '.gemini', 'skills', skillId),
    path.join(root, '.agent', 'skills', skillId),
    path.join(root, 'skills', skillId),
    path.join(os.homedir(), '.gemini', 'antigravity', 'skills', skillId),
    path.join(os.homedir(), '.gemini', 'skills', skillId),
    path.join(os.homedir(), '.codex', 'skills', skillId),
    path.join(os.homedir(), '.agents', 'skills', skillId)
  ];
  return candidates.filter((dir) => fs.existsSync(path.join(dir, 'SKILL.md')));
}

function readTextIfExists(filePath, maxChars = 4000) {
  try {
    return fs.readFileSync(filePath, 'utf8').slice(0, maxChars);
  } catch {
    return '';
  }
}

function packageSummary(root) {
  const packageJson = readJsonSafe(path.join(root, 'package.json'), null);
  if (!packageJson) return null;
  const deps = Object.keys({
    ...(packageJson.dependencies || {}),
    ...(packageJson.devDependencies || {})
  }).slice(0, 40);
  return {
    name: packageJson.name || path.basename(root),
    packageManager: packageJson.packageManager || null,
    scripts: Object.keys(packageJson.scripts || {}).slice(0, 20),
    dependencies: deps
  };
}

function inferDomain(task, paths, pkg) {
  const text = `${task} ${paths.join(' ')} ${(pkg?.dependencies || []).join(' ')}`.toLowerCase();
  const domains = [];
  if (/react|next|tsx|jsx|frontend|ui|css|tailwind/.test(text)) domains.push('frontend');
  if (/test|playwright|jest|vitest|qa|e2e/.test(text)) domains.push('testing');
  if (/deploy|vercel|netlify|render|hosting|ci/.test(text)) domains.push('deployment');
  if (/docker|container|compose|kubernetes/.test(text)) domains.push('devops');
  if (/postgres|database|sql|migration|supabase/.test(text)) domains.push('database');
  if (/mcp|agent|workflow|skill|kernel/.test(text)) domains.push('agent-workflows');
  if (/security|auth|secret|scan|audit/.test(text)) domains.push('security');
  return domains.length > 0 ? domains : ['general-tooling'];
}

function buildSearchBrief(root, task, paths, lane) {
  const state = readJsonSafe(path.join(root, '.agent', 'current_state.json'), {});
  const pkg = packageSummary(root);
  const targetFileHints = paths.slice(0, 12).map((rawPath) => {
    const absolute = path.isAbsolute(rawPath) ? rawPath : path.join(root, rawPath);
    return {
      path: rawPath,
      exists: fs.existsSync(absolute),
      ext: path.extname(rawPath)
    };
  });
  const domain = inferDomain(task, paths, pkg);
  const constraints = [
    'prefer existing skills before creating new skills',
    'install project-local into .agents/skills by default',
    'use skills.sh find-skills for external discovery',
    'audit before install',
    'pin CLI/packages to exact versions; no @latest'
  ];

  return {
    task,
    lane,
    project: state.project || pkg?.name || path.basename(root),
    currentObjective: state.objective || null,
    status: state.status || null,
    domain,
    package: pkg,
    targetFiles: targetFileHints,
    constraints,
    successCriteria: [
      'find a relevant existing skill if one exists',
      'avoid reinventing a skill already present in the ecosystem',
      'do not install until candidates are reviewed and audited'
    ]
  };
}

function queryVariants(brief) {
  const stack = [
    ...(brief.package?.dependencies || []),
    brief.package?.packageManager || ''
  ].filter(Boolean).slice(0, 12).join(' ');
  const fileHints = brief.targetFiles.map((item) => `${item.ext || item.path}`).filter(Boolean).join(' ');
  const domain = brief.domain.join(' ');
  const task = brief.task.replace(/\s+/g, ' ').trim();
  return Array.from(new Set([
    `${task}. Project context: ${domain}; stack: ${stack || 'unknown'}; files: ${fileHints || 'none provided'}; need reusable agent skill, workflow, or tool; prefer high reputation skills.`,
    `${domain} ${task} ${stack}`.trim(),
    `${domain} agent skill workflow ${task}`.trim(),
    `${task} best practices testing automation deployment design docs security`.trim(),
    `${domain} ${fileHints} skill skills.sh`.trim(),
    `${task} habilidad skill agente flujo herramienta existente no reinventar`.trim()
  ].filter((query) => query.length > 0)));
}

function ensureFindSkills(root, execute = false) {
  const found = findSkillDirs(root, 'find-skills');
  const installCommand = [
    dependencyAdapter(root),
    '--root',
    root,
    'run-npx',
    '--',
    '-y',
    skillsCliSpec(root),
    'add',
    'https://github.com/vercel-labs/skills',
    '--skill',
    'find-skills'
  ];
  if (found.length > 0) {
    return {
      present: true,
      sourceUrl: 'https://www.skills.sh/vercel-labs/skills/find-skills',
      localSkillMd: path.join(found[0], 'SKILL.md'),
      installCommand
    };
  }
  if (!execute) {
    return {
      present: false,
      sourceUrl: 'https://www.skills.sh/vercel-labs/skills/find-skills',
      localSkillMd: null,
      installCommand
    };
  }
  const result = spawnSync(installCommand[0], installCommand.slice(1), { encoding: 'utf8', shell: false, cwd: root });
  return {
    present: result.status === 0,
    sourceUrl: 'https://www.skills.sh/vercel-labs/skills/find-skills',
    localSkillMd: null,
    installCommand,
    stdout: result.stdout,
    stderr: result.stderr,
    exitCode: result.status
  };
}

function commandDiscover(root, args) {
  let task = '';
  let paths = [];
  let lane = 'standard';
  let execute = false;
  let forceExternal = false;
  for (let i = 0; i < args.length; i += 1) {
    if (args[i] === '--task') task = args[++i] || '';
    else if (args[i] === '--paths' || args[i] === '--path') paths.push(...splitList(args[++i] || ''));
    else if (args[i] === '--lane') lane = args[++i] || 'standard';
    else if (args[i] === '--execute') execute = true;
    else if (args[i] === '--force-external') forceExternal = true;
  }
  if (!task) {
    console.error('skill-trust-gate: discover requires --task');
    process.exit(1);
  }

  const local = resolveContext(root, task, paths, lane);
  const selected = local.skills_selected || [];
  const strongLocalMatch = selected.some((skill) => skill.scopeClass === 'project' || skill.defaultDiscovery === true);
  const brief = buildSearchBrief(root, task, paths, lane);
  const queries = queryVariants(brief);
  const findSkills = ensureFindSkills(root, execute && (!strongLocalMatch || forceExternal));
  const externalRequired = forceExternal || !strongLocalMatch;
  const plannedFindCommands = externalRequired
    ? queries.map((query) => [
      dependencyAdapter(root),
      '--root',
      root,
      'run-npx',
      '--',
      '-y',
      skillsCliSpec(root),
      'find',
      query
    ])
    : [];

  const executed = [];
  if (execute && externalRequired && findSkills.present) {
    for (const command of plannedFindCommands.slice(0, lane === 'deep_audit' ? 6 : 4)) {
      const result = spawnSync(command[0], command.slice(1), { encoding: 'utf8', shell: false, cwd: root });
      executed.push({
        command,
        exitCode: result.status,
        stdout: result.stdout.slice(0, 4000),
        stderr: result.stderr.slice(0, 2000)
      });
    }
  }

  const output = {
    schemaVersion: 1,
    localRegistryChecked: true,
    localResolverAvailable: Boolean(local.available),
    localSkillsSelected: selected,
    localSkillsConsidered: local.skills_considered || [],
    externalDiscoveryRequired: externalRequired,
    findSkills,
    skillSearchBrief: brief,
    queries,
    plannedFindCommands,
    executed,
    noInstallDuringDiscovery: true,
    createSkillAllowed: false,
    createSkillPolicy: 'Creation is blocked until local registry, find-skills discovery, candidate review, and rejection rationale are recorded.'
  };
  process.stdout.write(`${JSON.stringify(output, null, 2)}\n`);
}

function commandEnsureFindSkills(root, args) {
  process.stdout.write(`${JSON.stringify(ensureFindSkills(root, args.includes('--execute')), null, 2)}\n`);
}

function hashSkillDir(dir) {
  if (!dir || !fs.existsSync(dir)) return null;
  const files = [];
  const walk = (current) => {
    for (const name of fs.readdirSync(current).sort()) {
      const filePath = path.join(current, name);
      const stat = fs.statSync(filePath);
      if (stat.isDirectory()) walk(filePath);
      else files.push(filePath);
    }
  };
  walk(dir);
  const hash = crypto.createHash('sha256');
  for (const file of files) {
    hash.update(path.relative(dir, file));
    hash.update('\0');
    hash.update(fs.readFileSync(file));
    hash.update('\0');
  }
  return hash.digest('hex');
}

function commandAudit(root, args) {
  let sourceUrl = '';
  let skillId = '';
  let stagedDir = '';
  let deep = false;
  let execute = false;
  for (let i = 0; i < args.length; i += 1) {
    if (args[i] === '--source-url') sourceUrl = args[++i] || '';
    else if (args[i] === '--skill-id') skillId = args[++i] || '';
    else if (args[i] === '--staged-dir') stagedDir = args[++i] || '';
    else if (args[i] === '--deep') deep = true;
    else if (args[i] === '--execute') execute = true;
  }
  if (!sourceUrl || !skillId) {
    console.error('skill-trust-gate: audit requires --source-url and --skill-id');
    process.exit(1);
  }
  const scanners = [
    {
      id: 'skillcheck',
      required: true,
      command: [dependencyAdapter(root), '--root', root, 'run-npx', '--', '-y', '@mondoohq/skillcheck@0.2.0', stagedDir || sourceUrl]
    },
    {
      id: 'skillaudit',
      required: false,
      command: [dependencyAdapter(root), '--root', root, 'run-npx', '--', '-y', 'skillaudit@1.1.0', stagedDir || sourceUrl]
    }
  ];
  if (deep) {
    scanners.push({
      id: 'cisco-ai-skill-scanner',
      required: false,
      command: ['python3', '-m', 'cisco_ai_skill_scanner', 'scan', stagedDir || sourceUrl]
    });
  }
  const executed = [];
  if (execute) {
    for (const scanner of scanners) {
      const result = spawnSync(scanner.command[0], scanner.command.slice(1), { encoding: 'utf8', shell: false, cwd: root });
      executed.push({
        id: scanner.id,
        exitCode: result.status,
        stdout: result.stdout.slice(0, 4000),
        stderr: result.stderr.slice(0, 2000)
      });
      if (scanner.required && result.status !== 0) break;
    }
  }
  const output = {
    schemaVersion: 1,
    sourceUrl,
    skillId,
    stagedDir: stagedDir || null,
    stagedSha256: stagedDir ? hashSkillDir(stagedDir) : null,
    scanners,
    executed,
    decision: execute && executed.some((item) => item.exitCode !== 0) ? 'warn_or_fail_review_required' : 'pending_review',
    installAllowed: false
  };
  process.stdout.write(`${JSON.stringify(output, null, 2)}\n`);
}

function commandApprove(root, args) {
  const entry = {
    sourceUrl: '',
    repo: '',
    skillId: '',
    sha256: '',
    risk: '',
    auditStatus: '',
    approvedScopes: ['project'],
    approvedAt: new Date().toISOString()
  };
  let dryRun = false;
  for (let i = 0; i < args.length; i += 1) {
    if (args[i] === '--source-url') entry.sourceUrl = args[++i] || '';
    else if (args[i] === '--repo') entry.repo = args[++i] || '';
    else if (args[i] === '--skill-id') entry.skillId = args[++i] || '';
    else if (args[i] === '--sha256') entry.sha256 = args[++i] || '';
    else if (args[i] === '--risk') entry.risk = args[++i] || '';
    else if (args[i] === '--audit-status') entry.auditStatus = args[++i] || '';
    else if (args[i] === '--scope') entry.approvedScopes = splitList(args[++i] || 'project');
    else if (args[i] === '--dry-run') dryRun = true;
  }
  const missing = Object.entries(entry)
    .filter(([key, value]) => ['sourceUrl', 'repo', 'skillId', 'sha256', 'risk', 'auditStatus'].includes(key) && !value)
    .map(([key]) => key);
  if (missing.length > 0) {
    console.error(`skill-trust-gate: approve missing fields: ${missing.join(', ')}`);
    process.exit(1);
  }
  if (!['low', 'moderate', 'high'].includes(entry.risk)) {
    console.error('skill-trust-gate: risk must be low, moderate, or high');
    process.exit(1);
  }
  if (entry.auditStatus !== 'pass' || entry.risk !== 'low') {
    entry.requiresConfirmation = true;
  }
  if (dryRun) {
    process.stdout.write(`${JSON.stringify({ ok: true, dryRun: true, entry }, null, 2)}\n`);
    return;
  }
  const filePath = skillTrustPath(root);
  const trust = readJsonSafe(filePath, { schemaVersion: 1, skills: [] });
  trust.schemaVersion = trust.schemaVersion || 1;
  trust.skills = (trust.skills || []).filter((item) => !(item.sourceUrl === entry.sourceUrl && item.skillId === entry.skillId));
  trust.skills.push(entry);
  writeJsonAtomic(filePath, trust);
  process.stdout.write(`${JSON.stringify({ ok: true, path: filePath, entry }, null, 2)}\n`);
}

function findApprovedSkill(root, sourceUrl, skillId, globalInstall) {
  const trust = readJsonSafe(skillTrustPath(root), { skills: [] });
  return (trust.skills || []).find((entry) =>
    entry.sourceUrl === sourceUrl &&
    entry.skillId === skillId &&
    entry.auditStatus === 'pass' &&
    entry.risk === 'low' &&
    (entry.approvedScopes || []).includes(globalInstall ? 'global' : 'project')
  );
}

function commandInstall(root, args) {
  let sourceUrl = '';
  let skillId = '';
  let globalInstall = false;
  let explicitApproval = false;
  let dryRun = false;
  for (let i = 0; i < args.length; i += 1) {
    if (args[i] === '--source-url') sourceUrl = args[++i] || '';
    else if (args[i] === '--skill-id') skillId = args[++i] || '';
    else if (args[i] === '--global') globalInstall = true;
    else if (args[i] === '--explicit-user-approval') explicitApproval = true;
    else if (args[i] === '--dry-run') dryRun = true;
  }
  if (!sourceUrl || !skillId) {
    console.error('skill-trust-gate: install requires --source-url and --skill-id');
    process.exit(1);
  }
  if (globalInstall && !explicitApproval) {
    console.error('skill-trust-gate: global skill install requires explicit user approval');
    process.exit(77);
  }
  const approved = findApprovedSkill(root, sourceUrl, skillId, globalInstall);
  if (!approved && !dryRun) {
    console.error('skill-trust-gate: skill is not approved in state/skill-trust-allowlist.json');
    process.exit(77);
  }
  const command = [
    dependencyAdapter(root),
    '--root',
    root,
    'run-npx',
    '--',
    '-y',
    skillsCliSpec(root),
    'add',
    sourceUrl,
    '--skill',
    skillId
  ];
  if (globalInstall) command.push('-g');
  const output = {
    ok: true,
    dryRun,
    installScope: globalInstall ? 'global' : 'project',
    projectLocalDefault: !globalInstall,
    targetScopeHint: globalInstall ? 'user-global' : '.agents/skills',
    command,
    approved: Boolean(approved)
  };
  if (dryRun) {
    process.stdout.write(`${JSON.stringify(output, null, 2)}\n`);
    return;
  }
  const result = spawnSync(command[0], command.slice(1), { encoding: 'utf8', shell: false, cwd: root });
  output.exitCode = result.status;
  output.stdout = result.stdout;
  output.stderr = result.stderr;
  process.stdout.write(`${JSON.stringify(output, null, 2)}\n`);
  process.exit(result.status || 0);
}

function main() {
  const parsed = parseGlobalArgs(process.argv.slice(2));
  switch (parsed.command) {
    case 'discover':
      return commandDiscover(parsed.root, parsed.args);
    case 'ensure-find-skills':
      return commandEnsureFindSkills(parsed.root, parsed.args);
    case 'audit':
      return commandAudit(parsed.root, parsed.args);
    case 'approve':
      return commandApprove(parsed.root, parsed.args);
    case 'install':
      return commandInstall(parsed.root, parsed.args);
    default:
      usage(parsed.command ? 1 : 0);
  }
}

main();
