#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
ELIGIBILITY_CHECK="$ROOT_DIR/evals/checks/check-memory-maintenance-eligibility.sh"
ELIGIBILITY_JSON="$("$ELIGIBILITY_CHECK" "$@")"

if ! jq -e '.eligible' >/dev/null <<<"$ELIGIBILITY_JSON"; then
  printf '%s\n' "$ELIGIBILITY_JSON"
  exit 0
fi

export ELIGIBILITY_JSON

python3 - <<'PY'
import ast
import json
import os
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path


LOCAL_CATEGORY_DIRS = {
    "decision": "architecture",
    "bug_resolution": "incidents",
    "pattern": "architecture",
    "dependency": "ecosystem",
    "context_state": "context",
    "config": "ecosystem",
    "schema_migration": "architecture",
    "test_insight": "incidents",
    "api_contract": "architecture",
    "research": "research",
    "skill_insight": "research",
    "conclusion": "research",
    "handoff": "context",
}

FRONTMATTER_ORDER = [
    "ki_id",
    "memory_scope",
    "stability_class",
    "promotion_state",
    "category",
    "kind",
    "status",
    "is_consolidated",
    "timestamp",
    "last_verified_at",
    "expires_at",
    "tenant_domain",
    "entities",
    "aliases",
    "tags",
    "capture_kind",
    "candidate_category",
    "summary",
    "source_projects",
    "evidence_sources",
    "related_kis",
    "promoted_to",
    "promoted_at",
    "archive_reason",
]


def parse_scalar(raw: str):
    raw = raw.strip()
    if raw == "":
        return ""
    if raw in {"true", "false"}:
        return raw == "true"
    if raw in {"null", "None"}:
        return None
    if raw.startswith("[") and raw.endswith("]"):
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            try:
                return ast.literal_eval(raw)
            except (ValueError, SyntaxError):
                return raw
    if raw.startswith('"') and raw.endswith('"'):
        return json.loads(raw)
    if raw.startswith("'") and raw.endswith("'"):
        return raw[1:-1]
    if re.fullmatch(r"-?\d+", raw):
        return int(raw)
    if re.fullmatch(r"-?\d+\.\d+", raw):
        return float(raw)
    return raw


def parse_markdown(path: Path) -> tuple[dict, str]:
    text = path.read_text(encoding="utf-8", errors="ignore")
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}, text
    meta: dict[str, object] = {}
    body_start = 0
    for idx, line in enumerate(lines[1:], start=1):
        if line.strip() == "---":
            body_start = idx + 1
            break
        if not line.strip() or line.lstrip().startswith("#") or ":" not in line:
            continue
        key, value = line.split(":", 1)
        meta[key.strip()] = parse_scalar(value)
    return meta, "\n".join(lines[body_start:])


def render_value(value) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, list):
        return json.dumps(value, ensure_ascii=False)
    return json.dumps(value, ensure_ascii=False)


def write_markdown(path: Path, meta: dict, body: str) -> None:
    keys = [key for key in FRONTMATTER_ORDER if key in meta]
    keys.extend(key for key in meta if key not in keys)
    lines = ["---"]
    for key in keys:
        lines.append(f"{key}: {render_value(meta[key])}")
    lines.append("---")
    content = "\n".join(lines) + "\n" + body.lstrip("\n").rstrip("\n") + "\n"
    path.write_text(content, encoding="utf-8")


def atomic_write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.tmp.{os.getpid()}")
    tmp.write_text(content, encoding="utf-8")
    os.replace(tmp, path)


def load_kis(vault: Path) -> list[dict]:
    items = []
    for path in sorted(vault.rglob("*.md")):
        if path.name.startswith("."):
            continue
        meta, body = parse_markdown(path)
        if meta:
            items.append({"path": path, "meta": meta, "body": body})
    return items


def active_items(kis: list[dict]) -> list[dict]:
    return [item for item in kis if str(item["meta"].get("status", "")) == "active"]


def first_meaningful_line(body: str) -> str:
    for line in body.splitlines():
        cleaned = line.strip().lstrip("-").strip()
        if cleaned and not cleaned.startswith("#"):
            return cleaned
    return "No summary captured."


def normalize_body(body: str) -> str:
    return re.sub(r"\s+", " ", body.strip().lower())


def entities(item: dict) -> list[str]:
    raw = item["meta"].get("entities", [])
    return [str(entity) for entity in raw] if isinstance(raw, list) else []


def duplicate_signature(item: dict) -> tuple:
    meta = item["meta"]
    return (
        str(meta.get("category", meta.get("stability_class", ""))),
        str(meta.get("kind", "")),
        str(meta.get("tenant_domain", "")),
        tuple(sorted(entities(item))),
        normalize_body(item["body"]),
    )


def supersession_signature(item: dict) -> tuple:
    meta = item["meta"]
    return (
        str(meta.get("category", meta.get("stability_class", ""))),
        str(meta.get("tenant_domain", "")),
        tuple(sorted(entities(item))),
    )


def rank(item: dict) -> tuple:
    meta = item["meta"]
    return (
        int(meta.get("last_verified_at", meta.get("timestamp", 0)) or 0),
        int(meta.get("timestamp", 0) or 0),
        str(meta.get("ki_id", "")),
    )


def choose_keeper(items: list[dict]) -> dict:
    return max(items, key=rank)


def merge_related(keeper: dict, loser_ids: list[str]) -> None:
    existing = keeper["meta"].get("related_kis", [])
    if not isinstance(existing, list):
        existing = []
    merged = list(existing)
    for ki_id in loser_ids:
        if ki_id and ki_id not in merged:
            merged.append(ki_id)
    keeper["meta"]["related_kis"] = merged[:8]


def update_status(item: dict, status: str, now_ts: int, reason: str = "") -> None:
    item["meta"]["status"] = status
    if reason:
        item["meta"]["archive_reason"] = reason
    write_markdown(item["path"], item["meta"], item["body"])
    os.utime(item["path"], (now_ts, now_ts))


def is_inbox_item(vault: Path, item: dict) -> bool:
    try:
        rel = item["path"].relative_to(vault)
    except ValueError:
        return False
    return bool(rel.parts) and rel.parts[0] == "inbox"


def draft_summary(item: dict) -> str:
    summary = str(item["meta"].get("summary", "") or "").strip()
    return summary or first_meaningful_line(item["body"])


def draft_category(item: dict) -> str:
    raw = str(item["meta"].get("candidate_category", "") or "").strip()
    if raw in LOCAL_CATEGORY_DIRS:
        return raw
    if str(item["meta"].get("capture_kind", "") or "") == "debug_dead_end":
        return "conclusion"
    return "conclusion"


def slugify(raw: str, fallback: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", raw.lower()).strip("-")
    return re.sub(r"-+", "-", slug)[:72].strip("-") or fallback


def unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    for idx in range(2, 1000):
        candidate = path.with_name(f"{path.stem}-{idx}{path.suffix}")
        if not candidate.exists():
            return candidate
    raise RuntimeError(f"unable to allocate unique path for {path}")


def promote_draft(vault: Path, draft: dict, now_ts: int) -> Path:
    kind = draft_category(draft)
    family = LOCAL_CATEGORY_DIRS[kind]
    target_dir = vault / family
    target_dir.mkdir(parents=True, exist_ok=True)
    summary = draft_summary(draft)
    dt = datetime.fromtimestamp(int(draft["meta"].get("timestamp", now_ts) or now_ts), tz=timezone.utc)
    path = unique_path(target_dir / f"{dt.strftime('%Y-%m-%d')}_{slugify(summary, 'memory-draft')}.md")
    meta = {
        "ki_id": str(draft["meta"].get("ki_id", path.stem) or path.stem),
        "category": family,
        "kind": kind,
        "status": "active",
        "is_consolidated": False,
        "timestamp": int(draft["meta"].get("timestamp", now_ts) or now_ts),
        "tenant_domain": str(draft["meta"].get("tenant_domain", "general") or "general"),
        "entities": entities(draft),
        "related_kis": draft["meta"].get("related_kis", []) if isinstance(draft["meta"].get("related_kis", []), list) else [],
    }
    body = draft["body"].strip() or f"# {summary}\n\n- {summary}"
    if not body.lstrip().startswith("#"):
        body = f"# {summary}\n\n{body}"
    write_markdown(path, meta, body)
    os.utime(path, (now_ts, now_ts))
    return path


def process_inbox(vault: Path, kis: list[dict], now_ts: int) -> dict:
    actions = {"promoted": 0, "archived": 0}
    for draft in [item for item in kis if is_inbox_item(vault, item) and str(item["meta"].get("status", "")) == "draft"]:
        if not draft_summary(draft) or not entities(draft) or not str(draft["meta"].get("tenant_domain", "") or "").strip():
            update_status(draft, "archived", now_ts, "invalid_draft")
            actions["archived"] += 1
            continue
        promoted = promote_draft(vault, draft, now_ts)
        draft["meta"]["promoted_to"] = str(promoted.relative_to(vault))
        draft["meta"]["promoted_at"] = now_ts
        update_status(draft, "superseded", now_ts)
        actions["promoted"] += 1
    return actions


def build_project_dna(vault: Path, kis: list[dict], now_ts: int) -> tuple[bool, int]:
    def is_structural(item: dict) -> bool:
        kind = str(item["meta"].get("kind", "") or "")
        title = ""
        for line in item["body"].splitlines():
            if line.startswith("# "):
                title = line[2:].strip().lower()
                break
        if kind in {"handoff", "context_state"}:
            return False
        if title.startswith("close session") or title.startswith("cerrar sesión"):
            return False
        return True

    active = [
        item for item in active_items(kis)
        if item["path"].name != ".project_dna.md" and is_structural(item)
    ]
    if not active:
        return False, 0
    ranked = sorted(active, key=rank, reverse=True)
    refs = ranked[:8]
    domains = []
    entity_names = []
    categories = []
    for item in ranked:
        meta = item["meta"]
        domain = str(meta.get("tenant_domain", "") or "")
        category = str(meta.get("category", meta.get("stability_class", "")) or "")
        if domain and domain not in domains:
            domains.append(domain)
        if category and category not in categories:
            categories.append(category)
        for entity in entities(item):
            if entity not in entity_names:
                entity_names.append(entity)
    lines = [
        "# Project DNA",
        "",
        "## Stable Stack",
        f"- Domains: {', '.join(domains[:4]) or 'No domains captured yet.'}",
        f"- Core entities: {', '.join(entity_names[:6]) or 'No entities captured yet.'}",
        f"- Active categories: {', '.join(categories[:4]) or 'No categories captured yet.'}",
        "",
        "## Active Truths",
    ]
    for item in refs[:3]:
        lines.append(f"- {first_meaningful_line(item['body'])}")
    if not refs:
        lines.append("- No active truths captured yet.")
    lines.extend(["", "## Key KIs"])
    for item in refs:
        rel = item["path"].relative_to(vault)
        ki_id = str(item["meta"].get("ki_id", "")) or item["path"].stem
        lines.append(f"- `{rel}` ({ki_id})")
    content = "\n".join(lines[:50]).rstrip() + "\n"
    atomic_write_text(vault / ".project_dna.md", content)
    os.utime(vault / ".project_dna.md", (now_ts, now_ts))
    return True, sum(1 for line in lines[:50] if line.startswith("- `"))


def write_state(path: Path, scope: str, mode: str, reason: str, signal_count: int, now_ts: int) -> None:
    payload = {
        "version": 1,
        "last_run_at": now_ts,
        "last_run_mode": mode,
        "last_reason": reason,
        "last_signal_count": signal_count,
        "last_scope": scope,
    }
    atomic_write_text(path, json.dumps(payload, ensure_ascii=False, indent=2) + "\n")


def count_low_connectivity(kis: list[dict]) -> int:
    count = 0
    for item in active_items(kis):
        related = item["meta"].get("related_kis", [])
        if not isinstance(related, list) or not related:
            count += 1
    return count


def count_alias_candidates(kis: list[dict]) -> int:
    by_key: dict[str, set[str]] = {}
    for item in active_items(kis):
        for entity in entities(item):
            key = re.sub(r"[^a-z0-9]+", "", entity.lower())
            if key:
                by_key.setdefault(key, set()).add(entity)
    return sum(1 for values in by_key.values() if len(values) > 1)


def count_broken_related_kis(kis: list[dict]) -> int:
    known_ids = {
        str(item["meta"].get("ki_id", "") or "")
        for item in kis
        if str(item["meta"].get("ki_id", "") or "")
    }
    broken = 0
    for item in active_items(kis):
        related = item["meta"].get("related_kis", [])
        if not isinstance(related, list):
            continue
        broken += sum(1 for ki_id in related if str(ki_id) not in known_ids)
    return broken


def main() -> int:
    eligibility = json.loads(os.environ["ELIGIBILITY_JSON"])
    scope = eligibility["scope"]
    vault = Path(eligibility["vault"])
    state_path = Path(eligibility["state_path"])
    now_ts = int(eligibility.get("now_ts", int(time.time())))
    mode = eligibility.get("mode", "simple_maintenance")
    reason = eligibility.get("reason", "manual_override")
    signal_count = int(eligibility.get("signal_count", 0) or 0)
    vault.mkdir(parents=True, exist_ok=True)

    kis = load_kis(vault)
    actions = {
        "duplicates_merged": 0,
        "contradictions_resolved": 0,
        "advisories_expired": 0,
        "project_dna_regenerated": False,
        "project_dna_ref_count": 0,
        "consolidated": 0,
        "inbox_drafts_promoted": 0,
        "inbox_drafts_archived": 0,
        "low_connectivity_count": 0,
        "alias_candidate_count": 0,
        "broken_related_kis_count": 0,
        "graph_rebuild_required": False,
    }

    if scope == "local":
        inbox_actions = process_inbox(vault, kis, now_ts)
        actions["inbox_drafts_promoted"] = inbox_actions["promoted"]
        actions["inbox_drafts_archived"] = inbox_actions["archived"]
        if any(inbox_actions.values()):
            actions["graph_rebuild_required"] = True
            kis = load_kis(vault)

    duplicate_groups: dict[tuple, list[dict]] = {}
    for item in active_items(kis):
        duplicate_groups.setdefault(duplicate_signature(item), []).append(item)
    for group in duplicate_groups.values():
        if len(group) < 2:
            continue
        keeper = choose_keeper(group)
        losers = [item for item in group if item is not keeper]
        merge_related(keeper, [str(item["meta"].get("ki_id", "")) for item in losers])
        write_markdown(keeper["path"], keeper["meta"], keeper["body"])
        for loser in losers:
            update_status(loser, "superseded", now_ts)
            actions["duplicates_merged"] += 1
        actions["graph_rebuild_required"] = True

    kis = load_kis(vault)
    supersession_groups: dict[tuple, list[dict]] = {}
    for item in active_items(kis):
        signature = supersession_signature(item)
        if signature[0] and signature[1] and signature[2]:
            supersession_groups.setdefault(signature, []).append(item)
    for group in supersession_groups.values():
        if len(group) < 2:
            continue
        keeper = choose_keeper(group)
        losers = [item for item in group if item is not keeper]
        merge_related(keeper, [str(item["meta"].get("ki_id", "")) for item in losers])
        write_markdown(keeper["path"], keeper["meta"], keeper["body"])
        for loser in losers:
            update_status(loser, "superseded", now_ts, "superseded_by_newer_memory")
            actions["contradictions_resolved"] += 1
        actions["graph_rebuild_required"] = True

    kis = load_kis(vault)
    if scope == "global":
        for item in kis:
            meta = item["meta"]
            if str(meta.get("stability_class", "")) != "advisory":
                continue
            expires_at = int(meta.get("expires_at", 0) or 0)
            if expires_at and expires_at < now_ts and str(meta.get("promotion_state", "")) != "expired":
                meta["promotion_state"] = "expired"
                meta["status"] = "superseded"
                write_markdown(item["path"], meta, item["body"])
                actions["advisories_expired"] += 1

    kis = load_kis(vault)
    if scope == "local":
        regenerated, ref_count = build_project_dna(vault, kis, now_ts)
        actions["project_dna_regenerated"] = regenerated
        actions["project_dna_ref_count"] = ref_count
    actions["low_connectivity_count"] = count_low_connectivity(kis)
    actions["alias_candidate_count"] = count_alias_candidates(kis)
    actions["broken_related_kis_count"] = count_broken_related_kis(kis)

    write_state(state_path, scope, mode, reason, signal_count, now_ts)
    result = {
        "result": "MAINTENANCE_COMPLETE",
        "scope": scope,
        "mode": mode,
        "reason": reason,
        "signal_count": signal_count,
        "actions": actions,
        "vault": str(vault),
        "state_path": str(state_path),
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
PY
