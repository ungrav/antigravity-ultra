#!/usr/bin/env bash
set -euo pipefail

ROOT="$HOME/.gemini"
JSON_OUTPUT=0

usage() {
  cat <<'EOF'
Usage:
  audit-surface-usage.sh --root PATH [--json]

Description:
  Read-only usage report for scripts, eval helpers, and workflows. It separates
  operational references from eval, generated recovery, and historical refs so
  generated manifests do not make a surface look runtime-active.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --root)
      ROOT="$2"
      shift 2
      ;;
    --json)
      JSON_OUTPUT=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unexpected argument: $1" >&2
      usage
      exit 1
      ;;
  esac
done

ROOT="$(cd "$ROOT" && pwd -P)"

python3 - "$ROOT" "$JSON_OUTPUT" <<'PY'
import json
import pathlib
import sys
from collections import Counter

root = pathlib.Path(sys.argv[1])
json_output = sys.argv[2] == "1"

EXCLUDED_DIRS = {
    ".git",
    ".agent",
    ".kernel",
    "__pycache__",
    "_DEPRECATED_TRASH",
    "antigravity",
    "antigravity-browser-profile",
    "history",
    "knowledge",
    "logs",
    "node_modules",
    "reports",
    "scratch",
    "tmp",
    "tmp_test_project",
}
EVAL_REF_PREFIXES = (
    "evals/",
)
EVAL_REF_EXACT = {
    "scripts/gemini-doctor.sh",
    "scripts/run-core-evals.sh",
}
GENERATED_REF_EXACT = {
    ".portable/bundle_manifest.json",
    "blueprints/manifest.json",
    "GEMINI_BLUEPRINTS.md",
    "workflows/WORKFLOWS_INDEX.md",
}
HISTORICAL_REF_PREFIXES = (
    "state/plan-events/",
    "state/traces/",
)
HISTORICAL_REF_EXACT = {
    "ERROR_LOG.md",
    "PROJECT_HISTORY.md",
}


def rel(path: pathlib.Path) -> str:
    return path.relative_to(root).as_posix()


def excluded(path: pathlib.Path) -> bool:
    parts = set(path.relative_to(root).parts)
    return bool(parts.intersection(EXCLUDED_DIRS))


def read_text(path: pathlib.Path) -> str:
    try:
        if path.stat().st_size > 1_000_000:
            return ""
    except OSError:
        return ""
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return ""


def collect_surfaces() -> list[tuple[pathlib.Path, str]]:
    surfaces: list[tuple[pathlib.Path, str]] = []
    scripts_dir = root / "scripts"
    if scripts_dir.exists():
        for path in sorted(scripts_dir.rglob("*")):
            if path.is_file() and not excluded(path):
                surfaces.append((path, "script"))
    evals_dir = root / "evals"
    for dirname, surface_type in (("checks", "eval-check"), ("bin", "eval-bin")):
        surface_dir = evals_dir / dirname
        if surface_dir.exists():
            for path in sorted(surface_dir.iterdir()):
                if path.is_file() and not excluded(path):
                    surfaces.append((path, surface_type))
    workflows_dir = root / "workflows"
    if workflows_dir.exists():
        for path in sorted(workflows_dir.glob("*.md")):
            if path.is_file() and not excluded(path):
                surfaces.append((path, "workflow"))
    return surfaces


def collect_reference_files() -> list[pathlib.Path]:
    paths: list[pathlib.Path] = []
    for path in root.rglob("*"):
        if path.is_file() and not excluded(path):
            paths.append(path)
    return paths


def is_eval_ref(reference: str, surface: str = "") -> bool:
    if reference == "scripts/gemini-doctor.sh" and surface.startswith("scripts/doctor/"):
        return False
    return reference in EVAL_REF_EXACT or any(reference.startswith(prefix) for prefix in EVAL_REF_PREFIXES)


def is_generated_ref(reference: str) -> bool:
    return reference in GENERATED_REF_EXACT


def is_historical_ref(reference: str) -> bool:
    return reference in HISTORICAL_REF_EXACT or any(reference.startswith(prefix) for prefix in HISTORICAL_REF_PREFIXES)


def is_legacy_adapter(path: pathlib.Path, surface_type: str) -> bool:
    if surface_type != "workflow":
        return False
    text = read_text(path)
    return (
        "status: adapter" in text
        or "surface_class: adapter" in text
        or "entry_role: adapter" in text
    )


surfaces = collect_surfaces()
reference_files = collect_reference_files()
reference_texts = [(path, read_text(path)) for path in reference_files]
items = []

for path, surface_type in surfaces:
    path_rel = rel(path)
    tokens = {path_rel, path.name}
    references = []
    for candidate, text in reference_texts:
        if candidate == path:
            continue
        if not text:
            continue
        if any(token in text for token in tokens):
            references.append(rel(candidate))
    references = sorted(set(references))
    eval_references = [reference for reference in references if is_eval_ref(reference, path_rel)]
    generated_references = [reference for reference in references if is_generated_ref(reference)]
    historical_references = [reference for reference in references if is_historical_ref(reference)]
    operational_references = [
        reference
        for reference in references
        if reference not in eval_references
        and reference not in generated_references
        and reference not in historical_references
    ]

    if surface_type in {"eval-check", "eval-bin"}:
        classification = "eval-suite"
    elif is_legacy_adapter(path, surface_type):
        classification = "legacy-adapter"
    elif not references:
        classification = "orphan-candidate"
    elif operational_references:
        classification = "active"
    elif eval_references:
        classification = "eval-only"
    elif generated_references:
        classification = "recovery-only"
    elif historical_references:
        classification = "historical-only"
    else:
        classification = "orphan-candidate"

    items.append(
        {
            "path": path_rel,
            "surface_type": surface_type,
            "classification": classification,
            "reference_count": len(references),
            "operational_reference_count": len(operational_references),
            "eval_reference_count": len(eval_references),
            "generated_reference_count": len(generated_references),
            "historical_reference_count": len(historical_references),
            "references": references[:20],
            "operational_references": operational_references[:20],
            "eval_references": eval_references[:20],
            "generated_references": generated_references[:20],
            "historical_references": historical_references[:20],
        }
    )

counts = Counter(item["classification"] for item in items)
result = {
    "schema_version": 1,
    "root": str(root),
    "summary": {
        "total": len(items),
        "active": counts["active"],
        "eval_only": counts["eval-only"],
        "eval_suite": counts["eval-suite"],
        "recovery_only": counts["recovery-only"],
        "historical_only": counts["historical-only"],
        "legacy_adapter": counts["legacy-adapter"],
        "orphan_candidate": counts["orphan-candidate"],
    },
    "surfaces": items,
}

if json_output:
    print(json.dumps(result, ensure_ascii=False, indent=2))
else:
    print(
        f"total={result['summary']['total']} "
        f"active={result['summary']['active']} "
        f"eval-suite={result['summary']['eval_suite']} "
        f"eval-only={result['summary']['eval_only']} "
        f"recovery-only={result['summary']['recovery_only']} "
        f"historical-only={result['summary']['historical_only']} "
        f"legacy-adapter={result['summary']['legacy_adapter']} "
        f"orphan-candidate={result['summary']['orphan_candidate']}"
    )
    for item in items:
        print(
            f"{item['classification']}\t{item['surface_type']}\t{item['path']}"
            f"\trefs={item['reference_count']}"
            f"\top={item['operational_reference_count']}"
            f"\teval={item['eval_reference_count']}"
            f"\tgen={item['generated_reference_count']}"
            f"\thist={item['historical_reference_count']}"
        )
PY
