# Autofix Run

This file is generated from `.autofix/spec.json` plus recovered memory.
Do not treat it as the source of truth.

## Objective
- Replace this section with the bounded goal from `spec.json`.

## Constraints
- Modify only the files listed in `editable_files`.
- Respect the current project conventions.
- Do not change memory files, Blueprints, or global kernel files from inside the improvement loop.

## Hyperlayer Guidance
- None provided yet.

## Known Good Strategies
- None loaded yet.

## Known Dead Ends
- None loaded yet.

## Evaluation Contract
- `eval.sh` is the judge.
- `result.json` must be valid on every iteration.
