#!/usr/bin/env bash
set -euo pipefail

cat > .autofix/result.json <<'EOF'
{
  "status": "blocked",
  "metric_name": "eval_not_configured",
  "score": 0,
  "summary": "Customize .autofix/eval.sh before running autofix.",
  "changed_files": []
}
EOF

echo "Customize .autofix/eval.sh before running autofix." >&2
exit 1
