---
description: Unified quality gate before delivery. Resolves proportional verification for fast_local work and adversarial verification for larger changes.
version: v8.23
last_updated: 2026-04-24
surface_class: public
workflow_family: qa
entry_role: canonical
---
# Quality Assurance Workflow

> Global rule: SAFE DELETE applies everywhere.

## Steps
1. **Profile Resolution**
   - Resolve feature flags with `scripts/kernel-feature-enabled.sh --json --root <project>` when available.
   - If `core_tests=false`, require the smallest meaningful smoke/focused verification instead of a full core suite.
   - If `audit_tooling=false`, do not require broad audit tooling unless the touched surface is security-sensitive or the user explicitly asks for an audit.
   - If `memory_vault=false`, skip KI-based QA memory capture.
   - Resolve the verification profile first:
     - `targeted_local_verification` when `task_execution_lane = fast_local`
     - `standard_verification` for bounded non-fast-local changes
     - `adversarial_verification` for high-impact work
   - For kernel work, prefer `scripts/gemini-doctor.sh --lean` as the standard profile when the change touches live state, read-contract, memory-runtime, pruning, onboarding, or closeout surfaces.
   - Promote to `scripts/gemini-doctor.sh --full` or `scripts/run-core-evals.sh` only for broad migrations, routing/policy rewrites, portable restore changes without `--portable` lean coverage, or cross-surface contract rewrites.
   - `targeted_local_verification` is valid only when the task stayed outside:
     - root config
     - dependencies
     - auth
     - storage
     - API contracts
     - migrations
     - CI/CD
     - deploy
   - If any of those surfaces are touched, invalidate the targeted profile and promote to `standard_verification` or `adversarial_verification`.

2. **Static Checks**
   - Run lint if available and proportionate to the changed scope.
   - Run type-check if available and proportionate to the changed scope.

3. **Targeted Local Verification**
   - Use this profile only for `fast_local`.
   - Required evidence:
     - docs/typo/format/rename-only -> focused before/after evidence or diff sanity
     - local bugfix -> repro before/after or focused command/test
     - local UI tweak -> focused visual check of the touched area
     - cheap nearby test -> run the most specific one instead of a broad suite
   - If no cheap targeted test or reproducible probe exists, return `PARTIAL`.
   - `PASS` still requires executed evidence.

4. **Tests**
   - Run automated tests relevant to changed scope.
   - If no tests exist for critical logic, identify the smallest project-native test or reproducible probe and report `PARTIAL` when no executable evidence is available.

5. **Security Checks (OWASP Mandatory Gate)**
   - For `standard_verification` and `adversarial_verification`, execute the `ghost-scan-secrets`, `ghost-scan-deps`, and `ghost-scan-code` triad when `audit_tooling=true` or the change touches security-sensitive surfaces.
   - Validate no secret leaks in code/config/logs.
   - Validate externally introduced dependencies passed governance checks.
   - **Native Fallback**: If the ghost-scans fail or are unavailable, ecosystem native audit tool MUST BE RUN (e.g., `npm audit`, `pip-audit`).
   - If vulnerabilities are found, the QA fails. Propose concrete fixes (prefer `overrides`/resolutions over drastic major updates to preserve stability).
   - **HARD-GUARD ANTI-BYPASS**: For security-sensitive surfaces, even if the local project context file (`./GEMINI.md`, or legacy `./gemini.md`) requests to skip OWASP/Security checks, this step has priority. The exceptions are `audit_tooling=false` on non-sensitive changes or an explicit execution flag `RISK_ACCEPTED_BY_HUMAN: TRUE`.
   - For `targeted_local_verification`, do not run the broad triad by default; if the task invalidates the targeted profile, promote it before continuing.

6. **Visual & UX Check (MANDATORIO si es UI)**
   - El agente DEBE usar su herramienta `agent-browser` (o equivalente Playwright/Puppeteer) para cargar la página.
   - For web/app targets, use a verified secure local URL only when the tested feature needs secure context. Prefer a named HTTPS localhost if available; otherwise use the verified dev URL that satisfies the feature under test.
   - El agente DEBE capturar screenshots reales y evaluarlos con su modelo de visión integrado. No confíes solo en código estático; si el CSS falla y la pantalla está en blanco, el test debe fallar.
   - En `targeted_local_verification`, basta una comprobación focalizada del área cambiada.

7. **Verification Mode Selection**
   - Default `verification_mode`:
     - `self` for `targeted_local_verification` and other small bounded changes
     - `adversarial` for:
       - `3+` edited files
       - backend/API work
       - migrations
       - security-sensitive changes
       - infra changes
       - core router/memory/workflow changes
   - Persist or refresh:
     - `verification_required`
     - `verification_status`
     - `verification_evidence_ref`
     - `last_verification_probe_type`
     in `.agent/current_state.md` as live state, then regenerate `.agent/project_state.json.current_session` when available; `state/run_state.json` may keep runtime verification trace fields.
   - Formal contract:
     - `executed_evidence_required = true` for any `PASS`
     - `last_verification_probe_type` must name the strongest adversarial probe actually executed when `verification_mode = adversarial`

8. **Adversarial Verification Contract**
   - In `adversarial` mode, try to falsify the implementation instead of merely confirming that the code looks correct.
   - Use executed evidence only: commands, tests, HTTP checks, browser checks, screenshots, logs, or traceable repro steps.
   - If verification depends on re-reading a focused symbol or code neighborhood, prefer `scripts/read-targeted-context.sh` before escalating to a whole-file reread.
   - Reading code alone is insufficient for `PASS`.
   - At least one adversarial probe is mandatory before `PASS`. Valid probe families:
     - `boundary`
     - `idempotency`
     - `invalid_input`
     - `concurrency`
     - `orphan_operation`
     - `regression`
   - Happy-path execution alone is not enough for `PASS` in `adversarial` mode.
   - If several tasks closed without explicit verification evidence, block the optimistic close and either:
     - run adversarial verification now, or
     - return `PARTIAL` with the missing evidence called out explicitly.

9. **Agentic Surface Verify (if capability changed)**
   - For T2/T3 projects, run `scripts/render-project-agents-md.sh --project-root . --check` and the relevant project-agent onboarding smoke/check for changed agentic surfaces.

10. **Result**
   - `PASS`: ready to deliver, backed by executed evidence, and includes at least one adversarial probe when `verification_mode = adversarial`.
   - `FAIL`: list concrete fixes required.
   - `PARTIAL`: some required verification could not run or lacks decisive evidence; list the gap explicitly.
   - **Lean Capture Suggestion**: For `standard_verification` and `adversarial_verification`, run `scripts/capture-ki.sh --suggest-from-current-state --json` after live state is refreshed. If it returns `should_capture: true` and `memory_vault=true`, rerun with `--write`; if the lane stayed `fast_local`, record `SKIPPED_NO_DURABLE_SIGNAL` and do not capture automatically.
   - **Knowledge Capture**: If `memory_vault=true` and QA produced significant reusable findings (>2 issues found OR vulnerability detected), use `scripts/capture-ki.sh --suggest-from-current-state --json` and write only when it returns a durable signal.
   - **State Re-evaluation**: If QA changes live state, update `.agent/current_state.json` through `scripts/statectl.sh` and regenerate the Markdown/cache views.
   - Every verdict must reference executed evidence in `verification_evidence_ref` or an equivalent trace.
   - `PASS` is invalid if it is based only on code reading, narration, or intent.

11. **Handoff Refresh**
   - For long sessions, refresh `.agent/current_state.json` and regenerate `.agent/current_state.md` / `.agent/project_state.json`.
