---
description: Unified quality gate before delivery. Resolves proportional verification for fast_local work and adversarial verification for larger changes.
version: v8.23
last_updated: 2026-05-13
surface_class: public
workflow_family: qa
entry_role: canonical
---
# Quality Assurance Workflow

> Global rule: SAFE DELETE applies everywhere.

## Steps
1. **Profile Resolution**
   - Resolve feature flags with `scripts/kernel-feature-enabled.sh --json --root <project>` when available.
   - If `core_tests=false`, run the smallest meaningful smoke/focused verification.
   - If `audit_tooling=false`, skip broad audit tooling unless the touched surface is security-sensitive or the user explicitly requests an audit.
   - Verification profiles:
     - `targeted_local_verification` for `task_execution_lane = fast_local`
     - `standard_verification` for bounded non-fast-local changes
     - `adversarial_verification` for high-impact work
   - For kernel work, use `scripts/gemini-doctor.sh --lean` as Tier 1 daily/standard verification when touching live state, read-contract, memory-runtime, pruning, onboarding, or closeout.
   - Promote to `scripts/gemini-doctor.sh --full` or `scripts/run-core-evals.sh` Tier 2 broad verification for routing/policy rewrites, portable restore changes, broad migrations, or cross-surface contract rewrites.
   - `targeted_local_verification` is invalid for root config, dependencies, auth, storage, API contracts, migrations, CI/CD, or deploy surfaces.

2. **Static and Focused Checks**
   - Run lint, type-check, and automated tests proportionate to the changed scope.
   - For `fast_local`, focused before/after evidence, a repro probe, a nearby test, or a targeted visual check is enough.
   - If no cheap targeted probe exists for critical logic, return `PARTIAL` instead of claiming `PASS`.

3. **Security and External Risk**
   - For `standard_verification` and `adversarial_verification`, run `ghost-scan-secrets`, `ghost-scan-deps`, and `ghost-scan-code` when `audit_tooling=true` or the change touches security-sensitive surfaces.
   - If those tools are unavailable, run the ecosystem-native audit fallback such as `npm audit` or `pip-audit`.
   - Validate no secrets leaked and any new external dependency passed governance.
   - Security-sensitive surfaces may skip this only with explicit `RISK_ACCEPTED_BY_HUMAN: TRUE`.

4. **UI Verification**
   - For UI changes, use `agent-browser` or equivalent Playwright/Puppeteer to load the page.
   - Capture real screenshots and inspect the changed area; static CSS review alone is insufficient.
   - Use a secure local URL only when the feature requires secure context.

5. **Adversarial Contract**
   - Default `verification_mode=self` for small bounded changes; use `verification_mode=adversarial` for 3+ edited files, backend/API work, migrations, security-sensitive changes, infra, or core router/memory/workflow changes.
   - `executed_evidence_required = true` for any `PASS`.
   - At least one adversarial probe is mandatory before `PASS` in adversarial mode.
   - Valid probe families: `boundary`, `idempotency`, `invalid_input`, `concurrency`, `orphan_operation`, `regression`.
   - Happy-path execution, code reading, narration, or intent alone cannot produce `PASS`.
   - Persist or refresh `verification_required`, `verification_status`, `verification_evidence_ref`, and `last_verification_probe_type` in live state when QA changes state.

6. **Agentic Surfaces and Result**
   - For T2/T3 capability changes, run `scripts/render-project-agents-md.sh --project-root . --check` and the relevant project-agent onboarding smoke/check.
   - `PASS`: ready to deliver, backed by executed evidence and adversarial probe evidence when required.
   - `FAIL`: list concrete fixes required.
   - `PARTIAL`: list missing or inconclusive evidence.
   - For significant reusable findings, run `scripts/capture-ki.sh --suggest-from-current-state --json` and write only when it returns a durable signal.
   - For long sessions, refresh `.agent/current_state.json` and regenerate `.agent/current_state.md` plus `.agent/project_state.json`.
