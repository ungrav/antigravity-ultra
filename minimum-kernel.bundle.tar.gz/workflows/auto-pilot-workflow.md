---
description: Mandatory lean master router. Classifies every request, applies risk gates, dispatches workflows, enforces verification and durable state updates.
version: v8.24
last_updated: 2026-04-27
surface_class: public
workflow_family: routing
entry_role: canonical
---
# Auto-Pilot Protocol

> Global rule: SAFE DELETE applies everywhere. No direct `rm` for project/system artifacts.

## Phase 1: Warmup Minimo
- Native Antigravity runtime starts from `GEMINI.md` + `.agent/current_state.md`; no separate workflow warmup is required.
- External agents use the hot path only: `AGENTS.md` when present, `.agent/current_state.md`, then classify intent before opening memory, ledgers, or runtime-specific kernel files.
- `state/read_contract.json` is the machine read contract. `GEMINI.md` and `AGENTS.md` are generated human projections; if a surface is not declared for the active read class, it stays out.
- Classify intent before opening project digest, memory notes, ledgers, `MEMORY.md`, or `GEMINI_BLUEPRINTS.md`.
- Use `scripts/read-targeted-context.sh` for focused context reads and `evals/bin/evaluate-cache-break.sh` when prompt/cache drift needs diagnosis.
- Load `.agent/knowledge/.project_dna.md`, `rules/memory-runtime.md`, and targeted memory notes from `scripts/select-memory-context.sh` only when the classified task needs memory, kernel, architecture, incident, or durable historical context.
- Load full `MEMORY.md` only when the task explicitly changes/audits memory, RAG, memory notes, maintenance, or kernel internals.
- Do not read `GEMINI_BLUEPRINTS.md` during runtime work. It is for `bootstrap`, `recover`, `pack`, `regen`, and `doctor`.
- Never inject `AGENTS.md` or `CLAUDE.md` into the native Antigravity runtime prompt; they are interop/onboarding surfaces only.
- Persist warmup/cache state in `state/run_state.json`: `prompt_prefix_hash`, `prompt_dynamic_hash`, `cache_break_reason`, `warmup_completed_at`, and `warmup_source_order`.
- If a handoff only has partial visible state, mark it as `PARTIAL VIEW`, trust repo/runtime facts first, exclude `antigravity/brain` historical drafts from hot context, and refresh `.agent/current_state.json` before proceeding.

## Phase 2: Clasificar Tarea
- Classify depth as `micro`, `lite`, `standard`, or `deep_audit`.
- Resolve execution lane separately as `fast_local`, `standard`, or `deep_audit`.
- `fast_local` is for obvious local work in one file or a tightly related 2-3 file local cluster.
- `fast_local` invalidators: auth/storage, API contract, migrations, deploy/release, dependencies, MCP runtime, memory/RAG, blueprints, core scripts, security-sensitive config, breaking changes, broad multi-module impact, unclear root cause, or a fourth relevant file/module.
- Persist `task_class`, `task_execution_lane`, `fast_local_reason`, `fast_local_invalidators`, and `fast_local_validation_scope`.

## Phase 3: Superficie Sensible Y Plan Gate
- AUTO covers bounded, low-risk, reversible work.
- CONFIRM covers installs, move/delete, architecture shifts, breaking changes, high-impact operations, and ambiguous risky actions.
- Before shell-like mutating actions, evaluate guardrails/tool/provider policy when those evaluators are available; fail closed to `CONFIRM` on invalid output.
- The formal implementation plan lifecycle is mandatory only for sensitive/high-impact surfaces: architecture, auth, storage, API contracts, migrations, deploy/release, dependencies, MCP runtime, memory/RAG internals, blueprints, core scripts, security-sensitive config, external integrations, breaking changes, or broad multi-module changes with rollback/release risk.
- If gated, load `rules/implementation-planning.md` and use `scripts/ingest-plan-event.sh` for lifecycle events.
- If `task_execution_lane = fast_local`, skip the formal plan gate and continue with localized execution + proportional verification.
- For plan-gated work, sync only `plan_state`; the plan body stays in the host/session.
- Preserve `producer_agent` as the agent that authored the plan/receipt; the host remains the state authority.
- Non-sensitive bounded features, refactors, and bugfixes that are not obvious enough for `fast_local` use `standard_low` as a short chat/session receipt; lifecycle events are not required.
- Bounded local features, refactors, and bugfixes that touch 2-3 tightly related files may use `standard_low` receipt flow or `fast_local` when the root cause and acceptance are obvious.

## Phase 4: Contexto Dirigido
- `fast_local`: zero broad discovery; route directly to localized execution inside this workflow.
- `fast_local` uses only targeted context needed for the edit, skips pre-plan discovery and the formal blocking plan gate, and must not create inbox drafts.
- `micro`: answer or edit inline with only the files needed.
- `lite`: use bounded local/official discovery.
- `standard` and `deep_audit`: gather pre-plan intelligence inline only when discovery materially improves the outcome: check applicable skills, official/current sources, dependency or web safety, and governance constraints.
- Normal work uses the Golden Path first: current state, targeted files, and resolver guidance when useful.
- Normal memory routing loads `rules/memory-runtime.md` and selector output, not full `MEMORY.md`.
- Keep interop docs, archival brain notes, and draft inbox entries out of runtime context unless the user or task explicitly asks for that surface.

## Phase 5: Ejecutar
- Dispatch the smallest workflow that matches the task: bugfix, feature local, QA/doctor, plan-gated sensitive work, or portable restore.
- Use native host sub-agent delegation only when delegated branches are explicit and useful. Valid modes are `research_parallel | implementation_owned | verification_independent`; vague prompts like `based on your findings` are prohibited because the coordinator must synthesize concrete findings before acting.
- Persist `delegation_synthesis_required = true` when parallel branches or unsynthesized delegated findings exist.
- Route to `autofix-workflow.md` only when the user explicitly requests a bounded autonomous fix/improvement or another workflow has a clear goal, an objective evaluator, and an editable-file allowlist.
- Optional SLM/Hyperlayer/autofix-advanced flows are experimental. Do not suggest or route to them from `micro`, `lite`, or simple direct execution.

## Phase 6: Verificar
- Run proportional verification for every code-impacting task.
- `fast_local` uses targeted local verification unless an invalidator promotes the task.
- Required verification surfaces: 3+ edited files, backend/API changes, migrations, security-sensitive changes, infra changes, core router/memory/workflow changes.
- Persist `verification_required`, `verification_status`, `verification_evidence_ref`, and `last_verification_probe_type`.
- `last_verification_probe_type` must be populated whenever adversarial verification ran.
- Do not close complex work optimistically. If verification could not fully run, report `PARTIAL`.

## Phase 7: Persistir Solo Lo Durable
- Update `PROJECT_HISTORY.md` only when `project_ledgers=true` for durable changes: architecture, contracts, workflows, scripts core, behavior worth future recall, or release-relevant outcomes.
- Prefer `scripts/logctl.sh history` for durable changelog writes when available and `project_ledgers=true`.
- Skip pure typo/docs/format/rename-only `fast_local` noise.
- Update `ERROR_LOG.md` only when `project_ledgers=true` for real incidents, repeatable failures, root cause, and fix.
- Prefer `scripts/logctl.sh incident` for incident writes when available and `project_ledgers=true`.
- `.agent/current_state.json` is the machine source of truth for live state. `.agent/current_state.md` is the agent-readable live handoff view. `.agent/project_state.json` is cache/script output, not a second manual source of truth.
- `fast_local`: never capture memory notes automatically; do not write inbox drafts unless a real incident or reusable bug signal promotes the task out of `fast_local`.
- skip pure typo/docs/format/rename-only `fast_local` noise unless the user explicitly asks for a durable record.
- `standard` and `deep_audit`: after refreshing `.agent/current_state.json`, run `scripts/capture-ki.sh --suggest-from-current-state --json`; add `--write` only when the returned JSON says `should_capture=true`.
- `fast_local`: the closeout suggestion path is treated as `SKIPPED_NO_DURABLE_SIGNAL`; do not create KI noise for local edits.
- Normal task lanes use targeted context only; broad memory cleanup is explicit tooling work.

## Phase 8: Cerrar Con Resultado Fiel
- Report exactly what changed, what verification ran, and any residual risk.
- If work failed or was blocked, run the incident path and say what evidence caused the stop.
- On long sessions or handoffs, update `.agent/current_state.json`, then render `.agent/current_state.md` with objective, blockers, verification status, and next step.
- For non-fast-local durable work, include the capture suggestion result in closeout state rather than relying on the agent to remember manual KI creation.

## Golden Rules
1. Router first, execution second.
2. Sensitive surface beats step count.
3. Product work beats kernel bureaucracy.
4. Keep user-facing communication in Spanish.
5. Load `dependency-safety-baseline-workflow.md` before dependency installs or dependency runtime changes.
