---
description: Public entrypoint for global system health diagnostics. Uses gemini-doctor as the umbrella contract and keeps specialized checks as drill-down tools.
version: v8.9
last_updated: 2026-03-30
surface_class: public
workflow_family: operations
entry_role: canonical
---
# System Health Check Workflow

> Global rule: SAFE DELETE applies everywhere.

## When to Run
- Session start.
- After bootstrap or major updates.
- When behavior drifts unexpectedly.

## Checks
1. **Core Files**
   - Verify `~/.gemini/GEMINI.md` exists.
   - Verify `~/.gemini/MEMORY.md` exists.
   - Verify `~/.gemini/GEMINI_BLUEPRINTS.md` exists.
   - Treat the portable trio as separately managed. Do not expect BLUEPRINTS to restore kernel or memory files.

2. **Core Tooling**
   - `git --version`
   - `node -v`
   - `docker -v || echo "Docker optional/unavailable"`
   - `portless --version || echo "Portless optional/unavailable"`

3. **Workflow & Knowledge Integrity**
   - Run `bash ~/.gemini/scripts/gemini-doctor.sh --lean` as the default daily integrity gate.
   - Run `bash ~/.gemini/scripts/gemini-doctor.sh --full` only before declaring broad kernel migrations complete.
   - Use `bash ~/.gemini/scripts/build-blueprints.sh ~/.gemini` and `bash ~/.gemini/scripts/verify-blueprint-manifest.sh ~/.gemini` as drill-down when BLUEPRINT coverage needs targeted diagnosis.
   - Treat simple Markdown KIs plus selector output as the active memory contract. `MEMORY.md`, `GEMINI.md`, and the recovery workflows must agree on that split.

4. **Simple Memory Health**
   - Ensure `MEMORY.md` defines Markdown KIs, Project DNA, global memory, capture, and compaction.
   - Ensure `MEMORY.md` also defines `Global Memory Layer` and `Global Promotion & Demotion Contract`.
   - Ensure `project-init-workflow.md` does not require generated memory helper state for normal bootstrap.
   - Run `bash ~/.gemini/evals/checks/check-memory-bootstrap-smoke.sh`.
   - Run `bash ~/.gemini/evals/checks/check-global-memory-bootstrap-smoke.sh`.
   - Run `bash ~/.gemini/evals/checks/check-global-memory-retrieval-smoke.sh`.
   - Run `bash ~/.gemini/evals/checks/check-global-memory-promotion-smoke.sh`.
   - Run `bash ~/.gemini/evals/checks/check-global-memory-cross-project-e2e.sh` when validating isolation, contradiction handling, and multi-project promotion behavior.
   - Run `bash ~/.gemini/evals/checks/check-global-memory-continuous-flow-e2e.sh` when validating a continuous flow of learn -> promote -> consume -> contradict -> degrade.
   - If any check finds expired advisories leaking into ranking, local/global precedence drift, cross-project contamination, or contract drift between the portable kit/workflows, downgrade status to `ACTION_REQUIRED`.

5. **Capability / Consent Health**
   - Ensure `config/feature_capability_contract.json` exists and describes `slm` + `hyperlayer`.
   - Ensure `state/capability_state.json` exists and remains the runtime authority for optional features.
   - Run `bash ~/.gemini/evals/checks/check-capability-onboarding-smoke.sh`.
   - Run `bash ~/.gemini/evals/checks/check-feature-consent-memory-e2e.sh`.
   - Run `bash ~/.gemini/evals/checks/check-hyperlayer-bypass-smoke.sh`.
   - Run `bash ~/.gemini/evals/checks/check-hyperlayer-three-projects-e2e.sh` when validating cross-project learning and promotion of Hyperlayer strategies.
   - Run `bash ~/.gemini/evals/checks/check-hyperlayer-runstate-smoke.sh` after changing Phase 4.5 runtime persistence.
   - Run `bash ~/.gemini/evals/checks/check-hyperlayer-runtime-feedback-e2e.sh` after changing feedback-to-registry behavior.
   - Run `bash ~/.gemini/evals/checks/check-slm-bypass-smoke.sh`.
   - Run `bash ~/.gemini/evals/checks/check-antigravity-fallback-warning-e2e.sh`.
   - If any of these fail, downgrade status to `ACTION_REQUIRED`.

6. **Autofix Portability + Runtime Health**
   - Run `bash ~/.gemini/evals/checks/check-autofix-smoke.sh` when available.
   - Run `bash ~/.gemini/evals/checks/check-autofix-strategy-hint-e2e.sh` after changing Hyperlayer-to-autofix integration.
   - Ensure `autofix` remains workflow-first:
     - workflow canonical
     - skill thin adapter
     - loop script + `.autofix/` templates restorable from BLUEPRINTS
   - If the smoke fails or the manifest cannot restore the autofix bundle, downgrade status to `ACTION_REQUIRED`.

7. **Skills Health**
   - Run `skills-lifecycle-workflow.md` as the public maintenance gate.
   - Use `scripts/sync-skills-registry.sh` and the skill registry/curation smokes as drill-down integrity when lifecycle diagnostics need more detail.
   - Ensure curation tiers, duplicate state, and default discovery contract stay healthy.

8. **Portless Runtime Health (optional/local-web)**
   - Run `bash ~/.gemini/evals/checks/check-portless-smoke.sh`.
   - Treat missing `portless` as `PARTIAL` only if no workflow in scope requires secure named localhost URLs.
   - Treat unwritable state-dir defaults, broken route listing, or runtime/version drift as `ACTION_REQUIRED` when `portless` is part of the active workflow chain.

9. **Guardrails Health**
   - Run `bash ~/.gemini/evals/checks/check-guardrails.sh`.

10. **Routing Health**
   - Run `bash ~/.gemini/evals/checks/check-routing-evals.sh`.

11. **Lifecycle Hooks Health**
   - Run `bash ~/.gemini/evals/checks/check-lifecycle-hooks.sh`.

12. **Tool Policy Health**
   - Run `bash ~/.gemini/evals/checks/check-tool-policies.sh`.

13. **Provider / Environment Profile Health**
   - Run `bash ~/.gemini/evals/checks/check-provider-environment.sh`.

14. **External Capability Surface Health**
   - Run `bash ~/.gemini/evals/checks/check-external-capability-surfaces.sh`.

15. **Persistent Approval Health**
   - Run `bash ~/.gemini/evals/checks/check-approval-grants.sh`.

16. **Persistent Approval Management Health**
   - Run `bash ~/.gemini/evals/checks/check-approval-grant-management.sh`.

17. **Observability Health**
   - Run `bash ~/.gemini/evals/checks/check-trace-observability.sh`.

18. **Dependency Safety Drift**
   - Ensure `gemini-doctor.sh` remains green, including dependency safety baseline checks.

19. **Agentic Stack Readiness (project scope)**
   - If current project is classified as T2/T3, run `scripts/render-project-agents-md.sh --project-root . --check` and verify declared agentic surfaces exist.

20. **Recovery Path**
   - If drift detected, run `scripts/build-blueprints.sh`, `scripts/verify-blueprint-manifest.sh`, and re-run integrity checks.

## Output Status
- READY
- PARTIAL
- ACTION_REQUIRED
