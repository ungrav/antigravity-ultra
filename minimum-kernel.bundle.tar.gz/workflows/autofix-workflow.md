---
description: Canonical workflow for portable, eval-driven bounded autofix loops with simple local memory hints.
version: v8.0
last_updated: 2026-03-31
surface_class: public
workflow_family: agentic
entry_role: canonical
---
# Autofix Workflow

> Global rule: SAFE DELETE applies everywhere.

## Introduction
`autofix` is a core on-demand capability inspired by `autoresearch`, but hardened for the Antigravity kernel. The canonical source of truth is this workflow. The skill only adapts the entrypoint, and the loop script only executes the contract defined here.

This workflow solves bounded improvement tasks by running a foreground loop with:
- explicit scope
- an objective evaluator
- deterministic rollback
- local-first memory reuse
- optional durable memory capture after the run

## Prerequisites
- The task already has a clear goal and a real evaluation path.
- `.autofix/` exists or can be created in the project root.
- If browser evaluation requires secure origin, use a verified secure local URL. `Portless` is opt-in: only when `eval_mode == browser` and `requires_secure_origin == true`.
- If `.agent/knowledge/` exists, reuse it as the local-first memory source. Do not invent a parallel memory system.

## Steps

1. **Create the Run Contract**
   - The canonical contract is `.autofix/spec.json`.
   - Required files inside `.autofix/`:
     - `spec.json`
     - `program.md`
     - `eval.sh`
     - `result.json`
     - `state.json`
     - `history.jsonl`
   - `spec.json` is the source of truth. `program.md` is generated from it plus recovered memory.

2. **Populate `.autofix/spec.json`**
   - Required keys:
     - `goal`
     - `tenant_domain`
     - `objective_type`
     - `editable_files`
     - `backend`
     - `eval_mode`
     - `requires_secure_origin`
     - `success_rule`
     - `max_iterations`
     - `plateau_window`
     - `timeout_seconds`
     - `rollback_mode`
     - `memory_mode`
   - Optional keys:
     - `strategy_hint`
       - `strategy_id`
       - `decision_source`
       - `confidence`
       - `backend_hint`
       - `reasoning_effort`
       - `workflow_chain`
       - `skill_hints`
       - `autofix_hint`
   - Allowed backends in v1: `codex`, `claude`, `gemini`.
   - Runtime selection is stricter than user preference:
     - clean Git repo -> `git_worktree`
     - dirty Git repo -> `hybrid_safe`
     - no Git -> `hybrid_safe`
   - `strategy_hint` is advisory only:
     - it can bias planning and document a preferred backend/reasoning path
     - it cannot bypass `goal + evaluator + editable_files`
     - if absent, autofix behaves exactly as before

3. **Prepare the Evaluator**
   - `.autofix/eval.sh` is the judge.
   - It must write `.autofix/result.json`.
   - `result.json` must be valid even on failure. Allowed statuses in v1:
     - `pass`
     - `fail`
     - `error`
     - `timeout`
     - `plateau`
     - `blocked`
   - `eval.sh` without a valid `result.json` is a contract failure.

4. **Load Memory Before the Loop**
- Recover up to 5 local KIs from `.agent/knowledge/` using `scripts/select-memory-context.sh` or equivalent simple selector output.
   - Default autofix query mode is `normal`:
     - `normal` -> only `active`
     - `historical` -> may include `superseded`, never `archived`
   - Apply a fixed category budget for reliability:
     - up to 2 `conclusion`
     - up to 2 `research`
     - up to 1 `skill_insight`
   - Rank candidates with simple script-owned heuristics:
     - filter by `status`
     - prefer matching `tenant_domain`, `editable_files`, and goal tokens
   - Deduplicate related or near-duplicate KIs before prompt assembly.
   - Generate `program.md` with two explicit sections:
     - `Known Good Strategies`
     - `Known Dead Ends`
   - If `strategy_hint` exists, also render:
     - `Hyperlayer Guidance`
     - a strategy-hint entry inside `Known Good Strategies`
     - a blocked reason inside `Known Dead Ends` when `autofix_hint.status == blocked`
   - Retrieval alone must not mutate journals, indexes, or KIs in the normal path.
   - Log memory-selection debugging events in `history.jsonl`:
     - `memory_selection_started`
     - `memory_selection_completed`
     - `memory_selection_rejected`

5. **Launch the Loop**
   - Use the canonical loop engine:
     - `bash ~/.gemini/skills/autofix/scripts/autofix-loop.sh`
   - The skill may call it, but the workflow remains canonical.
   - The loop order is fixed:
     1. read `spec.json`
     2. recover memory
     3. generate `program.md`
     4. execute backend only on `editable_files`
     5. run `eval.sh`
     6. validate `result.json`
     7. decide `continue`, `rollback`, or `stop`

6. **Rollback Policy**
   - Forbidden in all modes:
     - `git stash`
     - `git restore .`
     - `git checkout -- .`
     - auto `git commit -am`
   - `git_worktree` mode:
     - only for clean repositories
     - run iterations inside a temporary worktree
     - keep the main tree untouched during failures
     - apply only the winning diff back to the caller workspace
   - `hybrid_safe` mode:
     - snapshot only the allowlisted files per iteration
     - take a full checkpoint before risky runs
     - use SAFE DELETE plus a temporary worktree or file snapshot for full-project restore
   - If the backend edits files outside `editable_files`, mark the iteration as `error`, rollback immediately, and log `out_of_scope_edit`.

7. **Stop Conditions**
   - `pass`
   - `timeout`
   - `max_iterations`
   - `plateau` after `plateau_window` non-improving iterations
   - out-of-scope edits

8. **Memory Update After the Run**
   - On success:
     - create a `conclusion` KI
     - create a `skill_insight` KI if the run produced a reusable autofix adaptation
     - record reused KI paths and outcome in the run history
   - On useful failure / dead end:
     - create a `research` KI
     - record the dead end in the run history
   - Do not write derived scoring fields into KI frontmatter or selector output.

9. **Validation**
   - Run `check-autofix-smoke.sh` after structural changes.
   - Run `check-autofix-strategy-hint-e2e.sh` after changes to `strategy_hint` handling.
   - Keep `gemini-doctor.sh` green.
