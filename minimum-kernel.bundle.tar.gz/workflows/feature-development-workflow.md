---
description: End-to-end feature workflow: consume pre-plan evidence, implement, integrate, verify, generate RAG knowledge, and sync agentic metadata.
version: v8.3
last_updated: 2026-03-28
surface_class: public
workflow_family: delivery
entry_role: canonical
---
# Feature Development Workflow

> Global rule: SAFE DELETE applies everywhere.

> This workflow is for `standard` / `deep_audit` delivery scope. If the router resolved `task_execution_lane = fast_local`, stay in the localized Auto-Pilot path instead of entering this flow.

## Steps
0. **Feature Flags**
   - Resolve optional runtime features with `scripts/kernel-feature-enabled.sh --json --root <project>` when available.
   - `memory_vault=false`: skip memory-note retrieval/generation, Project DNA expectations, and knowledge-capture fallback.
   - `project_ledgers=false`: do not require `PROJECT_HISTORY.md` or `ERROR_LOG.md`.
   - `strict_plan_gate=false`: use a short chat/session receipt unless the surface is clearly sensitive under `rules/implementation-planning.md`.
   - `core_tests=false`: keep verification to the smallest meaningful smoke/focused command.

1. **Scope, Evidence & Plan Gate**
   - Define objective, impacted files, and acceptance criteria.
   - If routed via `auto-pilot-workflow.md`, consume `discovery_evidence` from `run_state.json` instead of re-running discovery, brainstorming, or broad community search.
   - If invoked standalone and the scope touches a sensitive surface, gather pre-plan intelligence inline: relevant skills, official/current references, dependency/web safety, and governance constraints.
   - `brainstorming` is optional support inside the pre-plan phase when the design space is genuinely open; it is no longer a rigid mandatory prerequisite.
   - For plan-gated mutating scope, load `~/.gemini/rules/implementation-planning.md`.
   - Sensitive/high-impact work uses the blocking host/session implementation plan. Bounded local features/refactors outside sensitive surfaces use `standard_low` receipt flow when alignment is useful, never a long-form plan body.
   - For plan-event gated work only, create or update the implementation plan/receipt inside the current host/session in Spanish, then mirror only `plan_state` into the project/runtime state through `scripts/ingest-plan-event.sh`.
   - Non-sensitive `standard_low` work stays in chat/session receipt form and does not require lifecycle events.
   - `draft`, `pending_user`, `approved`, `superseded`, and plan audit memory sync must come from explicit host events. If the agent just presented a bounded plan and the user clearly says "sí, dale" or equivalent, wait for the host or adapter to register that approval as a structured event; do not add extra ceremony in chat.
   - Respect the split `source_host` vs `producer_agent`: the host owns state, the producer owns the plan body.
   - Approval must enter as a structured event with `approval_source`; conversational approval is valid only after the adapter or host records it.
   - The plan/receipt is BLOCKING only when the gate applies: do not continue to implementation until the user approves it.
   - If the scope changes materially, update the plan and obtain renewed approval before resuming.
   - **Knowledge Capture**: Do not duplicate pre-plan capture if `auto-pilot` already persisted the research/audit rationale. Only capture here when running standalone and substantive pre-plan investigation was not yet recorded.

2. **Skills Reuse & Logic Extraction**
   - Reuse the skill decision already resolved by Auto-Pilot or host skill discovery whenever available.
   - Load only the skills that survived the pre-plan selection.
   - If a required skill is still missing and no valid evidence exists, search available host skills/connectors first; install or create only after confirming no adequate existing skill/tool covers the need.
   - **Recommendation**: If building generic/domain-agnostic complex logic (>30 lines), use `skill-creator` to extract it as a global agent skill only after the search-first skill lifecycle confirms no community or installed skill exists.
   - **Restriction**: NEVER extract private *business logic* into an agent skill. Keep business logic documented inside the project repo.
   - **Knowledge Capture**: When applying a skill for the first time in this project, use `scripts/capture-ki.sh --suggest-from-current-state --json` and write only when the resulting note is durable and reusable.

3. **Governance Consumption**
   - If `discovery_evidence` or the active scope indicates external tooling/dependencies/APIs/models, consume the prior governance recommendation first.
   - If the scope includes dependency installation or package-manager changes, load `dependency-safety-baseline-workflow.md` before proposing commands.
   - If no valid prior evidence exists and the change is genuinely external, run the inline external governance checklist before implementation: official/current source, maintenance status, license, security posture, alternatives, project fit, and rollback.
   - Use `web-safety-workflow.md` before web research, third-party code ingestion, or unknown URLs.
   - Do not proceed on `BLOCKED` decisions.

4. **Implementation**
   - Build incrementally.
   - **AST Mutator Mandate**: If the change touches imports/exports, signatures, JSX/TSX trees, nested objects, or multiple related symbols, use AST-based extracting and editing tools first. For large files (`>300` lines), AST is preferred. If parser support is unavailable, use the smallest safe textual patch and verify the result immediately.
   - Keep code/identifiers in English.
   - Keep function comments in Spanish.
   - **Graceful Degradation**: Strictly PROHIBITED to implement blocking Promises or critical APIs (AI, WebGPU) in UI front-ends without a `try/catch` block that triggers an amicable fallback State (avoiding White Screen of Death on OOM).
   - **HTTPS/CSP Local Enforcer**: Do NOT test WebCrypto, ServiceWorkers, or WebGPU APIs on local IPs without secure contexts. Prefer `portless` when installed, otherwise use framework-native HTTPS or another verified secure local origin.
   - **Proactive Rule Suggestion (The Claude Pattern)**: If experiencing continuous friction (e.g., repeating the same compilation or linting error >2 times due to a strict rule), the agent MUST pause and proactively ask the user: *"I notice rule X is causing continuous friction. Should we temporarily loosen this constraint in our local `GEMINI.md` (Human Zone) to allow an iterative approach?"*. If the user agrees, apply the surgical edit immediately.
   - **WAL Journaling**: During significant code modifications, append `.agent/knowledge/.wal_journal` only when `memory_vault=true` and `telemetry_tooling=true`.

5. **Integration & Auto-Docker Refresh**
   - Wire feature into existing flows.
   - **Docker Refresh**: If a `docker-compose.yml` exists in the project root, propose `docker compose build && docker compose up -d -V --force-recreate` to apply changes, but transition to **CONFIRM** mode before execution.
   - Validate no obvious regressions.

6. **Agentic Stack Sync (if capability changed)**
   - When new actions/tools/routes/capabilities are introduced in a T2/T3 project, update renderer-managed agentic surfaces directly: `scripts/render-project-agents-md.sh --project-root . --write`, then run the relevant project-agent onboarding smoke/check.

7. **Quality Gate**
   - Run `quality-assurance-workflow.md`.

8. **Memory Update & RAG Knowledge Generation**
   - Log outcomes in `PROJECT_HISTORY.md` only when `project_ledgers=true` and the result is durable: contract change, architecture/workflow/core-script change, user-visible behavior worth future recall, or version milestone.
   - Log issues in `ERROR_LOG.md` only when `project_ledgers=true` and there was a real incident, regression, repeated failure, or blocked execution with root cause/fix.
   - **RAG memory-note generation** (only when `memory_vault=true`) — never choose a folder manually. Call `scripts/capture-ki.sh --summary "<durable synthesis>" --tenant-domain <area> --kind decision|pattern|api_contract --write` for durable decisions, reusable conventions, and API contract changes.
   - Apply **Cross-Workflow Rule**: if any workflow step generated a security, Docker, a11y, i18n, or other domain-specific decision, create the KI with the appropriate `tenant_domain`.
   - **Knowledge Capture Fallback**: If `memory_vault=true` and earlier discovery, investigation, or plan audit occurred but was not captured by `auto-pilot` or Step 1/2, run `scripts/capture-ki.sh --suggest-from-current-state --json` and write only when it returns a durable signal.

9. **Context Compaction**
   - On long sessions, update `.agent/current_state.json` and regenerate `.agent/current_state.md` / `.agent/project_state.json`.
