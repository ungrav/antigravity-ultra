---
description: End-to-end feature workflow: consume pre-plan evidence, implement, integrate, verify, generate RAG knowledge, and sync agentic metadata.
version: v8.3
last_updated: 2026-05-13
surface_class: public
workflow_family: delivery
entry_role: canonical
---
# Feature Development Workflow

> Global rule: SAFE DELETE applies everywhere.

> Use this only for `standard` or `deep_audit` delivery. If `auto-pilot-workflow.md` resolved `task_execution_lane = fast_local`, stay in the localized Auto-Pilot path.

## Steps
1. **Flags, Scope, and Plan Gate**
   - Resolve feature flags with `scripts/kernel-feature-enabled.sh --json --root <project>` when available.
   - Define objective, impacted files, acceptance criteria, and verification profile.
   - Consume Auto-Pilot `discovery_evidence` from `run_state.json`; do not redo discovery unless evidence is missing or stale.
   - For sensitive surfaces under `rules/implementation-planning.md`, present the blocking host/session plan and wait for structured approval before mutating.
   - For bounded non-sensitive work, use a short chat/session receipt; no lifecycle event is required.
   - If scope changes materially, update the plan/receipt and renew approval before continuing.

2. **Reuse and Governance**
   - Reuse the skill/tool decision from Auto-Pilot or host discovery.
   - If a required skill is missing, search installed/available/community options before creating one.
   - Never extract private business logic into a global agent skill.
   - If external tooling, dependencies, APIs, models, unknown URLs, or package-manager changes are involved, consume prior governance first.
   - If package installation or lockfile sync is required, load `dependency-safety-baseline-workflow.md`; do not proceed on `BLOCKED`.
   - Use `web-safety-workflow.md` before web research, third-party code ingestion, or unknown URLs.

3. **Implementation**
   - Build incrementally and keep edits scoped to the affected surface.
   - Prefer AST-aware edits for imports/exports, signatures, JSX/TSX trees, nested objects, related symbols, or files over 300 lines; otherwise use the smallest safe patch.
   - Keep code and identifiers in English; keep function comments in Spanish when comments are needed.
   - UI front-ends must wrap blocking Promises and critical APIs (AI, WebGPU, WebCrypto, Service Workers) in `try/catch` with a user-safe fallback.
   - Test WebCrypto, Service Workers, WebGPU, OAuth callbacks, and secure cookies only on a verified secure local origin.
   - If a strict rule causes the same compile/lint failure more than twice, pause and ask whether to temporarily loosen the local rule.
   - For significant code modifications, append `.agent/knowledge/.wal_journal` only when `memory_vault=true` and `telemetry_tooling=true`.

4. **Integration**
   - Wire the feature into existing flows and validate no obvious regressions.
   - If `docker-compose.yml` exists, propose `docker compose build && docker compose up -d -V --force-recreate`, but enter `CONFIRM` before execution.
   - When new actions, routes, tools, or capabilities affect a T2/T3 project, run `scripts/render-project-agents-md.sh --project-root . --write`, then `--check` and the project-agent onboarding smoke.

5. **Quality and Memory**
   - Run `quality-assurance-workflow.md`.
   - Log `PROJECT_HISTORY.md` only for durable contract, architecture, workflow, core-script, user-visible behavior, or version milestone changes when project ledgers are enabled.
   - Log `ERROR_LOG.md` only for real incidents, regressions, repeated failures, or blocked execution with root cause/fix.
   - If `memory_vault=true`, use `scripts/capture-ki.sh --suggest-from-current-state --json`; write only durable decisions, reusable conventions, or API contracts.
   - On long sessions, update `.agent/current_state.json` and regenerate `.agent/current_state.md` plus `.agent/project_state.json`.
