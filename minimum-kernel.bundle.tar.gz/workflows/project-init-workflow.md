---
description: Deterministic first-run initialization. Creates mandatory memory files, bootstraps RAG knowledge vault, verifies git context, and bootstraps Agentic Stack when required.
version: v8.5
last_updated: 2026-04-11
surface_class: public
workflow_family: bootstrap
entry_role: canonical
---
# Project Init Workflow

> Global rule: SAFE DELETE applies everywhere.

## When to Run
- First entry into a project.
- Missing `PROJECT_HISTORY.md` or `ERROR_LOG.md` when `features.project_ledgers=true`.
- Missing `.agent/current_state.md`.
- Missing `.agent/knowledge/` directory when `features.memory_vault=true`.

## Steps
1. **Pre-Flight Infrastructure Check**
   - Detect whether the project truly needs a secure local origin (Service Worker, WebAuthn, WebCrypto, OAuth callbacks, `Secure` cookies).
   - If secure local origin is needed, choose the first viable option:
     1. `portless` if already installed.
     2. Framework-native HTTPS.
     3. `mkcert` + local proxy.
   - If none are available, transition to **CONFIRM** mode before proposing installation or local HTTPS setup.
   - If secure local origin is not needed, allow plain `http://localhost` and log the decision.

2. **Memory Files Check**
   - Resolve feature flags first with `scripts/kernel-feature-enabled.sh --json --root <project>` when available.
   - If `features.project_ledgers=true` and `PROJECT_HISTORY.md` is missing, create from BLUEPRINTS semantic section `<!-- BEGIN: PROJECT_HISTORY.md -->`.
   - If `features.project_ledgers=true` and `ERROR_LOG.md` is missing, create from BLUEPRINTS semantic section `<!-- BEGIN: ERROR_LOG.md -->`.
   - If `.agent/current_state.md` is missing, create a strict mutable handoff template with this exact section order:
     - `Current Objective`
     - `Last Completed Task`
     - `Blockers`
     - `Active Files`
     - `Resume Commands`
     - `Next Step`
     - `Verification Status`
     - `Freshness`
   - If `.agent/project_state.json` is missing, generate it from `.agent/current_state.md` with `scripts/render-project-state-cache.sh`; seed neutral `plan_state` defaults in `current_state.md` frontmatter, not in the cache.

3. **Universal Zero-Trust Initialization**
   - Before running ANY package manager install command (e.g., `npm i`, `pip install`, `cargo build`, `go mod download`) or pulling external binaries:
     1. **Priority 1**: Use specialized analyzer skills (e.g. `npx skills find security-audit`) to perform a static, dry-run audit of lockfiles (`package-lock.json`, `Cargo.lock`, `poetry.lock`) without downloading/executing packages.
     2. **Priority 2**: Use native dry-run commands (e.g., `npm audit --package-lock-only`, `pip-audit -r`).
     3. Extract core dependencies and run the inline external governance checklist: official/current source, maintenance, license, security posture, alternatives, and project fit.
     4. Run `dependency-safety-baseline-workflow.md` to classify the next step as safe local sync, project dependency install, or host/global install.
   - If critical vulnerabilities are found, or if the project relies on heavily deprecated paradigms, **DO NOT INSTALL**.
   - Transition to `CONFIRM` mode and present a "Modernization Proposal" (categorized by Patch/Minor/Major risks).
   - If the next step is classified as `dependency_sync_local` and the project root is trusted, `.venv` bootstrap or lockfile sync may proceed using the scoped sync-approval path without extra interruption.

4. **Git Context Safety**
   - Check git status, current branch, remotes, and uncommitted changes before mutating repository structure.
   - If no git repo and user approves, initialize repository.

5. **Design System (UI projects only)**
   - If UI exists and `DESIGN_SYSTEM.md` missing, create from BLUEPRINTS semantic section `<!-- BEGIN: DESIGN_SYSTEM.md -->`.

6. **RAG Knowledge Vault Bootstrap**
   - If `features.memory_vault=false`, skip this step entirely. Do not create `.agent/knowledge/`, `.project_dna.md`, KIs, or `inbox/` as baseline artifacts.
   Skip if `.agent/knowledge/` already exists with populated folders.
   1. **Detect project type** from manifest files:
      - `package.json` with `next`/`remix`/`nuxt` -> **Full-Stack**
      - `package.json` with `react`/`vue`/`svelte` (no server) -> **Frontend**
      - `package.json` with `express`/`fastify`/`nest`/`hono` -> **Backend API**
      - `pyproject.toml` with `fastapi`/`django`/`flask` -> **Backend API**
      - `pyproject.toml`/`setup.py` with CLI tools (`click`, `typer`) -> **CLI/Library**
      - `pyproject.toml` with `torch`/`tensorflow`/`pandas` -> **ML/Data Pipeline**
      - `Cargo.toml` -> **CLI/Library** (default)
      - No manifest -> **CLI/Library** (minimal)
   2. **Create logical folder structure** per `~/.gemini/MEMORY.md`:
      | Detected Stack | Folders |
      |---|---|
      | Any project | architecture, incidents, ecosystem, research, context |
      | Compatibility | legacy category folders are read-only for one release and should not be created for new vaults |
      | Explicit tooling only | `inbox/` is created only by memory tooling, never by normal project init |
   3. **Scan project files for initial KIs** (max 1 summary KI per source):
      - `package.json`/`pyproject.toml` -> 1 `category: "ecosystem"`, `kind: "dependency"` KI summarizing notable deps. Exclude trivial: `eslint*`, `prettier*`, `jest`, `mocha`, `vitest`, `*-loader`, `lodash`, `@types/*`, `rimraf`, `husky`, `lint-staged`.
      - `README.md` -> 1 `category: "architecture"`, `kind: "decision"` KI with project purpose and stack (only if >200 chars of real content).
      - `.env.example` -> 1 `category: "ecosystem"`, `kind: "config"` KI listing required variables (NEVER store actual values).
      - `DESIGN_SYSTEM.md` -> 1 `category: "architecture"`, `kind: "decision"` KI with `tenant_domain: "design"` (UI projects only).
      - `prisma/schema.prisma` or `migrations/` -> 1 `category: "architecture"`, `kind: "schema_migration"` KI with current schema state.
   3.5. **PROJECT_HISTORY Bootstrap**: If `PROJECT_HISTORY.md` has >5 significant entries, generate 1 `research` KI in `.agent/knowledge/research/` synthesizing accumulated knowledge.
   3.6. **Runtime State Skeleton**:
      - Initialize `.agent/current_state.md` with JSON frontmatter if absent, then generate `.agent/project_state.json` from it with `scripts/render-project-state-cache.sh`.
      - Treat `.vectorstore/`, `.graph_index.json`, `.entity_aliases.json`, maintenance state, and `.project_dna.md` as follow-up artifacts. Their absence must NOT block the simple memory bootstrap.
   4. **Update `.gitignore`** -- append if not present:
      ```
      # RAG Knowledge Vault (transient files)
      .agent/knowledge/.wal_journal
      .agent/knowledge/.memory_maintenance.json
      .agent/knowledge/.memory_maintenance.lock
      .agent/knowledge/.vectorstore/
      .agent/knowledge/.graph_index.json
      .agent/knowledge/.entity_aliases.json
      .agent/knowledge/.rebuild.lock
      .agent/knowledge/_DEPRECATED_TRASH/
      ```
   5. **Import global patterns** -- if `~/.gemini/knowledge/global_patterns/` has KIs matching the project's detected domains, copy them to `.agent/knowledge/architecture/` with `kind: "pattern"`.
      - In v1, import ONLY `global_patterns/`.
      - Do NOT copy `~/.gemini/knowledge/advisories/` into the project vault.
      - Do NOT copy `~/.gemini/knowledge/global_profile/` into the project vault.
      - If global maintenance state is missing, note the drift for health diagnostics only when relevant and do not block project bootstrap.

6.5. **User-Facing Documentation Bootstrap**
   - If project is web/app OR has >2 main dependencies:
     - Create `docs/decisions/` (if not exists) for ADRs.
     - Create `docs/plans/` (if not exists) for design docs.
   - Do NOT create if project is a simple script or minimal CLI.

7. **Agentic Stack Bootstrap (tiered)**
   - Classify the project before generating artifacts:
     - **T0**: script, scratch repo, minimal CLI -> ensure `AGENTS.md` onboarding only.
     - **T1**: standard app with no exposed agent-facing capabilities -> ensure `AGENTS.md` onboarding only.
     - **T2**: project should be readable by other agents or teams -> ensure `AGENTS.md` + `llms.txt`.
     - **T3**: project exposes APIs, tools, MCP/A2A metadata, or explicit agent interoperability -> create renderer-managed agentic surfaces directly.
   - `AGENTS.md` is always a deterministic onboarding export generated by `scripts/render-project-agents-md.sh`; it is not a manual parallel source of truth.
   - Verify `AGENTS.md` with `scripts/render-project-agents-md.sh --project-root . --check`. T2/T3 extend verification to `llms.txt`, `server.json`, `.mcp.json`, `.well-known/agent-card.json`, and `agent-tools.js` when those surfaces exist.

8. **Initial Logging**
   - Append project baseline status in `PROJECT_HISTORY.md` only when `features.project_ledgers=true`.
   - If RAG vault was created and `features.project_ledgers=true`, log: "RAG Knowledge Vault initialized (type: <detected_type>, folders: <count>, simple-memory: v1)".
   - Populate `.agent/current_state.md` with the strict live-state contract and bootstrap verification status/freshness.

9. **Foreign Context Normalization**
   - Before the first local context generation, run `scripts/normalize-foreign-project-context.sh --project-root . --write`.
   - Normalization precedence is fixed:
     1. `./GEMINI.md`
     2. `./gemini.md`
     3. `./AGENTS.md`
     4. `./CLAUDE.md`
   - If `GEMINI.md` already exists, preserve it as the canon and record `context_import.source_type = native_gemini`.
   - If only `gemini.md` exists, preserve it as compatibility input, record `context_import.source_type = legacy_gemini`, and let the existing orchestrator migration path generate `GEMINI.md`.
   - If no Gemini file exists but `AGENTS.md` exists, seed a canonical `GEMINI.md` from the durable onboarding subset, record `context_import.mode = migrate_agents`, and preserve the imported `AGENTS.md` content for the renderer-managed Human Zone migration.
   - If only `CLAUDE.md` exists, seed a canonical `GEMINI.md` from durable project facts, record `context_import.mode = seed_from_claude`, and preserve `CLAUDE.md` untouched.
   - If `AGENTS.md` and `CLAUDE.md` both exist without `GEMINI.md`, prefer `AGENTS.md` for portable facts and use `CLAUDE.md` only as secondary durable input.

10. **Canonical Context Bootstrap**
   - After normalization, ensure `./GEMINI.md` exists as canonical local context. If a legacy `./gemini.md` already exists, treat it as compatibility input only and preserve it untouched.

11. **Project Agent Onboarding Render**
   - After `GEMINI.md` exists, ensure `AGENTS.md` for every project via `scripts/render-project-agents-md.sh --project-root . --write`.
   - The renderer must persist `agent_onboarding.source_hash`, `render_hash`, `docs_presence`, and `agentic_surfaces` in `.agent/project_state.json`.
   - The renderer must not embed live session state, blockers, or dynamic RAG summaries into `AGENTS.md`.

## Exit Criteria
- `PROJECT_HISTORY.md` present when `features.project_ledgers=true`; otherwise not required.
- `ERROR_LOG.md` present when `features.project_ledgers=true`; otherwise not required.
- `.agent/current_state.md` present.
- `AGENTS.md` present and renderer-managed.
- `.agent/knowledge/` present with logical folders when `features.memory_vault=true`; otherwise not required.
- `.gitignore` includes RAG transient exclusions.
- For T2/T3 projects: required agentic artifacts created and verified.
