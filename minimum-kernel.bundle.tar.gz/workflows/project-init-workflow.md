---
description: Deterministic first-run initialization. Creates mandatory memory files, bootstraps RAG knowledge vault, verifies git context, and bootstraps Agentic Stack when required.
version: v8.5
last_updated: 2026-05-13
surface_class: public
workflow_family: bootstrap
entry_role: canonical
---
# Project Init Workflow

> Global rule: SAFE DELETE applies everywhere.

## When to Run
- First entry into a project.
- Missing `.agent/current_state.md`, renderer-managed `AGENTS.md`, or required ledgers when feature flags require them.
- Missing `.agent/knowledge/` when `features.memory_vault=true`.

## Steps
1. **Feature Flags and Preflight**
   - Resolve flags with `scripts/kernel-feature-enabled.sh --json --root <project>` when available.
   - Check git status, branch, remotes, and uncommitted changes before mutating structure.
   - For secure local APIs (Service Worker, WebAuthn, WebCrypto, OAuth callbacks, `Secure` cookies), prefer existing `portless`, then framework HTTPS, then `mkcert` proxy; if none is available, enter `CONFIRM`.
   - Before package install/sync, run `dependency-safety-baseline-workflow.md` and block on unsafe external dependency decisions.
   - After restoring scripts, run `scripts/dependency-safety-adapter.sh --root . install-guard` when available so new users get guarded `npx`/`pnpx`/`pnpm dlx` behavior even without a preexisting host guard.

2. **Runtime State and Ledgers**
   - If `features.project_ledgers=true`, restore missing `PROJECT_HISTORY.md` and `ERROR_LOG.md` from `GEMINI_BLUEPRINTS.md`.
   - Ensure `.agent/current_state.md` exists with this exact section order: `Current Objective`, `Last Completed Task`, `Blockers`, `Active Files`, `Resume Commands`, `Next Step`, `Verification Status`, `Freshness`.
   - Ensure `.agent/current_state.json` is the structured source and render `.agent/project_state.json` from it with `scripts/render-project-state-cache.sh`.
   - Append bootstrap status to `PROJECT_HISTORY.md` only when project ledgers are enabled.

3. **Knowledge Vault**
   - If `features.memory_vault=false`, do not create `.agent/knowledge/`, KIs, `.project_dna.md`, graph/vector artifacts, or maintenance state.
   - If enabled and absent, create only logical folders from `MEMORY.md`: `architecture`, `incidents`, `ecosystem`, `research`, and `context`.
   - Seed at most one KI per durable source: manifest dependency summary, substantive README, `.env.example` variable list without values, design system decision, schema/migration summary, or meaningful historical synthesis.
   - Treat `.vectorstore/`, `.graph_index.json`, `.entity_aliases.json`, maintenance files, and `.project_dna.md` as follow-up artifacts; their absence must not block bootstrap.
   - Add `.agent/knowledge/.wal_journal`, maintenance files, vectorstore, graph indexes, aliases, locks, and `.agent/knowledge/_DEPRECATED_TRASH/` to `.gitignore`.

4. **Import global patterns**
   - Import only matching files from `~/.gemini/knowledge/global_patterns/` into project architecture KIs.
   - Do NOT copy `~/.gemini/knowledge/advisories/` into the project vault.
   - Do NOT copy `~/.gemini/knowledge/global_profile/` into the project vault.
   - Missing global maintenance state is a diagnostic note only, never a bootstrap blocker.

5. **Foreign Context Normalization**
   - Run `scripts/normalize-foreign-project-context.sh --project-root . --write` before first local context generation.
   - Precedence is fixed: `GEMINI.md`, `gemini.md`, `AGENTS.md`, then `CLAUDE.md`.
   - Preserve existing `GEMINI.md` as canon; treat legacy `gemini.md` as compatibility input only.
   - If only `AGENTS.md` or `CLAUDE.md` exists, seed durable project facts into canonical `GEMINI.md` and preserve the source file untouched.

6. **Agentic Stack**
   - Classify T0/T1 as renderer-managed `AGENTS.md` only; T2 adds `llms.txt`; T3 adds API/tool/MCP/A2A surfaces when applicable.
   - Always ensure `AGENTS.md` for every project with `scripts/render-project-agents-md.sh --project-root . --write`.
   - Verify with `scripts/render-project-agents-md.sh --project-root . --check`.
   - For T2/T3, also verify existing `llms.txt`, `server.json`, `.mcp.json`, `.well-known/agent-card.json`, and `agent-tools.js`.

## Exit Criteria
- Required ledgers exist when `features.project_ledgers=true`.
- `.agent/current_state.md`, `.agent/current_state.json`, and `.agent/project_state.json` are aligned.
- `.agent/knowledge/` exists only when `features.memory_vault=true`.
- `AGENTS.md` is renderer-managed and verified.
- T2/T3 agentic surfaces are present and checked when applicable.
