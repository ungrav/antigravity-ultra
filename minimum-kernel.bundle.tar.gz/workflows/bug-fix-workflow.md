---
description: Diagnose, reproduce, fix, verify bugs, and capture resolution as RAG knowledge.
version: v8.1
last_updated: 2026-03-28
surface_class: public
workflow_family: delivery
entry_role: canonical
---
# Bug Fix Workflow

> Global rule: SAFE DELETE applies everywhere.

> This workflow is for `standard` / `deep_audit` bug resolution. If the router resolved `task_execution_lane = fast_local`, keep the work in the localized Auto-Pilot path unless an invalidator promotes it.

## Steps
0. **Feature Flags**
   - Resolve optional runtime features with `scripts/kernel-feature-enabled.sh --json --root <project>` when available.
   - `memory_vault=false`: skip RAG incident lookup, global knowledge synthesis, and KI generation.
   - `project_ledgers=false`: do not require `ERROR_LOG.md` or `PROJECT_HISTORY.md`.
   - `strict_plan_gate=false`: use a short receipt for bounded fixes unless the bug touches a sensitive surface.

1. **Reproduce**
   - Define exact reproduction path.
   - Capture error output and context.

2. **Diagnose**
   - Identify root cause (not only symptom).
   - Check `ERROR_LOG.md` for similar incidents only when `project_ledgers=true`.
   - **RAG Check**: If `memory_vault=true` and `.agent/knowledge/incidents/` exists, search for KIs with matching entities to see if this bug pattern has occurred before.

3. **Preflight, Fix Strategy & Plan Gate**
   - If the bug is local, obvious, and bounded, stay lightweight and do not force the full pre-plan chain.
   - If the root cause is uncertain, the fix may touch multiple modules, or the resolution may introduce tooling/dependencies/external tech, consume `discovery_evidence` from `run_state.json` or gather pre-plan intelligence inline before choosing the fix.
   - If the bug fix touches sensitive/high-impact surfaces under `rules/implementation-planning.md`, ensure the blocking host-internal implementation plan exists, is reflected in `plan_state` via explicit plan events, and is approved through an explicit host action before mutating code.
   - Bounded local bugfixes across 1-3 tightly related files may proceed with targeted verification or `standard_low` receipt flow; do not force a long plan or lifecycle event when auth/storage/API/migration/dependency/MCP/memory/blueprints/core-script/breaking surfaces are absent.
   - **Additive Editing**: The default behavior is to extend/improve existing functions incrementally. Do not "wipe and rewrite from scratch" to avoid breaking adjacent stable code.
   - **Nuclear Escape Hatch**: If the existing code is severely degraded (spaghetti) and additive editing will cause Tech Debt, you MUST switch to CONFIRM mode, pause, and ask the user explicit permission to "Wipe and Rewrite".
   - Avoid unrelated refactors.
   - For complex, difficult-to-isolate bugs with a clear evaluator and editable-file allowlist, consider routing to `autofix-workflow.md`.

4. **External Governance Gate (if needed)**
   - If fix introduces new external dependency/tool/API/model, first consume any existing governance recommendation from `discovery_evidence`.
   - If none exists, run the inline external governance checklist and use `dependency-safety-baseline-workflow.md` / `web-safety-workflow.md` as applicable before implementation.

5. **Verify & Auto-Docker Refresh**
   - **Docker Refresh**: If a `docker-compose.yml` exists, propose `docker compose build && docker compose up -d` to ensure the container reflects the fix, but transition to **CONFIRM** mode before execution.
   - Reproduction now passes.
   - No regression in existing behavior.
   - Visual verification for UI issues.

6. **Document, Synthesize & RAG Knowledge**
   - Add incident entry in `ERROR_LOG.md` only when `project_ledgers=true` and the bug is a real incident, recurring failure, regression, blocked execution, or has a reusable root cause.
   - Add fix summary in `PROJECT_HISTORY.md` only when `project_ledgers=true` and the fix changes durable behavior, closes a notable regression, or establishes a reusable decision/pattern.
   - **RAG KI Generation** (only when `memory_vault=true`): call `scripts/capture-ki.sh --kind bug_resolution --tenant-domain <area> --summary "<root cause, fix, prevention>" --write`. Do not write `.agent/knowledge/incidents/` files manually.
   - Apply **Cross-Workflow Rule**: if the bug was caused by a security vulnerability, use `tenant_domain: "security"`. If it was a rollback/incident, use `tenant_domain: "incident"`.
   - **WAL Entry**: Append `[<ISO-8601>] BUG_FIX: <1-line summary>` only when `memory_vault=true` and `telemetry_tooling=true`.
