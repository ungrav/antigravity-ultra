---
description: Public skills maintenance gate. Verifies registry sync, curation, duplicates, trust policy, and update decisions without specialist workflow indirection.
status: bundle
version: v8.0
last_updated: 2026-03-28
surface_class: public
workflow_family: skills
entry_role: canonical
---
# Skills Lifecycle Workflow

> Puerta pública de lifecycle de skills. El flujo absorbe verificación y actualización; no depende de workflows especialistas.

## When to Run
- Monthly maintenance and periodic system hygiene.
- After adding/removing skills.
- When `system-health-check-workflow.md` detects skill inconsistencies.

## Steps

### Step 1: Skills Verification
- Run `scripts/sync-skills-registry.sh` after adding, removing, or moving installed skill directories.
- Verify registry sync, curation tiers, duplicate state, and discovery contract.
- Validate SKILL.md format, required fields, source trust, and local/global duplication.
- Run `scripts/resolve-capability-context.sh --task "<maintenance task>" --lane standard --json` when validating task-specific skill routing. Confirm selected skills are compact, project-first, and limited to the task surface.

### Step 2: Skills Update
- Check for newer versions of installed skills only from trusted or explicitly approved sources.
- Apply updates following trust policy from `rules/skills-arsenal.md`.
- After updates, rerun registry sync, relevant skill smokes, and blueprint generation/manifest verification when portable skill artifacts changed.

### Step 3: Capability Acquisition
- Search local registry first through `scripts/resolve-capability-context.sh`; if there is no clear match, run `scripts/skill-trust-gate.sh discover --task "<task>" --paths "<paths>" --lane standard`.
- The discovery gate must build a project-context brief before using skills.sh `find-skills`: objective, stack, files, constraints, problem shape, environment, and success criteria. Do not reduce discovery to one or two generic keywords.
- Use the official skills.sh `find-skills` flow as the external discovery path. The underlying CLI is run through `scripts/dependency-safety-adapter.sh` with the pinned `skills@1.5.6`, exact versions, no `@latest`, and `DISABLE_TELEMETRY=1`.
- Before installing, run `scripts/skill-trust-gate.sh audit --source-url <url> --skill-id <id>` and record approval with `scripts/skill-trust-gate.sh approve ...` only when scanner output and source review justify it.
- Install into `.agents/skills/` by default after trust approval. Use global install only when the user explicitly requested global scope and confirms the elevated risk.
- After acquisition, rerun `scripts/sync-skills-registry.sh`, then `check-skill-discovery-flow.sh`, `check-skill-acquisition-gate.sh`, and the resolver smoke checks so compact rules and curation stay aligned.

## Output
- `SKILLS_LIFECYCLE_OK` — verification and update passed.
- `SKILLS_LIFECYCLE_ISSUES` — with detail per step.
