---
description: Public skills maintenance gate. Verifies registry sync, curation, duplicates, trust policy, and update decisions without specialist workflow indirection.
status: bundle
version: v8.0
last_updated: 2026-03-28
surface_class: public
workflow_family: skills
entry_role: canonical
---
# Skills Lifecycle Workflow

> Puerta pública de lifecycle de skills. El flujo absorbe verificación y actualización; no depende de workflows especialistas.

## When to Run
- Monthly maintenance and periodic system hygiene.
- After adding/removing skills.
- When `system-health-check-workflow.md` detects skill inconsistencies.

## Steps

### Step 1: Skills Verification
- Run `scripts/sync-skills-registry.sh` after adding, removing, or moving installed skill directories.
- Verify registry sync, curation tiers, duplicate state, and discovery contract.
- Validate SKILL.md format, required fields, source trust, and local/global duplication.

### Step 2: Skills Update
- Check for newer versions of installed skills only from trusted or explicitly approved sources.
- Apply updates following trust policy from `rules/skills-arsenal.md`.
- After updates, rerun registry sync, relevant skill smokes, and blueprint generation/manifest verification when portable skill artifacts changed.

## Output
- `SKILLS_LIFECYCLE_OK` — verification and update passed.
- `SKILLS_LIFECYCLE_ISSUES` — with detail per step.
