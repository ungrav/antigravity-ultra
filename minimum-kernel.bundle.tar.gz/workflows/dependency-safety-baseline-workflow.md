---
description: Classify dependency commands into safe local syncs, project dependency installs, or host/global installs, then apply the correct baseline and approval path.
version: v1.0
last_updated: 2026-03-28
surface_class: public
workflow_family: governance
entry_role: specialist
---
# Dependency Safety Baseline Workflow

> Global rule: SAFE DELETE applies everywhere.

## Purpose
- Normalize dependency actions before execution.
- Keep `ignore-scripts` enabled by default.
- Prefer project-scoped protection (`.npmrc`, `.venv`) over host mutation.
- Reuse scoped approvals instead of inventing a second install-approval system.
- Durable memory captures produced by this gate should use `kind: "dependency"` and a concise receipt, never a copied package audit dump.

## Classification
Map the planned command and intent into one of these operations:

### 1. `dependency_sync_local`
- Reproducible, project-local sync/reinstall/bootstrap with no package graph expansion.
- Examples:
  - `npm ci`
  - `npm rebuild <pkg>`
  - `pnpm install --frozen-lockfile`
  - `yarn install --immutable`
  - `uv sync --locked`
  - `python -m venv .venv`

### 2. `dependency_install`
- Adds, updates, or otherwise changes project dependencies.
- Examples:
  - `npm install foo`
  - `pnpm add foo`
  - `pip install foo`
  - `uv add foo`
  - package-manager updates that change manifests or lockfiles by design

### 3. `binary_install` / `dependency_install_global`
- Host/global tool or binary install.
- Examples:
  - `brew install`
  - `apt install`
  - `npm -g`
  - system-wide package or binary installers

## Baseline
### Node / npm
- Route remote package execution through `scripts/dependency-safety-adapter.sh` when available. It detects an existing host guard or installs/uses the portable guard under `.kernel/dependency-safety/bin/`.
- Remote execution (`npx`, `pnpx`, `pnpm dlx`, `npm exec`, MCP packages, skills CLI) requires exact package versions and allowlist approval. `@latest` is blocked.
- Use a minimum package release age of 24h for normal dependency installs and prefer 72h for MCPs, skills, CLIs, or anything that executes agent/runtime code.
- Set `DISABLE_TELEMETRY=1` for automated Skills CLI usage.
- Prefer repo `.npmrc` over `~/.npmrc`.
- Keep:
  - `ignore-scripts=true`
  - `strict-ssl=true`
  - `allow-git=root`
- Apply `save-exact=true` only for app/service/internal repos, not by default for reusable libraries.

### Python
- Prefer `.venv` inside the project for local development.
- Treat `.venv` creation as a local sync/bootstrap operation, not as host setup.
- Do not turn local Python dependency work into global `pip install` by convenience.

## Approval behavior
### Safe local sync path
- If operation is `dependency_sync_local` and project root is trusted:
  - the agent may create a short-lived `project_dependency_sync` grant and proceed without interrupting the user again.
- If the project is not trusted, remain in `CONFIRM`.

### Explicit full-auto path
- If the user explicitly says “haz todo en automático”, “ejecútalo todo”, or uses a workflow-scoped equivalent like `// turbo-all`:
  - the agent may create a short-lived `project_dependency_install` grant for the current `project_root`.
- This grant is only for project dependency work. It must never cover:
  - `binary_install`
  - `dependency_install_global`
  - deploy/publish
  - delete/move
  - `ignore-scripts` bypass
  - `allow-git` relaxation

## Hard exceptions
- If an install would require `--ignore-scripts=false`, stop and ask specifically which package requires lifecycle scripts and why.
- If an install would require relaxing `allow-git` beyond `root`, stop and ask specifically for that exception.
- If an MCP or skill wants a package that is missing from the allowlist, stop with the exact package, version, source, age, integrity, and risk. Never piggyback these exceptions on generic auto/full-auto wording.

## Integration points
- `auto-pilot-workflow.md`
- `project-init-workflow.md`
- `feature-development-workflow.md`
- `web-safety-workflow.md` when dependency selection depends on web or third-party source review.
