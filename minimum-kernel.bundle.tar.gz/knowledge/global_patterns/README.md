# Global Patterns Memory Vault

This directory contains cross-project validated patterns discovered by the AI Agent across sessions.
The Agent's RAG Memory Architecture uses this vault to bootstrap new projects and maintain global intelligence.

**Structure**:
Files here should be named `{YYYY-MM-DD}_{slug}.md` and follow the KI (Knowledge Item) YAML frontmatter standard.

**Contract notes**:
- This scope stores only `durable` promoted memory.
- Files here may be imported into project-local `.agent/knowledge/patterns/` during bootstrap when domain overlap exists.
- Do not store time-sensitive advisories or profile/preferences here.
