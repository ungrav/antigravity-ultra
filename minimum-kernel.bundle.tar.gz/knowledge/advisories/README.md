# Global Advisories Memory Vault

This directory contains `advisory` global KIs with time-sensitive or operationally volatile knowledge.

**Use this scope for**:
- provider/model stability notes
- deprecations and ecosystem hazards
- temporary operational guidance that must carry freshness metadata

**Rules**:
- advisories stay global-only in v1
- every advisory should include `last_verified_at`
- advisories should include `expires_at` when practical
- expired advisories must not be injected into active retrieval
