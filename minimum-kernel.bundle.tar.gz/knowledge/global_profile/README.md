# Global Profile Memory Vault

This directory contains low-priority `profile` KIs: explicit defaults, preferences, and operating conventions.

**Rules**:
- profile entries are advisory only
- they never outrank security, reality checks, or local active memory
- they should be explicit and bounded, not vague opinions
- they must not force deprecated technology or unhealthy providers/models
- feature consent decisions for optional capabilities (`SLM`, `Hyperlayer`) may be stored here
- runtime activation still comes from `state/capability_state.json`, not from these KIs directly
- when a new consent decision replaces an old one for the same feature, older entries should be marked `superseded`
